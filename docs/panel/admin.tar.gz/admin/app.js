import { initializeApp, deleteApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, signInWithPopup,
  GoogleAuthProvider, signOut, createUserWithEmailAndPassword, updateProfile,
  sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, collection, doc, getDoc as fsGetDoc, getDocs as fsGetDocs,
  setDoc as fsSetDoc, deleteDoc as fsDeleteDoc,
  query, orderBy, limit, where, serverTimestamp, enableIndexedDbPersistence
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  getDatabase, ref as dRef, set as dSet, get as dGet, update as dUpdate, remove as dRemove
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";
import {
  getStorage, ref as sRef, uploadBytesResumable, getDownloadURL
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

/* ================= konfigurasi ================= */
const firebaseConfig = {
  apiKey: "AIzaSyAAm1ylv5H4McTNvOut_0UdgiAFdxBBumI",
  authDomain: "my-app-e7f8c.firebaseapp.com",
  projectId: "my-app-e7f8c",
  storageBucket: "my-app-e7f8c.firebasestorage.app",
  messagingSenderId: "622104139221",
  appId: "1:622104139221:android:294ad10f9eed7350acd95c",
  databaseURL: "https://my-app-e7f8c-default-rtdb.asia-southeast1.firebasedatabase.app"
};
const PEMILIK = "bangexx01@gmail.com";   // akun owner panel

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const rtdb = getDatabase(app);
enableIndexedDbPersistence(db).catch(() => {});

/* ================= util ================= */
const $ = (id) => document.getElementById(id);
const el = (tag, isi, cls) => {
  const e = document.createElement(tag);
  if (isi !== undefined) e.textContent = isi;
  if (cls) e.className = cls;
  return e;
};
const aman = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const rupiah = (n) => new Intl.NumberFormat("id-ID").format(Number(n) || 0);
const waktu = (ts) => {
  if (!ts) return "—";
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d)) return "—";
  return d.toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
};
let jamToast;
function toast(pesan, gagal = false) {
  const t = $("toast");
  t.textContent = pesan;
  t.className = "toast tampil" + (gagal ? " gagal" : "");
  clearTimeout(jamToast);
  jamToast = setTimeout(() => (t.className = "toast"), 3600);
}
const kumpulan = (nama) => collection(db, nama);

/** Aset VIP & item toko: APK membaca RTDB vipCfg lebih dulu (Firestore hanya cadangan),
 *  jadi semua simpan/hapus harus menulis ke keduanya. Kunci RTDB tidak boleh memuat . # $ [ ] / */
const kunciVip = (id) => String(id).replace(/[.#$\[\]/]/g, "_");

/** Tulis/hapus simpul RTDB lewat server dompet (akun layanan). Jauh lebih andal
 *  daripada menulis langsung dari browser, yang sering ditolak aturan Firebase
 *  dengan "PERMISSION_DENIED". */
async function tulisRtdbServer(path, data, hapus = false) {
  const t = await auth.currentUser?.getIdToken();
  if (!t) throw new Error("Sesi panel tidak ditemukan, coba keluar lalu masuk lagi");
  const r = await fetch(DOMPET_BASE + "/panel-rtdb", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ t, path, data: hapus ? null : data, hapus }),
  });
  const j = await r.json().catch(() => null);
  if (!j || !j.ok) throw new Error((j && j.e) || ("HTTP " + r.status));
  return true;
}

/** Apakah galat ini penolakan izin Firebase (bukan jaringan)? */
const fsDitolak = (e) =>
  /permission-denied|insufficient|PERMISSION_DENIED|Missing or insufficient/i
    .test(String((e && (e.code || e.message)) || ""));

/** Jalur cadangan Firestore lewat server dompet (akun layanan). Dipakai staf
 *  panel, karena aturan Firestore hanya mengizinkan email developer. */
async function fsServer(op, p) { return walletAdmin({ op, ...p }); }
async function fsBacaJalur(jalur) {
  const out = await fsServer("fs_get", { jalur });
  return out.ada ? (out.data || null) : null;
}
async function fsTulisJalur(jalur, data) { return fsServer("fs_set", { jalur, data }); }
async function fsHapusJalur(jalur) { return fsServer("fs_del", { jalur }); }
async function fsCari(koleksi, medan, nilai, batas = 20) {
  const out = await fsServer("fs_where", { koleksi, medan, nilai, batas });
  return out.items || [];
}

/** Jalur dokumen dari DocumentReference atau Query (untuk cadangan server). */
const refJalur = (r) => {
  try { if (r && typeof r.path === "string" && r.path) return r.path; } catch (e) { }
  try {
    const seg = r && r._query && r._query.path && r._query.path.segments;
    if (Array.isArray(seg) && seg.length) return seg.join("/");
  } catch (e) { }
  return "";
};

/** Buang nilai sentinel Firebase (serverTimestamp) supaya bisa dikirim ke server. */
const dataRapi = (data) => {
  const asal = typeof data === "function" ? data() : (data || {});
  const out = {};
  for (const k of Object.keys(asal)) {
    const v = asal[k];
    if (v === undefined) continue;
    if (v && typeof v === "object" && ("_methodName" in v || "_delegate" in v)) { out[k] = Date.now(); continue; }
    out[k] = v;
  }
  return out;
};

/* Bungkus Firestore SDK: kalau aturan Firestore menolak (staf panel), ulangi
 * lewat server dompet memakai akun layanan. Dengan begitu semua halaman panel
 * tetap bisa dibaca dan disimpan oleh manager/admin. */
async function getDoc(ref) {
  try { return await fsGetDoc(ref); } catch (e) {
    if (!fsDitolak(e)) throw e;
    const jalur = refJalur(ref);
    if (!jalur) throw e;
    const d = await fsBacaJalur(jalur);
    return {
      id: (ref && ref.id) || jalur.split("/").pop(),
      exists: () => !!d,
      data: () => d || {},
      get: (k) => (d ? d[k] : undefined),
    };
  }
}

async function getDocs(q) {
  try { return await fsGetDocs(q); } catch (e) {
    if (!fsDitolak(e)) throw e;
    const jalur = refJalur(q);
    if (!jalur) throw e;
    const out = await fsServer("fs_list", { koleksi: jalur, batas: 500 });
    const docs = (out.items || []).map((x) => ({ id: x.id, data: () => x, exists: () => true }));
    return { docs, empty: docs.length === 0, size: docs.length, forEach: (f) => docs.forEach(f) };
  }
}

async function setDoc(ref, data, opsi) {
  try { return await fsSetDoc(ref, data, opsi); } catch (e) {
    if (!fsDitolak(e)) throw e;
    const jalur = refJalur(ref);
    if (!jalur) throw e;
    await fsTulisJalur(jalur, dataRapi(data));
  }
}

async function deleteDoc(ref) {
  try { return await fsDeleteDoc(ref); } catch (e) {
    if (!fsDitolak(e)) throw e;
    const jalur = refJalur(ref);
    if (!jalur) throw e;
    await fsHapusJalur(jalur);
  }
}

async function simpanVip(id, data) {
  let galatFs = null;
  try { await setDoc(doc(db, "vipConfig", id), data, { merge: true }); } catch (e) { galatFs = e; }
  // APK membaca RTDB lebih dulu dan MENGABAIKAN Firestore saat RTDB sudah ada.
  // Jadi kalau tulisan RTDB gagal, item akan tampak di panel tapi tidak pernah
  // muncul di Store aplikasi. Dulu kegagalan ini ditelan diam-diam.
  let galatRtdb = null;
  // 1) Jalur utama: server memakai akun layanan, tidak kena aturan tulis Firebase.
  try {
    await tulisRtdbServer("vipCfg/" + kunciVip(id), data);
  } catch (eServer) {
    // 2) Cadangan: tulis langsung dari browser (hanya jalan kalau aturan mengizinkan).
    try {
      await dUpdate(dRef(rtdb, "vipCfg/" + kunciVip(id)), data);
      const cek = await dGet(dRef(rtdb, "vipCfg/" + kunciVip(id)));
      if (!cek.exists()) galatRtdb = new Error("tulisan tidak terbaca kembali");
    } catch (e) { galatRtdb = new Error((e.message || e) + " / server: " + (eServer.message || eServer)); }
  }
  if (galatRtdb) {
    throw new Error("Gagal menulis ke RTDB (sumber yang dibaca APK): " + (galatRtdb.message || galatRtdb));
  }
  if (galatFs) console.warn("vipConfig Firestore dilewati:", galatFs.code || galatFs.message);
}

/** Samakan RTDB dengan panel: item yang cuma ada di Firestore (karena tulisan
 *  RTDB dulu gagal) disalin ke RTDB supaya muncul di Store aplikasi. */
async function sinkronVipRtdb(daftar) {
  if (!Array.isArray(daftar) || !daftar.length) return 0;
  let ada;
  try {
    const sn = await dGet(dRef(rtdb, "vipCfg"));
    ada = new Set();
    if (sn.exists()) sn.forEach((c) => ada.add(c.key));
  } catch (e) {
    return 0;
  }
  let n = 0;
  for (const it of daftar) {
    if (!it || !it.id) continue;
    const k = kunciVip(it.id);
    if (ada.has(k)) continue;
    const data = {};
    for (const [kk, vv] of Object.entries(it)) {
      if (kk.startsWith("_") || vv === undefined) continue;
      data[kk] = vv;
    }
    try {
      await dUpdate(dRef(rtdb, "vipCfg/" + k), data);
      n += 1;
    } catch (e) { /* dicoba lagi saat halaman dibuka berikutnya */ }
  }
  return n;
}
/** Hapus aset dari SEMUA tempat: dokumen Firestore bernama sama, dokumen lain
 *  yang membawa id yang sama, dan semua node RTDB dengan key atau id tersebut.
 *  Sebelumnya hanya satu salinan yang terhapus, jadi barisnya muncul lagi. */
async function hapusVip(id, kunci) {
  const galat = [];
  // 1) Firestore: dokumen vipConfig/<id> dan dokumen lain yang field id-nya sama.
  try { await deleteDoc(doc(db, "vipConfig", id)); } catch (e) { galat.push("firestore: " + (e.code || e.message)); }
  try {
    const snap = await getDocs(query(kumpulan("vipConfig"), limit(500)));
    for (const d of snap.docs) {
      if (d.id !== id && (d.data() || {}).id !== id) continue;
      try { await deleteDoc(d.ref); } catch (e) { galat.push("firestore " + d.id); }
    }
  } catch (e) { /* tanpa izin baca: cukup langkah 1 */ }
  // 2) RTDB: semua node yang key atau field id-nya cocok.
  try {
    const sn = await dGet(dRef(rtdb, "vipCfg"));
    if (sn.exists()) {
      const sasaran = [];
      sn.forEach((c) => {
        const v = c.val() || {};
        if (c.key === id || c.key === (kunci || "") || c.key === kunciVip(id) || v.id === id) sasaran.push(c.key);
      });
      for (const k of sasaran) {
        try {
          await tulisRtdbServer("vipCfg/" + k, null, true);
        } catch (eS) {
          try { await dRemove(dRef(rtdb, "vipCfg/" + k)); } catch (e) { galat.push("rtdb " + k); }
        }
      }
    }
  } catch (e) { galat.push("rtdb: " + (e.message || e)); }
  if (galat.length) throw new Error(galat.slice(0, 2).join(" · "));
}
/** Jual atau tarik item dari Store tanpa menghapus berkasnya. */
async function setStoreVip(item, jual) {
  await simpanVip(item.id, { store: jual, updatedAt: Date.now() });
  if (item._kunci && item._kunci !== item.id) {
    try { await dUpdate(dRef(rtdb, "vipCfg/" + item._kunci), { store: jual, updatedAt: Date.now() }); } catch (e) { /* sudah ditulis di simpanVip */ }
  }
}
async function ambilSemuaVip(batas = 400) {
  // Satu aset bisa ada di Firestore (vipConfig/<id>) dan RTDB (vipCfg/<kunci>).
  // Digabung berdasarkan id aset supaya tidak tampil sebagai baris ganda.
  const peta = new Map();
  const simpan = (obj, kunci) => {
    const id = String(obj.id || kunci || "");
    if (!id) return;
    const lama = peta.get(id) || {};
    peta.set(id, { ...lama, ...obj, id, _kunci: kunci || lama._kunci || kunciVip(id) });
  };
  try { (await ambilSemua("vipConfig", batas)).forEach((d) => simpan(d, d.id)); } catch (e) { /* Firestore cadangan */ }
  try {
    const sn = await dGet(dRef(rtdb, "vipCfg"));
    if (sn.exists()) sn.forEach((c) => simpan(c.val() || {}, c.key));
  } catch (e) { /* RTDB gagal: tetap pakai Firestore */ }
  return [...peta.values()];
}

async function ambilSemua(nama, batas = 500) {
  try {
    const snap = await getDocs(query(kumpulan(nama), limit(batas)));
    return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  } catch (e) {
    // Staf panel ditolak aturan Firestore: baca lewat server.
    if (!fsDitolak(e)) throw e;
    const out = await fsServer("fs_list", { koleksi: nama, batas });
    return out.items || [];
  }
}

async function catatLog(aksi, rincian = "") {
  try {
    await setDoc(doc(kumpulan("adminLogs")), {
      admin: auth.currentUser?.email || "?",
      aksi, rincian, waktu: serverTimestamp()
    });
  } catch (e) { /* log gagal tidak menghentikan aksi */ }
}

/* ================= unggah berkas ================= */
const TIPE_BERKAS = {
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif",
  webp: "image/webp", svga: "application/octet-stream", json: "application/json",
  mp4: "video/mp4", webm: "video/webm", mp3: "audio/mpeg", ogg: "audio/ogg"
};
const TERIMA_BERKAS = ".png,.jpg,.jpeg,.webp,.gif,.svga,.json,.mp4,.webm,.mp3,.ogg";

/** Baca berkas jadi base64 tanpa awalan data URL. */
async function bacaB64(berkas) {
  const data = await new Promise((ok, gagal) => {
    const fr = new FileReader();
    fr.onload = () => ok(String(fr.result || ""));
    fr.onerror = () => gagal(new Error("Berkas tidak bisa dibaca"));
    fr.readAsDataURL(berkas);
  });
  return data.replace(/^data:[^,]+,/, "");
}

function ukuranTeks(n) {
  const v = Number(n) || 0;
  if (v >= 1048576) return (v / 1048576).toFixed(1).replace(".", ",") + " MB";
  return Math.max(1, Math.round(v / 1024)) + " KB";
}

/** Gambar besar diperkecil dulu (WebP) supaya unggahan tidak lama di jaringan HP.
    Foto/SVGA/MP4 tidak disentuh. Kalau hasil kecilnya tidak lebih kecil, pakai aslinya. */
async function kecilkanBerkas(berkas) {
  try {
    // HANYA PNG/JPG statis yang boleh dikecilkan. WebP/GIF bisa berisi animasi
    // dan menggambarnya ulang di canvas membuangnya jadi satu gambar diam.
    if (!berkas || !/^image\/(png|jpe?g)$/i.test(berkas.type || "")) return berkas;
    if (berkas.size < 900 * 1024) return berkas;
    if (typeof createImageBitmap !== "function") return berkas;
    // PNG animasi (APNG) juga punya chunk acTL: jangan disentuh.
    if (/png/i.test(berkas.type)) {
      const kepala = new Uint8Array(await berkas.slice(0, 65536).arrayBuffer());
      const teks = new TextDecoder("latin1").decode(kepala);
      if (teks.indexOf("acTL") !== -1) return berkas;
    }
    const bmp = await createImageBitmap(berkas);
    const sisi = 1600;
    const skala = Math.min(1, sisi / Math.max(bmp.width || 1, bmp.height || 1));
    const w = Math.max(1, Math.round((bmp.width || 1) * skala));
    const h = Math.max(1, Math.round((bmp.height || 1) * skala));
    const cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    cv.getContext("2d").drawImage(bmp, 0, 0, w, h);
    const blob = await new Promise((ok) => cv.toBlob(ok, "image/webp", 0.9));
    try { bmp.close && bmp.close(); } catch (e) {}
    if (!blob || blob.size >= berkas.size) return berkas;
    const namaBaru = String(berkas.name || "aset").replace(/\.[^.]+$/, "") + ".webp";
    return new File([blob], namaBaru, { type: "image/webp" });
  } catch (e) {
    return berkas;
  }
}

async function unggahBerkas(berkas, folder, lapor) {
  if (lapor) lapor(1);
  const asliUkuran = berkas.size;
  berkas = await kecilkanBerkas(berkas);
  window.__unggahInfo = asliUkuran > berkas.size
    ? ukuranTeks(asliUkuran) + " → " + ukuranTeks(berkas.size)
    : "";
  if (lapor) lapor(2);
  const namaAman = String(berkas.name || "aset").replace(/[^a-zA-Z0-9._-]/g, "_");
  const ekstensi = namaAman.split(".").pop().toLowerCase();

  // 1) Jalur utama: simpan di VPS dompet Viza. Tidak perlu Firebase Storage.
  try {
    if (berkas.size > 8 * 1024 * 1024) throw new Error("Berkas lebih dari 8 MB, kecilkan dulu");
    if (lapor) lapor(0);
    const t = await auth.currentUser?.getIdToken();
    if (!t) throw new Error("Sesi login tidak ada, muat ulang panel");
    const dasar = folder + "-" + namaAman.replace(/\.[^.]+$/, "");
    // Kirim biner mentah: tidak membengkak seperti base64, dan persentasenya asli.
    const alamat = DOMPET_BASE + "/aset-upload?raw=1"
      + "&t=" + encodeURIComponent(t)
      + "&name=" + encodeURIComponent(dasar)
      + "&ext=" + encodeURIComponent(ekstensi);
    const j = await new Promise((selesai, gagal) => {
      const xhr = new XMLHttpRequest();
      // Progres tidak boleh mundur walau unggahan diulang dari awal.
      let maks = 0;
      const naik = (p) => {
        if (!lapor) return;
        if (p > maks) { maks = p; lapor(p); }
      };
      let coba = 0;
      const kirim = () => {
      xhr.open("POST", alamat, true);
      xhr.setRequestHeader("Content-Type", berkas.type || TIPE_BERKAS[ekstensi] || "application/octet-stream");
      xhr.timeout = 300000;
      xhr.upload.onprogress = (e) => {
        if (!lapor) return;
        if (e.lengthComputable) naik(Math.min(99, Math.round((e.loaded / e.total) * 100)));
        else naik(50);
      };
      xhr.onload = () => {
        let hasil = null;
        try { hasil = JSON.parse(xhr.responseText || "null"); } catch (e) { /* bukan JSON */ }
        if (hasil && hasil.ok && hasil.url) return selesai(hasil);
        gagal(new Error((hasil && hasil.e) || ("HTTP " + xhr.status)));
      };
      xhr.onerror = () => {
        // Jaringan HP sering putus di tengah unggahan: ulangi sekali dulu.
        if (coba < 1) { coba += 1; setTimeout(kirim, 800); return; }
        window.__galatVpsJaringan = true;
        gagal(new Error("Jaringan terputus saat mengunggah"));
      };
      xhr.ontimeout = () => {
        window.__galatVpsJaringan = true;
        gagal(new Error("Unggahan lebih dari 5 menit, coba lagi atau kecilkan berkas"));
      };
      xhr.send(berkas);
      };
      kirim();
    });
    if (lapor) lapor(100);
    return j.url;
  } catch (eVps) {
    window.__galatVps = String(eVps?.message || eVps);
    const putus = window.__galatVpsJaringan === true;
    window.__galatVpsJaringan = false;
    // Kalau server VPS MENOLAK (mis. sesi/peran), jangan diam-diam pindah ke
    // Firebase: unggahan akan mulai dari 0% dan sering menggantung. Tampilkan
    // alasannya supaya jelas apa yang harus dibetulkan.
    if (!putus) throw new Error(window.__galatVps);
    if (lapor) lapor(0);
  }

  // 2) Cadangan: Firebase Storage, hanya kalau VPS menolak.
  const jalur = `aset/${folder}/${Date.now()}-${namaAman}`;
  const rujukan = sRef(storage, jalur);
  const tugas = uploadBytesResumable(rujukan, berkas, {
    contentType: berkas.type || TIPE_BERKAS[ekstensi] || "application/octet-stream",
    cacheControl: "public,max-age=31536000"
  });
  await new Promise((selesai, gagal) => {
    tugas.on("state_changed",
      (s) => { if (lapor) lapor(Math.round((s.bytesTransferred / s.totalBytes) * 100)); },
      gagal, selesai);
  });
  return await getDownloadURL(rujukan);
}

/** Markah pemilih sumber: lewat tautan atau unggah berkas dari perangkat. */
function htmlSumber(id, urlAwal = "", terima = TERIMA_BERKAS) {
  return `
    <div data-sumber="${id}">
      <div class="tabSumber">
        <div class="pil on" data-mode="link">Pakai tautan</div>
        <div class="pil" data-mode="file">Unggah dari perangkat</div>
      </div>
      <div data-bagian="link" style="margin-top:8px">
        <div class="isian"><label>Tautan berkas (SVGA, WEBP, PNG, GIF, MP4)</label>
          <input id="${id}Url" value="${aman(urlAwal)}" placeholder="https://…/animasi.svga"></div>
      </div>
      <div data-bagian="file" style="margin-top:8px;display:none">
        <div class="isian"><label>Pilih berkas dari perangkat</label>
          <input id="${id}File" type="file" accept="${terima}">
          <div class="kemajuan" id="${id}Progres"></div></div>
      </div>
      <div class="kotakPratinjau">
        <div class="judulPratinjau">Pratinjau</div>
        <div class="layarPratinjau" id="${id}Pra"><span class="kosongPra">Belum ada berkas</span></div>
        <div class="infoPratinjau" id="${id}PraInfo"></div>
        <div class="alasPratinjau">
          <span data-alas="gelap" class="on">Gelap</span><span data-alas="terang">Terang</span><span data-alas="kotak">Kotak</span>
        </div>
      </div>
    </div>`;
}

/* ---------- pratinjau langsung ---------- */
let pemutarSvgaPromise;
function muatPemutarSvga() {
  if (window.SVGA) return Promise.resolve();
  if (!pemutarSvgaPromise) {
    pemutarSvgaPromise = new Promise((ok, gagal) => {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/svgaplayerweb@2.3.1/build/svga.min.js";
      s.onload = ok; s.onerror = () => gagal(new Error("pemutar SVGA gagal dimuat"));
      document.head.appendChild(s);
    });
  }
  return pemutarSvgaPromise;
}

function ukuranBerkas(b) {
  if (!b) return "";
  return b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(1) + " KB" : (b / 1048576).toFixed(2) + " MB";
}

const tokenPra = {};
async function tampilkanPratinjau(id, sumber, namaBerkas = "", ukuran = 0, jenisPaksa = "") {
  const layar = document.getElementById(id + "Pra");
  const info = document.getElementById(id + "PraInfo");
  if (!layar) return;
  const token = (tokenPra[id] = (tokenPra[id] || 0) + 1);
  if (!sumber) {
    layar.innerHTML = '<span class="kosongPra">Belum ada berkas</span>';
    if (info) info.textContent = "";
    return;
  }
  const jenis = jenisPaksa || cabangBerkas(namaBerkas || sumber);
  layar.innerHTML = '<span class="kosongPra">Memuat…</span>';
  const infoDasar = [jenis.toUpperCase(), ukuranBerkas(ukuran)].filter(Boolean).join(" · ");
  if (info) info.textContent = infoDasar;

  if (jenis === "gambar") {
    const im = new Image();
    im.onload = () => {
      if (token !== tokenPra[id]) return;
      layar.innerHTML = ""; layar.appendChild(im);
      if (info) info.textContent = `${infoDasar} · ${im.naturalWidth}x${im.naturalHeight}`;
    };
    im.onerror = () => { if (token === tokenPra[id]) layar.innerHTML = '<span class="kosongPra gagalPra">Gambar tidak bisa dimuat. Periksa tautan atau berkasnya.</span>'; };
    im.src = sumber;
  } else if (jenis === "video") {
    const v = document.createElement("video");
    v.src = sumber; v.autoplay = true; v.loop = true; v.muted = true; v.playsInline = true; v.controls = true;
    v.onloadedmetadata = () => { if (info && token === tokenPra[id]) info.textContent = `${infoDasar} · ${v.videoWidth}x${v.videoHeight} · ${v.duration.toFixed(1)} dtk`; };
    v.onerror = () => { if (token === tokenPra[id]) layar.innerHTML = '<span class="kosongPra gagalPra">Video tidak bisa dimuat.</span>'; };
    layar.innerHTML = ""; layar.appendChild(v);
  } else if (jenis === "svga") {
    try {
      await muatPemutarSvga();
      if (token !== tokenPra[id]) return;
      layar.innerHTML = '<div class="svgaKotak"></div>';
      const target = layar.querySelector(".svgaKotak");
      const pemutar = new window.SVGA.Player(target);
      const pemuat = new window.SVGA.Parser();
      pemuat.load(sumber, (data) => {
        if (token !== tokenPra[id]) return;
        pemutar.setVideoItem(data);
        pemutar.setContentMode("AspectFit");
        pemutar.startAnimation();
        const w = data.videoSize?.width, h = data.videoSize?.height;
        if (info) info.textContent = `${infoDasar}${w ? " · " + w + "x" + h : ""}${data.FPS ? " · " + data.FPS + " fps" : ""}`;
      }, () => {
        if (token === tokenPra[id]) layar.innerHTML = '<span class="kosongPra gagalPra">SVGA tidak bisa dibaca. Pastikan berkasnya benar atau server mengizinkan akses.</span>';
      });
    } catch (e) {
      layar.innerHTML = '<span class="kosongPra gagalPra">' + aman(e.message) + '</span>';
    }
  } else {
    layar.innerHTML = '<span class="kosongPra">Format tidak dikenali untuk pratinjau</span>';
  }
}

/** Pasang pendengar: dipanggil sekali setelah form tampil. */
function aktifkanPratinjau(id) {
  const url = document.getElementById(id + "Url");
  const file = document.getElementById(id + "File");
  let tunda;
  if (url) {
    const dariUrl = () => tampilkanPratinjau(id, url.value.trim());
    url.addEventListener("input", () => { clearTimeout(tunda); tunda = setTimeout(dariUrl, 450); });
    if (url.value.trim()) dariUrl();
  }
  if (file) {
    file.addEventListener("change", () => {
      const b = file.files?.[0];
      if (!b) return tampilkanPratinjau(id, "");
      const objek = URL.createObjectURL(b);
      tampilkanPratinjau(id, objek, b.name, b.size);
    });
  }
  const kotak = document.querySelector(`[data-sumber="${id}"]`);
  kotak?.querySelectorAll(".tabSumber .pil").forEach((p) => p.addEventListener("click", () => {
    if (p.dataset.mode === "file") {
      const b = file?.files?.[0];
      if (b) tampilkanPratinjau(id, URL.createObjectURL(b), b.name, b.size);
      else tampilkanPratinjau(id, "");
    } else {
      tampilkanPratinjau(id, url?.value.trim() || "");
    }
  }));
  kotak?.querySelectorAll(".alasPratinjau span").forEach((s) => s.addEventListener("click", () => {
    kotak.querySelectorAll(".alasPratinjau span").forEach((x) => x.classList.toggle("on", x === s));
    const layar = document.getElementById(id + "Pra");
    layar.dataset.alas = s.dataset.alas;
  }));
}

document.addEventListener("click", (e) => {
  const pil = e.target.closest(".tabSumber .pil");
  if (!pil) return;
  const kotak = pil.closest("[data-sumber]");
  kotak.querySelectorAll(".tabSumber .pil").forEach((p) => p.classList.toggle("on", p === pil));
  kotak.querySelectorAll("[data-bagian]").forEach((b) => {
    b.style.display = b.dataset.bagian === pil.dataset.mode ? "" : "none";
  });
});

/** Ambil URL akhir: tautan yang diketik atau hasil unggahan berkas. */
async function urlDariSumber(id, folder) {
  const kotak = document.querySelector(`[data-sumber="${id}"]`);
  const mode = kotak?.querySelector(".tabSumber .pil.on")?.dataset.mode || "link";
  if (mode === "link") return (document.getElementById(id + "Url")?.value || "").trim();
  const berkas = document.getElementById(id + "File")?.files?.[0];
  if (!berkas) throw new Error("Belum ada berkas yang dipilih");
  const progres = document.getElementById(id + "Progres");
  if (progres) progres.textContent = "mengunggah 0%";
  try {
    const url = await unggahBerkas(berkas, folder, (p) => { if (progres) progres.textContent = `mengunggah ${p}%`; });
    if (progres) progres.textContent = window.__unggahInfo
      ? "selesai diunggah (" + window.__unggahInfo + ")"
      : "selesai diunggah";
    return url;
  } catch (e) {
    if (progres) progres.textContent = e?.code === "storage/unauthorized"
      ? "ditolak: Storage belum aktif atau aturan Storage belum dipasang"
      : "gagal mengunggah: " + (window.__galatVps || e?.code || e?.message || "");
    throw e;
  }
}


/** Buat sampul PNG (frame diam) dari berkas animasi, lalu unggah ke VPS.
 *  Dipakai APK untuk tampilan kartu di luar; preview dan saat dipasang tetap
 *  memakai berkas animasi aslinya. Mengembalikan "" kalau tidak bisa dibuat. */
async function buatSampul(sumberUrl, jenis, folder) {
  try {
    if (!sumberUrl) return "";
    let kanvas = document.createElement("canvas");
    const MAKS = 512;
    if (jenis === "svga") {
      await muatPemutarSvga();
      const host = document.createElement("div");
      host.style.cssText = "position:fixed;left:-9999px;top:0;width:" + MAKS + "px;height:" + MAKS + "px";
      document.body.appendChild(host);
      try {
        const data = await new Promise((ok, gagal) => {
          new window.SVGA.Parser().load(sumberUrl, ok, () => gagal(new Error("svga")));
        });
        const w = data.videoSize?.width || MAKS, h = data.videoSize?.height || MAKS;
        const skala = Math.min(1, MAKS / Math.max(w, h));
        host.style.width = Math.round(w * skala) + "px";
        host.style.height = Math.round(h * skala) + "px";
        const pemutar = new window.SVGA.Player(host);
        pemutar.setVideoItem(data);
        pemutar.setContentMode("AspectFit");
        pemutar.stepToFrame(Math.min(Math.floor((data.frames || 1) / 3), Math.max(0, (data.frames || 1) - 1)), false);
        await new Promise((r) => setTimeout(r, 450));
        const cv = host.querySelector("canvas");
        if (!cv) return "";
        kanvas.width = cv.width; kanvas.height = cv.height;
        kanvas.getContext("2d").drawImage(cv, 0, 0);
        pemutar.clear && pemutar.clear();
      } finally { host.remove(); }
    } else if (jenis === "video") {
      const v = document.createElement("video");
      v.muted = true; v.playsInline = true; v.crossOrigin = "anonymous"; v.src = sumberUrl;
      await new Promise((ok, gagal) => { v.onloadeddata = ok; v.onerror = () => gagal(new Error("video")); });
      v.currentTime = Math.min(0.5, (v.duration || 1) / 3);
      await new Promise((r) => { v.onseeked = r; setTimeout(r, 1200); });
      const skala = Math.min(1, MAKS / Math.max(v.videoWidth, v.videoHeight));
      kanvas.width = Math.round(v.videoWidth * skala); kanvas.height = Math.round(v.videoHeight * skala);
      kanvas.getContext("2d").drawImage(v, 0, 0, kanvas.width, kanvas.height);
    } else {
      return "";
    }
    const blob = await new Promise((r) => kanvas.toBlob(r, "image/png"));
    if (!blob || blob.size < 200) return "";
    const berkas = new File([blob], "sampul.png", { type: "image/png" });
    return await unggahBerkas(berkas, folder + "_sampul", () => {});
  } catch (e) {
    console.warn("sampul gagal dibuat:", e?.message || e);
    return "";
  }
}

const cabangBerkas = (url) => {
  const bersih = String(url || "").split("?")[0].toLowerCase();
  const ext = bersih.split(".").pop();
  if (["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) return "gambar";
  if (["mp4", "webm"].includes(ext)) return "video";
  if (ext === "svga") return "svga";
  return "lain";
};
const pratinjauAset = (url) => {
  const jenis = cabangBerkas(url);
  const klik = `data-lihatbesar="${aman(url)}" title="Klik untuk memperbesar" style="cursor:zoom-in"`;
  if (jenis === "gambar") return `<div class="pratinjau" ${klik}><img src="${aman(url)}" alt=""></div>`;
  if (jenis === "video") return `<div class="pratinjau" ${klik}><video src="${aman(url)}" muted></video></div>`;
  if (jenis === "svga") return `<div class="pratinjau" ${klik}>SVGA ▶</div>`;
  return `<div class="pratinjau" ${klik}>FILE</div>`;
};

document.addEventListener("click", (e) => {
  const t = e.target.closest("[data-lihatbesar]");
  if (!t) return;
  const url = t.dataset.lihatbesar;
  if (!url) return;
  modal("Pratinjau", `
    <div class="kotakPratinjau" data-sumber="besar" style="margin-top:0">
      <div class="layarPratinjau" id="besarPra" style="height:320px"></div>
      <div class="infoPratinjau" id="besarPraInfo"></div>
      <div class="alasPratinjau">
        <span data-alas="gelap" class="on">Gelap</span><span data-alas="terang">Terang</span><span data-alas="kotak">Kotak</span>
      </div>
    </div>`);
  tampilkanPratinjau("besar", url);
  document.querySelectorAll('[data-sumber="besar"] .alasPratinjau span').forEach((s) => s.addEventListener("click", () => {
    document.querySelectorAll('[data-sumber="besar"] .alasPratinjau span').forEach((x) => x.classList.toggle("on", x === s));
    $("besarPra").dataset.alas = s.dataset.alas;
  }));
});

/* ================= status sesi ================= */
let adminSaya = null;

async function cekAdmin(user) {
  if (!user) return null;
  const email = (user.email || "").toLowerCase();
  const peran = { email, nama: user.displayName || email.split("@")[0], peran: email === PEMILIK ? "owner" : "-", aktif: true };
  if (email === PEMILIK) return peran;
  try {
    const d = await getDoc(doc(db, "panelAdmins", email));
    if (d.exists() && d.data().aktif !== false) {
      return { ...peran, peran: d.data().peran || "admin", nama: d.data().nama || peran.nama };
    }
  } catch (e) {
    console.warn("panelAdmins tidak terbaca:", e.code);
  }
  return null;
}

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    $("layarLogin").hidden = false;
    $("aplikasi").hidden = true;
    return;
  }
  adminSaya = await cekAdmin(user);
  if (!adminSaya) {
    $("pesanLogin").textContent = `Akun ${user.email} belum terdaftar sebagai admin panel. Minta owner mendaftarkan email ini di menu Pengaturan.`;
    await signOut(auth);
    return;
  }
  $("layarLogin").hidden = true;
  $("aplikasi").hidden = false;
  $("emailSaya").textContent = adminSaya.email;
  $("namaSaya").textContent = adminSaya.nama;
  $("peranSaya").textContent = adminSaya.peran;
  $("avaSaya").textContent = (adminSaya.nama || "A")[0].toUpperCase();
  bukaRute();
});

/* ================= login ================= */
/** Nama admin disimpan sebagai kunci panelNama agar bisa dipakai untuk login. */
function kunciNama(nama) {
  return String(nama || "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 60);
}
async function emailDariNama(nama) {
  const kunci = kunciNama(nama);
  if (!kunci) return "";
  try {
    const d = await getDoc(doc(db, "panelNama", kunci));
    return d.exists() ? String(d.get("email") || "") : "";
  } catch (e) { return ""; }
}


$("tombolMasuk").addEventListener("click", async () => {
  const isi = $("loginEmail").value.trim();
  const sandi = $("loginSandi").value;
  if (!isi || !sandi) return ($("pesanLogin").textContent = "Isi nama admin dan password dulu.");
  $("pesanLogin").className = "pesan info";
  $("pesanLogin").textContent = "Memeriksa…";
  // Boleh isi nama admin (seperti saat didaftarkan) atau email lengkap.
  let email = isi;
  if (!isi.includes("@")) {
    email = await emailDariNama(isi);
    if (!email) {
      $("pesanLogin").className = "pesan";
      $("pesanLogin").textContent = "Nama admin itu belum terdaftar. Pakai email, atau minta owner mendaftarkannya dulu.";
      return;
    }
  }
  try {
    await signInWithEmailAndPassword(auth, email, sandi);
  } catch (e) {
    $("pesanLogin").className = "pesan";
    $("pesanLogin").textContent = pesanAuth(e);
  }
});

/* Lupa sandi: kirim tautan reset ke email yang diisi. Berguna kalau akunnya
   sudah ada dari sebelumnya sehingga sandi baru tidak pernah terpasang. */
const lupaSandi = $("lupaSandi");
if (lupaSandi) lupaSandi.addEventListener("click", async () => {
  const isi = $("loginEmail").value.trim();
  if (!isi.includes("@")) {
    $("pesanLogin").className = "pesan";
    $("pesanLogin").textContent = "Isi email lengkap dulu untuk menerima tautan reset.";
    return;
  }
  $("pesanLogin").className = "pesan info";
  $("pesanLogin").textContent = "Mengirim tautan reset…";
  try {
    await sendPasswordResetEmail(auth, isi);
    $("pesanLogin").className = "pesan info";
    $("pesanLogin").textContent = "Tautan reset dikirim ke " + isi + ". Buka email itu, buat sandi baru, lalu masuk lagi.";
  } catch (e) {
    $("pesanLogin").className = "pesan";
    $("pesanLogin").textContent = pesanAuth(e);
  }
});

$("tombolGoogle").addEventListener("click", async () => {
  $("pesanLogin").className = "pesan info";
  $("pesanLogin").textContent = "Membuka Google…";
  try {
    await signInWithPopup(auth, new GoogleAuthProvider());
  } catch (e) {
    $("pesanLogin").className = "pesan";
    $("pesanLogin").textContent = pesanAuth(e);
  }
});

$("loginSandi").addEventListener("keydown", (e) => { if (e.key === "Enter") $("tombolMasuk").click(); });

function pesanAuth(e) {
  const kode = e?.code || "";
  if (kode.includes("invalid-credential") || kode.includes("wrong-password") || kode.includes("user-not-found"))
    return "Email atau password salah.";
  if (kode.includes("unauthorized-domain")) return "Domain panel ini belum diizinkan di Firebase Authentication.";
  if (kode.includes("popup-blocked")) return "Popup diblokir browser. Izinkan popup lalu coba lagi.";
  if (kode.includes("too-many-requests")) return "Terlalu banyak percobaan. Tunggu beberapa menit.";
  return e?.message || "Gagal masuk.";
}

$("tombolKeluar").addEventListener("click", async () => {
  await signOut(auth);
  location.hash = "";
});

/* ================= rute ================= */
/** Harga VIP 1-9 bisa diubah di sini; aplikasi membacanya dari /vip-harga. */
async function gambarVip() {
  let harga = [];
  let galat = "";
  try { harga = (await walletAdmin({ op: "vip_harga_get" })).harga || []; }
  catch (e) { galat = e.message || String(e); }
  if (!Array.isArray(harga) || harga.length !== 9) {
    harga = [500000, 1500000, 3000000, 6000000, 12000000, 25000000, 50000000, 100000000, 250000000];
  }
  $("aksiTopbar").innerHTML = '<button class="tombolAtas" id="simpanVip">Simpan harga</button>';
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="catatan">Harga VIP 1 sampai 9 dalam coin. Setelah disimpan, aplikasi memakai harga baru tanpa build ulang.</div>
      ${galat ? `<div class="catatan">${aman(galat)}</div>` : ""}
      <div class="barisIsian">
        ${harga.map((h, i) => `<div class="isian"><label>VIP ${i + 1}</label><input id="vipHarga${i + 1}" type="number" min="0" step="1000" value="${Number(h) || 0}"></div>`).join("")}
      </div>
    </div>`;
  $("simpanVip").onclick = async () => {
    const isi = [];
    for (let i = 1; i <= 9; i++) isi.push(Number($("vipHarga" + i).value) || 0);
    try {
      await walletAdmin({ op: "vip_harga_set", harga: isi });
      alert("Harga VIP disimpan.");
      bukaRute();
    } catch (e) { alert("Gagal menyimpan: " + (e.message || e)); }
  };
}

/** Harga membuat family + rasio exp ke coin family (dipakai aplikasi tanpa build ulang). */
async function gambarFamily() {
  let cfg = { harga: 200000, exp_per_coin: 100 };
  let galat = "";
  try { cfg = Object.assign(cfg, await walletAdmin({ op: "fam_cfg_get" })); }
  catch (e) { galat = e.message || String(e); }
  $("aksiTopbar").innerHTML = '<button class="tombolAtas" id="simpanFamily">Simpan</button>';
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="catatan">Harga membuat family dalam coin. Rasio exp family ke coin family: isi 100 artinya setiap 100 exp menjadi 1 coin family. Setelah disimpan, aplikasi memakai nilai baru tanpa build ulang.</div>
      ${galat ? `<div class="catatan">${aman(galat)}</div>` : ""}
      <div class="barisIsian">
        <div class="isian"><label>Harga buat family (coin)</label><input id="famHarga" type="number" min="0" step="1000" value="${Number(cfg.harga) || 0}"></div>
        <div class="isian"><label>Exp jadi 1 coin family</label><input id="famExp" type="number" min="1" step="1" value="${Number(cfg.exp_per_coin) || 100}"></div>
      </div>
    </div>`;
  $("simpanFamily").onclick = async () => {
    try {
      await walletAdmin({ op: "fam_cfg_set", harga: Number($("famHarga").value) || 0, exp_per_coin: Number($("famExp").value) || 100 });
      alert("Pengaturan family disimpan.");
      bukaRute();
    } catch (e) { alert("Gagal menyimpan: " + (e.message || e)); }
  };
}


/* ---------- Cashback gift: nominal tetap (persen + rentang) ---------- */
// Disimpan di Realtime Database pub/_cashbackCfg -> tiers, dibaca server dompet.
// Satu baris = "persen:nominal-min:nominal-max", mis. "70:1000:5000" artinya
// peluang 70% dapat cashback acak antara 1.000 sampai 5.000 coin.
// Nominal TIDAK dikali harga gift (sesuai contoh pemilik).
const CB_BAWAAN = {
  on: true,
  modePersen: true,
  capPct: 12000,
  recvPct: 70,
  diamondPct: 5,
  diamondBiasaPct: 100,
  kembaliPct: 0,
  bebasZonkMulai: 0,
  jpMin: 50000,
  // Model persen: hadiah = harga gift x pengali. Bobot = seberapa sering muncul.
  // Tanpa tingkatan 0: setiap kiriman dapat pecahan kecil, tidak ada zonk.
  // Ujungnya tetap ada 100x dan 1000x supaya jackpot masih bisa pecah besar.
  // Kurva JP: pengali dan "1 dari berapa kiriman".
  jpKurva: [
    { m: 1, n: 4 },
    { m: 3, n: 4 },
    { m: 5, n: 4 },
    { m: 10, n: 4 },
  ],


  kurvaAktif: true,
  kurvaMode: "acak",
  tiersPersen: [
    { m: 0.1, w: 50 },
    { m: 0.2, w: 25 },
    { m: 0.5, w: 14 },
    { m: 1, w: 8 },
    { m: 5, w: 2.5 },
    { m: 10, w: 0.39 },
    { m: 100, w: 0.1 },
    { m: 1000, w: 0.01 },
  ],
  tiers: [
    { p: 70, min: 1000, max: 5000 },
    { p: 25, min: 10000, max: 20000 },
    { p: 5, min: 50000, max: 50000 },
  ],
  boostJumlah: [
    { min: 1, p: 100 },
  ],
  zonkPct: 8,
};

/** "520:78" -> kirim 520 ke atas dapat peluang 78%. */
function bacaBoostJumlah(teks) {
  return String(teks || "")
    .split(/[\n;]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((baris) => {
      const bag = baris.split(/[:=]/).map((y) => Number(String(y).replace(",", ".").trim()));
      return {
        min: Number.isFinite(bag[0]) ? Math.max(0, Math.floor(bag[0])) : 0,
        p: Number.isFinite(bag[1]) ? Math.max(0, Math.min(100, bag[1])) : 0,
      };
    })
    .filter((r) => r.p > 0)
    .sort((a, b) => a.min - b.min);
}

function teksBoostJumlah(rows) {
  return (Array.isArray(rows) ? rows : [])
    .map((r) => `${Number(r.min) || 0}:${Number(r.p) || 0}`)
    .join("\n");
}

function ringkasBoostJumlah(rows) {
  if (!rows.length) return '<div class="catatan">Belum ada baris. Semua jumlah dianggap 100% dapat cashback.</div>';
  const isi = rows
    .map((r, i) => {
      const sampe = rows[i + 1] ? rows[i + 1].min - 1 : null;
      const rentang = sampe == null ? `${rupiah(r.min)} ke atas` : `${rupiah(r.min)} - ${rupiah(sampe)}`;
      return `<tr><td>${rentang}</td><td>${String(r.p).replace(".", ",")}%</td></tr>`;
    })
    .join("");
  return `<table style="margin-top:8px"><tr><th>JUMLAH KIRIM</th><th>PELUANG DAPAT</th></tr>${isi}</table>`;
}

function bacaTierCashback(teks) {
  return String(teks || "")
    .split(/[\n;]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((baris) => {
      const bag = baris.split(/[:=]/).map((y) => Number(String(y).replace(",", ".").trim()));
      return {
        p: Number.isFinite(bag[0]) ? Math.max(0, bag[0]) : 0,
        min: Number.isFinite(bag[1]) ? Math.max(0, Math.floor(bag[1])) : 0,
        max: Number.isFinite(bag[2]) ? Math.max(0, Math.floor(bag[2])) : 0,
      };
    })
    .filter((r) => r.p > 0 && r.max > 0);
}

function teksTierCashback(tiers) {
  return (Array.isArray(tiers) ? tiers : [])
    .map((r) => `${Number(r.p) || 0}:${Number(r.min) || 0}:${Number(r.max) || 0}`)
    .join("\n");
}

/** Tabel peluang + rata-rata coin yang masuk per satu gift. */
function ringkasCashback(tiers) {
  const total = tiers.reduce((a, b) => a + b.p, 0);
  if (!total) return '<div class="catatan">Belum ada kelompok undian.</div>';
  const isi = tiers
    .map((r) => {
      const pct = (r.p / total) * 100;
      const rendah = r.min === r.max ? rupiah(r.min) : `${rupiah(r.min)} - ${rupiah(r.max)}`;
      const rata = (r.min + r.max) / 2;
      return `<tr><td>${pct.toFixed(1).replace(".", ",")}%</td><td>${rendah}</td><td>${rupiah(Math.round(rata))}</td></tr>`;
    })
    .join("");
  const peluang = tiers.reduce((a, b) => a + ((b.p / total) * ((b.min + b.max) / 2)), 0);
  return `<table style="margin-top:8px"><tr><th>PELUANG</th><th>CASHBACK</th><th>RATA-RATA</th></tr>${isi}</table>
    <div class="catatan">Rata-rata cashback per gift: <b>${rupiah(Math.round(peluang))} coin</b>, berapa pun harga giftnya.</div>`;
}

/* ---- Model persen: "pengali:bobot", mis. "10:0.3" ---- */
function bacaKurva(teks) {
  // Menerima "3 : 1:10", "3:10", "x3 1/10", "3 = 10" - semuanya jadi {m, n}.
  return String(teks || "")
    .split(/[\n;]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((baris) => {
      const angka = (baris.match(/\d+(?:[.,]\d+)?/g) || []).map((v) => Number(String(v).replace(",", ".")));
      if (angka.length < 2) return { m: 0, n: 0 };
      const m = angka[0];
      let n = angka[1];
      // Bentuk "1:N" menghasilkan tiga angka (m, 1, N): buang angka 1 di tengah.
      if (angka.length >= 3 && angka[1] === 1) n = angka[2];
      return { m: Math.max(0, m), n: Math.max(1, n) };
    })
    .filter((r) => r.m > 0 && r.n > 0)
    .sort((a, b) => a.m - b.m);
}

function teksKurva(rows) {
  return (Array.isArray(rows) ? rows : []).map((r) => `${r.m} : 1:${r.n}`).join("\n");
}

function ringkasKurva(rows) {
  const ev = rows.reduce((a, r) => a + r.m / r.n, 0);
  const dapat = rows.reduce((a, r) => a + 100 / r.n, 0);
  return `Rata-rata hadiah <b>${ev.toFixed(2)}x</b> nilai gift. Peluang dapat sesuatu <b>${dapat.toFixed(1)}%</b>, sisanya zonk.`;
}

function bacaTierPersen(teks) {
  return String(teks || "")
    .split(/[\n;]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((baris) => {
      const bag = baris.split(/[:=]/).map((y) => Number(String(y).replace(",", ".").trim()));
      return {
        m: Number.isFinite(bag[0]) ? Math.max(0, bag[0]) : 0,
        w: Number.isFinite(bag[1]) ? Math.max(0, bag[1]) : 0,
      };
    })
    .filter((r) => r.w > 0)
    .sort((a, b) => a.m - b.m);
}

function teksTierPersen(rows) {
  return (Array.isArray(rows) ? rows : [])
    .map((r) => `${Number(r.m) || 0}:${Number(r.w) || 0}`)
    .join("\n");
}

/** Tabel peluang + rata-rata RTP dari model persen (per harga gift 100.000). */
function ringkasTierPersen(rows, capPct, recvPct, diamondPct, kembaliPct = 0) {
  const total = rows.reduce((a, b) => a + b.w, 0);
  if (!total) return '<div class="catatan">Belum ada tingkatan.</div>';
  const contoh = 100000;
  // Sama seperti server: batas tidak boleh memotong tingkatan tertinggi.
  const tertinggi = rows.reduce((a, r) => Math.max(a, Number(r.m) || 0), 0);
  const capPakai = Math.max(Number(capPct) || 0, tertinggi * 100);
  const batas = (contoh * capPakai) / 100;
  let rtp = 0;
  const isi = rows
    .map((r) => {
      const pct = (r.w / total) * 100;
      const penuh = contoh * r.m;
      const dapat = Math.min(penuh, batas);
      rtp += (r.w / total) * (dapat / contoh);
      return `<tr><td>${(r.m > 0 && r.m < 1 ? Math.round(r.m * 100) + "%" : "x" + r.m)}</td>
        <td>${pct.toFixed(2).replace(".", ",")}%</td>
        <td>${rupiah(dapat)}</td></tr>`;
    })
    .join("");
  // Peluang dapat (bukan zonk) = bobot semua tingkatan selain pengali 0.
  const totalBobot = rows.reduce((a, b) => a + b.w, 0);
  const bobotMenang = rows.filter((r) => Number(r.m) > 0).reduce((a, b) => a + b.w, 0);
  const peluangMenang = totalBobot > 0 ? bobotMenang / totalBobot : 0;
  const biayaKembali = peluangMenang * ((Number(kembaliPct) || 0) / 100) * 100;
  const totalKeluar = (rtp * 100) + (Number(recvPct) || 0) + (Number(diamondPct) || 0) + biayaKembali;
  return `<table style="margin-top:8px"><tr><th>PENGALI</th><th>PELUANG</th><th>CONTOH GIFT 100.000</th></tr>${isi}</table>
    <div class="catatan">Cashback rata-rata <b>${(rtp * 100).toFixed(1).replace(".", ",")}%</b> dari harga gift. Pengembalian harga gift saat menang menambah <b>${biayaKembali.toFixed(1).replace(".", ",")}%</b>. Kalau penerima dapat <b>${Number(recvPct) || 0}%</b> ditambah ${Number(diamondPct) || 0}% diamond, total keluar <b>${totalKeluar.toFixed(1).replace(".", ",")}%</b>, jadi platform ${totalKeluar > 100 ? "rugi " : "pegang "}${Math.abs(100 - totalKeluar).toFixed(1).replace(".", ",")}%.${totalKeluar > 100 ? " Turunkan persen penerima atau bobot pengali besar." : ""}</div>`;
}

async function gambarCashback() {
  let cfg = CB_BAWAAN;
  let galat = "";
  try {
    const sn = await dGet(dRef(rtdb, "pub/_cashbackCfg"));
    if (sn.exists()) cfg = Object.assign({}, CB_BAWAAN, sn.val() || {});
  } catch (e) { galat = e.message || String(e); }
  const tiers = Array.isArray(cfg.tiers) && cfg.tiers.length ? cfg.tiers : CB_BAWAAN.tiers;
  const boost = Array.isArray(cfg.boostJumlah) ? cfg.boostJumlah : CB_BAWAAN.boostJumlah;
  const persenAktif = cfg.modePersen !== false;
  const capPct = Number(cfg.capPct ?? 12000) || 12000;
  const tierP = Array.isArray(cfg.tiersPersen) && cfg.tiersPersen.length ? cfg.tiersPersen : CB_BAWAAN.tiersPersen;

  $("aksiTopbar").innerHTML = '<button class="tombolAtas" id="simpanCashback">Simpan</button>';
  $("isiHal").innerHTML = `
    <div class="panel" style="max-width:700px">
      <div class="panelAtas"><h3>Cashback gift</h3><div class="sub">persen dan rentang nominal</div></div>
      <div class="panelIsi">
        <div class="catatan">Ditulis ke <b>pub/_cashbackCfg</b> dan langsung dipakai server dompet, tanpa build ulang aplikasi. Peluang menurut jumlah kirim: baris <b>520:78</b> berarti mulai kirim 520 buah, peluang dapat cashback 78%. Zonk dibuat jarang lewat kolom <b>Peluang zonk (%)</b> (bawaan 8%, jadi 92% kiriman dapat cashback). Kalau tabel jumlah diisi angka di bawah 100, angka itu yang dipakai. Tiap kelompok undian ditulis <b>persen:minimal:maksimal</b>, mis. <b>70:1000:5000</b> berarti 70% dapat cashback acak 1.000 sampai 5.000. Nominal tidak dikali harga gift. Baris terakhir dianggap jackpot.</div>
        ${galat ? `<div class="catatan">${aman(galat)}</div>` : ""}
        <div class="barisIsian" style="margin-top:10px">
          <div class="isian"><label>Cashback aktif</label>
            <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="cbOn" ${cfg.on === false ? "" : "checked"} style="width:auto">aktif</label>
          </div>
          <div class="isian"><label>Bagian penerima gift (%)</label><input id="cbRecv" type="number" min="0" max="100" value="${Number(cfg.recvPct) || 0}"></div>
          <div class="isian"><label>Diamond penerima gift cashback (%)</label><input id="cbDiamond" type="number" min="0" max="100" step="0.5" value="${Number(cfg.diamondPct ?? 5)}"></div>
          <div class="isian"><label>Diamond penerima gift biasa (%)</label><input id="cbDiamondBiasa" type="number" min="0" max="100" step="0.5" value="${Number(cfg.diamondBiasaPct ?? 100)}"></div>
          <div class="isian"><label>Cashback dasar min (%)</label><input id="cbMinPct" type="number" min="0" max="100" step="0.5" value="${Number(cfg.cbMinPct ?? 1)}"></div>
          <div class="isian"><label>Cashback dasar maks (%)</label><input id="cbMaxPct" type="number" min="0" max="100" step="0.5" value="${Number(cfg.cbMaxPct ?? 20)}"></div>
          <div class="isian"><label>Kembalikan harga gift saat menang (%)</label><input id="cbKembali" type="number" min="0" max="100" step="5" value="${Number(cfg.kembaliPct ?? 100)}"></div>
          <div class="isian"><label>Kiriman bebas zonk mulai jumlah (0 = mati)</label><input id="cbBebasZonk" type="number" min="0" max="999" step="1" value="${Number(cfg.bebasZonkMulai ?? 100)}"></div>
          <div class="isian"><label>Peluang zonk (%)</label><input id="cbZonk" type="number" min="0" max="90" value="${Number(cfg.zonkPct ?? 8) || 0}"></div>
        </div>
        <div class="barisIsian" style="margin-top:12px">
          <div class="isian"><label>Model persen (harga gift x pengali)</label>
            <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="cbPersen" ${persenAktif ? "checked" : ""} style="width:auto">pakai model persen</label>
          </div>
          <div class="isian"><label>Batas cashback (% dari nilai gift)</label><input id="cbCap" type="number" min="100" max="100000" value="${capPct}"></div>
        </div>
        <div class="isian" style="margin-top:12px">
          <label>Kurva JP (pengali : 1 dari berapa kiriman)</label>
          <textarea id="cbKurva" rows="9" style="width:100%;font-family:monospace">${aman(teksKurva(Array.isArray(cfg.jpKurva) && cfg.jpKurva.length ? cfg.jpKurva : CB_BAWAAN.jpKurva))}</textarea>
          <div class="isian" style="margin-top:6px"><label>Kurva JP aktif</label>
            <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="cbKurvaOn" ${cfg.kurvaAktif === false ? "" : "checked"} style="width:auto">pakai kurva 1:N</label>
          </div>
          <div class="isian" style="margin-top:6px"><label>Cara pilih pengali</label>
            <select id="cbKurvaMode">
              <option value="acak" ${String(cfg.kurvaMode || "kurva") === "acak" ? "selected" : ""}>Acak rata (sekali klik bisa x10)</option>
              <option value="kurva" ${String(cfg.kurvaMode || "kurva") === "kurva" ? "selected" : ""}>Ikut kurva 1:N (besar makin jarang)</option>
            </select>
          </div>
          <div id="cbKurvaRin"></div>
        </div>
        <div class="isian" style="margin-top:12px">
          <label>Tingkatan persen (pengali:bobot, satu per baris)</label>
          <textarea id="cbPersenTiers" rows="6" style="width:100%;font-family:monospace">${aman(teksTierPersen(tierP))}</textarea>
          <div id="cbPersenRin">${ringkasTierPersen(tierP, capPct, cfg.recvPct, cfg.diamondPct ?? 5, cfg.kembaliPct ?? 100)}</div>
        </div>
        <div class="catatan" style="margin-top:14px">Cadangan model nominal tetap (tidak ikut harga gift). Dipakai kalau model persen dimatikan.</div>
        <div class="isian" style="margin-top:12px">
          <label>Peluang menurut jumlah kirim (jumlah:persen, satu per baris)</label>
          <textarea id="cbBoost" rows="4" style="width:100%;font-family:monospace">${aman(teksBoostJumlah(boost))}</textarea>
          <div id="cbBoostRin">${ringkasBoostJumlah(boost)}</div>
        </div>
        <div class="isian" style="margin-top:12px">
          <label>Kelompok undian (persen:minimal:maksimal, satu per baris)</label>
          <textarea id="cbTiers" rows="5" style="width:100%;font-family:monospace">${aman(teksTierCashback(tiers))}</textarea>
        </div>
        <div id="cbRin">${ringkasCashback(tiers)}</div>
      </div>
    </div>`;

  const elBoost = $("cbBoost");
  elBoost.oninput = () => { $("cbBoostRin").innerHTML = ringkasBoostJumlah(bacaBoostJumlah(elBoost.value)); };
  const el = $("cbTiers");
  el.oninput = () => { $("cbRin").innerHTML = ringkasCashback(bacaTierCashback(el.value)); };
  const elP = $("cbPersenTiers");
  const elCap = $("cbCap");
  const segarkanPersen = () => {
    $("cbPersenRin").innerHTML = ringkasTierPersen(
      bacaTierPersen(elP.value),
      Number(elCap.value) || 0,
      Number($("cbRecv").value) || 0,
      Number($("cbDiamond").value) || 0,
      Number($("cbKembali").value) || 0,
    );
  };
  elP.oninput = segarkanPersen;
  elCap.oninput = segarkanPersen;
  $("cbRecv").oninput = segarkanPersen;
  $("cbDiamond").oninput = segarkanPersen;
  $("cbKembali").oninput = segarkanPersen;

  $("simpanCashback").onclick = async () => {
    const kurva = bacaKurva($("cbKurva").value);
    if (!kurva.length) return toast("Isi kurva JP, mis. 3 : 1:10", true);
    if (kurva.every((r) => r.n <= 1)) return toast("Kurva JP belum benar. Tulis mis. 3 : 1:10", true);
    const tiers = bacaTierCashback($("cbTiers").value);
    if (!tiers.length) return toast("Isi minimal satu kelompok undian", true);
    const tierPersen = bacaTierPersen($("cbPersenTiers").value);
    if ($("cbPersen").checked && !tierPersen.length) return toast("Isi tingkatan persen dulu", true);
    const baru = {
      on: $("cbOn").checked,
      modePersen: $("cbPersen").checked,
      capPct: Math.max(100, Math.min(100000, Number($("cbCap").value) || 12000)),
      tiersPersen: tierPersen.length ? tierPersen : CB_BAWAAN.tiersPersen,
      recvPct: Math.max(0, Math.min(100, Number($("cbRecv").value) || 0)),
      // Penerima gift cashback: 70% coin + diamond (bawaan 5%) dari harga gift.
      diamondPct: Math.max(0, Math.min(100, Number($("cbDiamond").value) || 0)),
      // Gift biasa: bawaan 100% (seluruh nilai jadi diamond). Ubah ke 5 kalau
      // ingin semua gift hanya 5% ke diamond.
      diamondBiasaPct: Math.max(0, Math.min(100, Number($("cbDiamondBiasa").value) || 0)),
      // Saat menang, harga gift dikembalikan sebanyak ini. Zonk tetap hangus.
      // Cashback dasar 1-20% dari nilai gift, lalu dikali pengali JP kalau kena.
      cbMinPct: Math.max(0, Math.min(100, Number($("cbMinPct").value) || 0)),
      cbMaxPct: Math.max(0, Math.min(100, Number($("cbMaxPct").value) || 0)),
      kembaliPct: Math.max(0, Math.min(100, Number($("cbKembali").value) || 0)),
      // Mulai jumlah kirim ini, zonk dibatalkan dan harga gift dikembalikan.
      bebasZonkMulai: Math.max(0, Math.min(999, Number($("cbBebasZonk").value) || 0)),
      jpKurva: kurva,
      kurvaAktif: $("cbKurvaOn").checked,
      kurvaMode: $("cbKurvaMode").value === "acak" ? "acak" : "kurva",
      tiers: tiers,
      boostJumlah: bacaBoostJumlah($("cbBoost").value),
      zonkPct: Math.max(0, Math.min(90, Math.floor(Number($("cbZonk").value) || 0))),
    };
    try {
      // Disimpan lewat server dompet (kunci layanan), bukan langsung dari browser:
      // aturan RTDB menolak tulisan dari panel, jadi dulu muncul PERMISSION_DENIED.
      await walletAdmin({ op: "cb_cfg_set", cfg: baru });
      catatLog("Atur cashback gift", tiers.map((t) => `${t.p}% ${t.min}-${t.max}`).join(" | "));
      toast("Pengaturan cashback disimpan");
      gambarCashback();
    } catch (e) { toast("Gagal menyimpan: " + (e.code || e.message), true); }
  };
}

const daftarHal = {
  dashboard: { judul: "Dashboard", crumb: "Dashboard", gambar: gambarDashboard },
  user: { judul: "Kelola user", crumb: "Dashboard / User", gambar: gambarUser },
  room: { judul: "Kelola room", crumb: "Dashboard / Room", gambar: gambarRoom },
  gift: { judul: "Kelola gift", crumb: "Dashboard / Gift", gambar: gambarGift },
  cashback: { judul: "Cashback gift", crumb: "Dashboard / Gift", gambar: gambarCashback },
  frame: { judul: "Frame & banner", crumb: "Dashboard / Frame & banner", gambar: gambarFrame },
  kirim: { judul: "Kirim ke user", crumb: "Dashboard / Kirim ke user", gambar: gambarKirim },
  staf: { judul: "Staf & seller", crumb: "Dashboard / Staf & seller", gambar: gambarStaf },
  wallet: { judul: "Coin, diamond & reset", crumb: "Dashboard / Coin, diamond & reset", gambar: gambarWallet },
  cekin: { judul: "Cek in harian", crumb: "Dashboard / Cek in harian", gambar: gambarCekIn },
  vipharga: { judul: "Harga VIP", crumb: "Dashboard / Harga VIP", gambar: gambarVip },
  family: { judul: "Family", crumb: "Dashboard / Family", gambar: gambarFamily },
  aset: { judul: "Aset & VIP", crumb: "Dashboard / Aset & VIP", gambar: gambarAset },
  asetvps: { judul: "Aset di VPS", crumb: "Dashboard / Aset di VPS", gambar: gambarAsetVps },
  emote: { judul: "Emote room", crumb: "Dashboard / Emote room", gambar: gambarEmote },
  katalog: { judul: "Katalog game", crumb: "Dashboard / Game", gambar: gambarKatalog },
  pasang: { judul: "Pasang game", crumb: "Dashboard / Game", gambar: gambarPasang },
  bet: { judul: "Bet game", crumb: "Dashboard / Game", gambar: gambarBet },
  greedy: { judul: "Greedy King", crumb: "Dashboard / Game", gambar: gambarGreedy },
  fruit: { judul: "Crazy Fruit", crumb: "Dashboard / Game", gambar: gambarFruit },
  roket: { judul: "Roket", crumb: "Dashboard / Roket", gambar: gambarRoket },
  reward: { judul: "Reward room", crumb: "Dashboard / Reward room", gambar: gambarReward },
  database: { judul: "Database", crumb: "Dashboard / Data", gambar: gambarDatabase },
  latar: { judul: "Background tab", crumb: "Dashboard / Background tab", gambar: gambarLatar },
  cs: { judul: "Customer Service", crumb: "Dashboard / Customer Service", gambar: gambarCs },
  laporan: { judul: "Laporan user", crumb: "Dashboard / Laporan user", gambar: gambarLaporan },
  pengumuman: { judul: "Pengumuman resmi", crumb: "Dashboard / Pengumuman resmi", gambar: gambarPengumuman },
  log: { judul: "Log admin", crumb: "Dashboard / Data", gambar: gambarLog },
  pengaturan: { judul: "Pengaturan", crumb: "Dashboard / Pengaturan", gambar: gambarPengaturan }
};

const keteranganHal = {
  dashboard: "Ringkasan user, room, gift, dan aktivitas admin",
  user: "Cari user, lihat detail, blokir atau buka blokir",
  room: "Daftar room aktif dan tombol tutup room",
  gift: "Katalog gift yang tampil di aplikasi",
  cashback: "Atur persen dan rentang cashback gift",
  frame: "Banner beranda dan bingkai profil",
  kirim: "Kirim lencana, medali, frame, efek, banner, ID unik ke akun user",
  staf: "Tambah staf dan seller yang boleh masuk panel",
  cs: "Pilih akun yang menerima chat Customer Service, atau cabut",
  laporan: "Laporan user dari sheet profil room, lengkap dengan ID user yang dilaporkan",
  wallet: "Kirim coin, VIP, reset coin/diamond/exp, topup manual, reset nama dan foto",
  cekin: "Atur hadiah cek in harian hari 1 sampai 7 yang tampil di aplikasi",
  aset: "Kartu VIP, frame, efek masuk, gelembung chat, medali, ID unik",
  emote: "Emote yang tampil di bar emote dalam room",
  katalog: "Game yang sudah terpasang",
  pasang: "Tambah game baru dengan alamat dan key production",
  greedy: "Chip bet dan RTP Greedy King (75 standar, 100 sering JP)",
  fruit: "Chip bet dan RTP Crazy Fruit (92 standar, makin tinggi makin sering menang)",
  roket: "Hadiah tiap roket level 1-5 dan hadiah peringkat Top 1, Top 2, Top 3",
  reward: "Hadiah mingguan room: tabel tingkat aliran koin, banner, dan ikon",
  bet: "Atur nilai bet tiap game",
  database: "Lihat, ubah, dan hapus dokumen Firestore",
  log: "Riwayat aksi yang dilakukan admin",
  pengaturan: "Daftarkan admin panel dan atur aksesnya"
};

function bukaRute() {
  if ($("aplikasi").hidden) return;
  const nama = (location.hash.replace("#", "") || "dashboard").split("?")[0];
  // Pengaturan (mendaftarkan admin panel) hanya untuk Owner. Admin lain boleh
  // semua halaman lain, tapi tidak bisa membuat akun panel baru.
  const peranSaya = String(adminSaya?.peran || "");
  const menuPengaturan = document.querySelector('.menu[data-hal="pengaturan"]');
  if (menuPengaturan) menuPengaturan.hidden = peranSaya !== "owner";
  if (nama === "pengaturan" && peranSaya !== "owner") {
    $("judulHal").textContent = "Khusus owner";
    $("crumbHal").textContent = "Dashboard";
    document.querySelectorAll(".menu").forEach((m) => m.classList.toggle("aktif", m.dataset.hal === "dashboard"));
    $("isiHal").innerHTML = '<div class="kosong">Halaman Pengaturan hanya bisa dibuka Owner.</div>';
    return;
  }
  const hal = daftarHal[nama] || daftarHal.dashboard;
  document.querySelectorAll(".menu").forEach((m) => m.classList.toggle("aktif", m.dataset.hal === nama));
  $("judulHal").textContent = hal.judul;
  $("crumbHal").textContent = hal.crumb;
  const ket = document.getElementById("ketHal");
  if (ket) ket.textContent = keteranganHal[nama] || "";
  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = '<div class="kosong">Memuat…</div>';
  Promise.resolve(hal.gambar()).catch((e) => {
    console.error(e);
    $("isiHal").innerHTML = `<div class="kosong">Gagal memuat data.<br><b>${aman(e.code || e.message)}</b><br><br>${
      String(e.code || "").includes("permission-denied")
        ? "Aturan Firestore belum mengizinkan koleksi ini. Tempel rules terbaru dari owner lalu Publish."
        : "Periksa koneksi lalu muat ulang."
    }</div>`;
  });
}
window.addEventListener("hashchange", () => { tutupMenu(); bukaRute(); });

/* menu geser (HP) */
const sidebar = document.querySelector(".sidebar");
const tiraiMenu = $("tiraiMenu");
function tutupMenu() {
  sidebar?.classList.remove("buka");
  tiraiMenu?.classList.remove("tampil");
}
$("tombolMenu").addEventListener("click", () => {
  const buka = sidebar.classList.toggle("buka");
  tiraiMenu.classList.toggle("tampil", buka);
});
tiraiMenu.addEventListener("click", tutupMenu);
document.querySelectorAll(".menu").forEach((m) => m.addEventListener("click", tutupMenu));

/* ================= dashboard ================= */
async function gambarDashboard() {
  const [users, rooms, gifts, banned, logs] = await Promise.all([
    ambilSemua("userIds", 500), ambilSemua("rooms", 500), ambilSemua("gifts", 100),
    ambilSemua("banned", 200).catch(() => []), ambilSemua("adminLogs", 50).catch(() => [])
  ]);
  const versi = await getDoc(doc(db, "settings", "versi")).then((d) => (d.exists() ? d.data().versi : "—")).catch(() => "—");

  $("isiHal").innerHTML = `
    <div class="kartu">
      <div class="stat"><b>${rupiah(users.length)}</b><span>User terdaftar</span></div>
      <div class="stat"><b>${rupiah(rooms.length)}</b><span>Room</span></div>
      <div class="stat"><b>${rupiah(gifts.length)}</b><span>Gift aktif</span></div>
      <div class="stat"><b>${rupiah(banned.length)}</b><span>User diblokir</span></div>
      <div class="stat"><b>${aman(versi)}</b><span>Versi APK tercatat</span></div>
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Aktivitas admin terakhir</h3><div class="filter"><div class="pil on">${logs.length} catatan</div></div></div>
      ${logs.length ? `<table><tr><th>WAKTU</th><th>ADMIN</th><th>AKSI</th><th>RINCIAN</th></tr>
        ${logs.sort((a, b) => (b.waktu?.seconds || 0) - (a.waktu?.seconds || 0)).slice(0, 12).map((l) => `
          <tr><td>${waktu(l.waktu)}</td><td>${aman(l.admin)}</td><td>${aman(l.aksi)}</td><td>${aman(l.rincian)}</td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada aktivitas tercatat.</div>'}
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Room terbaru</h3><div class="filter"><div class="pil on"><a href="#room">Lihat semua</a></div></div></div>
      ${rooms.length ? `<table><tr><th>ROOM</th><th>PEMILIK</th><th>KUNCI</th></tr>
        ${rooms.slice(0, 8).map((r) => `<tr><td>${aman(r.name || r.title || r.id)}</td><td>${aman((r.ownerUid || "").slice(0, 10))}…</td>
        <td>${r.locked ? '<span class="tag blokir">terkunci</span>' : '<span class="tag aktif">terbuka</span>'}</td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada room.</div>'}
    </div>`;
}

/* ================= user ================= */
let saringUser = "semua", cariUser = "";
async function gambarUser() {
  const [users, banned] = await Promise.all([
    ambilSemua("userIds", 500),
    ambilSemua("banned", 300).catch(() => [])
  ]);
  const diblokir = new Set(banned.map((b) => b.id));

  $("aksiTopbar").innerHTML = `<input id="cariUser" class="cari" placeholder="Cari nama atau UID…">
    <button class="tombolAtas" id="tambahUser">Tambah user</button>`;
  $("tambahUser").onclick = formTambahUser;
  $("cariUser").value = cariUser;
  $("cariUser").oninput = (e) => { cariUser = e.target.value.toLowerCase(); lukisTabelUser(users, diblokir); };

  $("isiHal").innerHTML = `
    <div class="kartu">
      <div class="stat"><b>${rupiah(users.length)}</b><span>User terdaftar</span></div>
      <div class="stat"><b>${rupiah(users.length - diblokir.size)}</b><span>Aktif</span></div>
      <div class="stat"><b>${rupiah(diblokir.size)}</b><span>Diblokir</span></div>
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Daftar user</h3>
        <div class="filter">
          <div class="pil on" data-saring="semua">Semua</div>
          <div class="pil" data-saring="aktif">Aktif</div>
          <div class="pil" data-saring="blokir">Diblokir</div>
        </div>
      </div>
      <div id="tabelUser"></div>
    </div>`;

  $("isiHal").querySelectorAll("[data-saring]").forEach((p) => {
    p.onclick = () => {
      saringUser = p.dataset.saring;
      $("isiHal").querySelectorAll("[data-saring]").forEach((x) => x.classList.toggle("on", x === p));
      lukisTabelUser(users, diblokir);
    };
  });
  lukisTabelUser(users, diblokir);
}

function lukisTabelUser(users, diblokir) {
  const kata = cariUser.trim();
  let baris = users.filter((u) => {
    const nama = (u.name || u.nama || "").toLowerCase();
    if (kata && !nama.includes(kata) && !u.id.toLowerCase().includes(kata)) return false;
    if (saringUser === "blokir") return diblokir.has(u.id) || diblokir.has(u.uid);
    if (saringUser === "aktif") return !diblokir.has(u.id) && !diblokir.has(u.uid);
    return true;
  });

  const kotak = $("tabelUser");
  if (!baris.length) {
    kotak.innerHTML = '<div class="kosong">Tidak ada user yang cocok.</div>';
    return;
  }
  kotak.innerHTML = `<table>
    <tr><th>USER</th><th>UID</th><th>STATUS</th><th>AKSI</th></tr>
    ${baris.slice(0, 120).map((u) => {
      const uid = u.uid || u.id;
      const blok = diblokir.has(u.id) || diblokir.has(uid);
      const nama = u.name || u.nama || "(tanpa nama)";
      const foto = u.avatar || u.photo || "";
      return `<tr>
        <td><div class="user"><div class="mini">${foto ? `<img src="${aman(foto)}" alt="">` : aman(nama[0] || "?")}</div>${aman(nama)}</div></td>
        <td>${aman(uid.slice(0, 14))}…</td>
        <td>${blok ? '<span class="tag blokir">diblokir</span>' : '<span class="tag aktif">aktif</span>'}</td>
        <td>
          <button class="aksi" data-lihat="${aman(uid)}">Detail</button> ·
          <button class="aksi" data-ban="${aman(uid)}" data-nama="${aman(nama)}">${blok ? "Buka blokir" : "Blokir"}</button> ·
          <button class="aksi" data-hapus="${aman(uid)}" data-nama="${aman(nama)}">Hapus</button>
        </td>
      </tr>`;
    }).join("")}
  </table><div class="kaki">${baris.length} user ditampilkan dari ${users.length} terdaftar</div>`;

  kotak.querySelectorAll("[data-lihat]").forEach((b) => (b.onclick = () => detailUser(b.dataset.lihat)));
  kotak.querySelectorAll("[data-ban]").forEach((b) => (b.onclick = () => blokirUser(b.dataset.ban, b.dataset.nama, diblokir)));
  kotak.querySelectorAll("[data-hapus]").forEach((b) => (b.onclick = () => hapusUser(b.dataset.hapus, b.dataset.nama)));
}

async function formTambahUser() {
  modal("Tambah user Viza", `
    <div class="isian"><label>Nama tampilan</label><input id="uNama" placeholder="Nama user di aplikasi"></div>
    <div class="isian" style="margin-top:10px"><label>Email untuk login</label><input id="uEmail" type="email" placeholder="user@email.com"></div>
    <div class="isian" style="margin-top:10px"><label>Password</label><input id="uSandi" placeholder="minimal 6 karakter, atau kosongkan untuk otomatis"></div>
    <div class="catatan">Akun ini langsung bisa dipakai login di aplikasi Viza. Di layar login APK, user memilih masuk dengan email lalu mengisi email dan password ini. Password hanya ditampilkan sekali di panel, jadi salin dulu sebelum ditutup.</div>`,
    async () => {
      const nama = $("uNama").value.trim();
      const email = $("uEmail").value.trim().toLowerCase();
      let sandi = $("uSandi").value.trim();
      if (!nama || !email) return toast("Nama dan email wajib diisi", true);
      if (!sandi) sandi = "vz" + Math.random().toString(36).slice(2, 10);
      if (sandi.length < 6) return toast("Password minimal 6 karakter", true);

      const appKedua = initializeApp(firebaseConfig, "userbaru-" + Date.now());
      const authKedua = getAuth(appKedua);
      let uid;
      try {
        const kredensial = await createUserWithEmailAndPassword(authKedua, email, sandi);
        uid = kredensial.user.uid;
        await updateProfile(kredensial.user, { displayName: nama }).catch(() => {});
        await signOut(authKedua);
        await deleteApp(appKedua);
      } catch (e) {
        deleteApp(appKedua).catch(() => {});
        throw e;
      }

      await setDoc(doc(db, "users", uid), {
        nickname: nama, name: nama, email, countryCode: "ID",
        dibuat: serverTimestamp(), dibuatOleh: auth.currentUser.email
      }, { merge: true });

      await setDoc(doc(db, "userIds", uid), {
        uid, name: nama, countryCode: "ID", dibuat: serverTimestamp()
      }, { merge: true });

      catatLog("Tambah user", `${nama} · ${email}`);
      gambarUser();

      modal("Akun dibuat", `
        <div class="isian"><label>Email login</label><input id="hasilEmail" value="${aman(email)}" readonly></div>
        <div class="isian" style="margin-top:10px"><label>Password</label><input id="hasilSandi" value="${aman(sandi)}" readonly></div>
        <div class="isian" style="margin-top:10px"><label>UID</label><input value="${aman(uid)}" readonly></div>
        <div class="catatan">Serahkan email dan password ini ke user. Di aplikasi Viza, pilih masuk dengan email lalu isi keduanya. Minta user mengganti password setelah masuk.</div>`);
    });
}

async function detailUser(uid) {
  modal(`Detail user`, '<div class="kosong">Memuat…</div>');
  try {
    const [profil, dompet, bannya] = await Promise.all([
      getDoc(doc(db, "users", uid)).catch(() => null),
      getDoc(doc(db, "wallets", uid)).catch(() => null),
      getDoc(doc(db, "banned", uid)).catch(() => null)
    ]);
    const isi = {
      profil: profil?.exists() ? profil.data() : null,
      dompet: dompet?.exists() ? dompet.data() : null,
      diblokir: bannya?.exists() ? bannya.data() : null
    };
    modal(`Detail user ${uid.slice(0, 12)}…`, `
      <div class="isian"><label>Profil (users/${aman(uid)})</label><textarea readonly>${aman(JSON.stringify(isi.profil, null, 2) || "—")}</textarea></div>
      <div class="isian" style="margin-top:10px"><label>Dompet (wallets/${aman(uid)})</label><textarea readonly>${aman(JSON.stringify(isi.dompet, null, 2) || "—")}</textarea></div>
      ${isi.diblokir ? `<div class="isian" style="margin-top:10px"><label>Blokir</label><textarea readonly>${aman(JSON.stringify(isi.diblokir, null, 2))}</textarea></div>` : ""}
      <div class="catatan">Data dibaca langsung dari Firestore. Untuk mengubah nilai, pakai menu Database.</div>`);
  } catch (e) {
    modal("Detail user", `<div class="kosong">${aman(e.message)}</div>`);
  }
}


/** Hapus user sepenuhnya: dompet, profil Firestore, dan akun login Firebase. */
async function hapusUser(uid, nama) {
  modal("Hapus user permanen", `
    <div class="isian"><label>User</label><input value="${aman(nama)} · ${aman(uid)}" readonly></div>
    <div class="isian" style="margin-top:10px"><label>Ketik nama user untuk memastikan</label><input id="konfirHapus" placeholder="${aman(nama)}"></div>
    <div class="catatan">Profil, dompet, dan akun login Firebase user ini dihapus. User tidak bisa masuk lagi dengan akun tersebut, dan datanya tidak bisa dikembalikan.
      Saldo coin yang tersisa ikut hilang. Kalau hanya ingin menghentikan sementara, pakai Blokir.</div>`,
    async () => {
      const teks = ($("konfirHapus")?.value || "").trim().toLowerCase();
      if (teks !== String(nama).trim().toLowerCase()) return toast("Nama belum sama", true);
      const tutup = $("modalTutup");
      try {
        // 1) dompet + akun login Firebase (lewat server)
        let authInfo = "";
        try {
          const r = await walletAdmin({ op: "delete_user", uid });
          const baris = (r.hasil || [])[0] || {};
          if (baris.lewat) { toast("Akun resmi tidak boleh dihapus", true); return; }
          authInfo = baris.auth ? "akun login terhapus" : ("akun login belum terhapus: " + (baris.auth_alasan || "kunci layanan belum dipasang"));
        } catch (e) {
          authInfo = "dompet gagal dihapus: " + (e.message || e);
        }

        // 2) dokumen Firestore
        await Promise.all([
          deleteDoc(doc(db, "users", uid)).catch(() => {}),
          deleteDoc(doc(db, "userIds", uid)).catch(() => {}),
          deleteDoc(doc(db, "wallets", uid)).catch(() => {}),
          deleteDoc(doc(db, "banned", uid)).catch(() => {})
        ]);

        catatLog("Hapus user", `${nama} · ${uid} · ${authInfo}`);
        if (tutup) tutup.click();
        toast("User dihapus · " + authInfo);
        gambarUser();
      } catch (e) {
        toast("Gagal menghapus: " + (e.message || e), true);
      }
    });
}

async function blokirUser(uid, nama, diblokir) {
  const sudah = diblokir.has(uid);
  if (!sudah && !confirm(`Blokir ${nama}? Dia tidak bisa memakai aplikasi sampai dibuka.`)) return;
  try {
    if (sudah) {
      await deleteDoc(doc(db, "banned", uid));
      toast(`${nama} dibuka blokirnya`);
      catatLog("Buka blokir", `${nama} · ${uid}`);
    } else {
      await setDoc(doc(db, "banned", uid), {
        uid, nama, alasan: "diblokir admin panel",
        oleh: auth.currentUser.email, waktu: serverTimestamp()
      });
      toast(`${nama} diblokir`);
      catatLog("Blokir user", `${nama} · ${uid}`);
    }
    gambarUser();
  } catch (e) {
    toast("Gagal: " + (e.code || e.message), true);
  }
}

/* ================= room ================= */
async function gambarRoom() {
  const rooms = await ambilSemua("rooms", 400).catch(() => []);
  // Room party dibaca aplikasi dari Realtime Database (roomsPub), bukan Firestore.
  let party = {}, official = {}, gagalParty = "";
  try {
    const snap = await dGet(dRef(rtdb, "roomsPub"));
    party = snap.exists() ? snap.val() : {};
  } catch (e) { gagalParty = e.message || String(e); }
  try {
    const snap = await dGet(dRef(rtdb, "officialRooms"));
    official = snap.exists() ? snap.val() : {};
  } catch (e) { }
  const daftarParty = Object.entries(party || {})
    .map(([id, r]) => ({ id, ...(r || {}) }))
    .sort((a, b) => (Number(b.pinned) || 0) - (Number(a.pinned) || 0) || (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0));

  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = `
    <div class="kartu"><div class="stat"><b>${rupiah(rooms.length)}</b><span>Total room</span></div>
      <div class="stat"><b>${rupiah(rooms.filter((r) => !r.locked).length)}</b><span>Terbuka</span></div>
      <div class="stat"><b>${rupiah(rooms.filter((r) => r.locked).length)}</b><span>Terkunci</span></div>
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Room party</h3><div class="sub">sematkan room paling atas dan beri tag official</div></div>
      ${gagalParty ? `<div class="kosong">Gagal memuat roomsPub: ${aman(gagalParty)}</div>`
        : (daftarParty.length ? `<table><tr><th>ROOM</th><th>PEMILIK</th><th>PESERTA</th><th>ATURAN</th><th>AKSI</th></tr>
          ${daftarParty.map((r) => `<tr>
            <td>${r.official || official[r.id] ? '✅ ' : ''}${aman(r.name || "(tanpa nama)")}<div class="catatan" style="padding:0;margin-top:2px">${aman(String(r.id).slice(0, 14))}…</div></td>
            <td>${aman((r.ownerName || r.ownerUid || "—").toString().slice(0, 14))}</td>
            <td>${rupiah(r.members || 0)}</td>
            <td>${r.pinned ? '<span class="tag aktif">disematkan</span>' : '<span class="tag">biasa</span>'} ${official[r.id] ? '<span class="tag aktif">official</span>' : ''}</td>
            <td>
              <button class="aksi" data-semats="${aman(r.id)}" data-nilai="${r.pinned ? 0 : 1}">${r.pinned ? "Lepas semat" : "Sematkan"}</button> ·
              <button class="aksi" data-official="${aman(r.id)}" data-nilai="${official[r.id] ? 0 : 1}">${official[r.id] ? "Lepas official" : "Tag official"}</button>
            </td></tr>`).join("")}
          </table>` : '<div class="kosong">Belum ada room party di Realtime Database.</div>')}
      <div class="catatan" style="padding:0 14px 14px">Room yang disematkan tampil paling atas di daftar room aplikasi. Tag official memberi tanda resmi di foto room dan daftar room.</div>
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Daftar room (Firestore)</h3><div class="filter"><div class="pil on">rooms</div></div></div>
      ${rooms.length ? `<table><tr><th>NAMA</th><th>ID ROOM</th><th>PEMILIK</th><th>KUNCI</th><th>AKSI</th></tr>
        ${rooms.map((r) => `<tr>
          <td>${aman(r.name || r.title || "(tanpa nama)")}</td>
          <td>${aman(r.id.slice(0, 12))}…</td>
          <td>${aman((r.ownerUid || "—").slice(0, 12))}</td>
          <td>${r.locked ? '<span class="tag blokir">terkunci</span>' : '<span class="tag aktif">terbuka</span>'}</td>
          <td><button class="aksi" data-room="${aman(r.id)}">Tutup room</button></td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada room.</div>'}
    </div>`;

  // Sematkan / lepas sematkan (roomsPub/{id}/pinned + pinnedAt)
  $("isiHal").querySelectorAll("[data-semats]").forEach((b) => (b.onclick = async () => {
    const id = b.dataset.semats, nilai = Number(b.dataset.nilai) === 1;
    try {
      try {
        await dSet(dRef(rtdb, `roomsPub/${id}/pinned`), nilai);
        await dSet(dRef(rtdb, `roomsPub/${id}/pinnedAt`), nilai ? Date.now() : 0);
      } catch (e) {
        // Aturan RTDB menolak staf panel (hanya pemilik room/email admin yang
        // boleh). Jalur VPS memakai akun layanan, jadi semat tetap tersimpan.
        await walletAdmin({ op: "room_pin", uid: id, nilai: nilai ? 1 : 0 });
      }
      catatLog(nilai ? "Sematkan room" : "Lepas semat room", id);
      toast(nilai ? "Room disematkan paling atas" : "Semat dilepas");
      gambarRoom();
    } catch (e) { toast("Gagal: " + (e.message || "tidak diizinkan rules"), true); }
  }));

  // Tag official (officialRooms/{id})
  $("isiHal").querySelectorAll("[data-official]").forEach((b) => (b.onclick = async () => {
    const id = b.dataset.official, nilai = Number(b.dataset.nilai) === 1;
    try {
      try {
        await dSet(dRef(rtdb, `officialRooms/${id}`), nilai ? true : null);
      } catch (e) {
        // Staf panel tidak boleh menulis officialRooms langsung; pakai akun layanan.
        await walletAdmin({ op: "room_official", uid: id, nilai: nilai ? 1 : 0 });
      }
      catatLog(nilai ? "Tag official" : "Lepas official", id);
      toast(nilai ? "Tag official dipasang" : "Tag official dilepas");
      gambarRoom();
    } catch (e) { toast("Gagal: " + (e.message || "tidak diizinkan rules"), true); }
  }));

  $("isiHal").querySelectorAll("[data-room]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Tutup dan hapus room ini? Tindakan ini langsung terasa di aplikasi.")) return;
    try {
      await deleteDoc(doc(db, "rooms", b.dataset.room));
      catatLog("Hapus room", b.dataset.room);
      toast("Room dihapus");
      gambarRoom();
    } catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  }));
}

/* ================= gift ================= */
/** Jenis media gift dari alamat berkasnya: svga, video, gif, atau image. */
function jenisMediaGift(url) {
  const bersih = String(url || "").split("?")[0].toLowerCase();
  const ext = bersih.split(".").pop();
  if (ext === "svga") return "svga";
  if (["mp4", "webm", "mov", "m4v"].includes(ext)) return "video";
  if (ext === "gif") return "gif";
  if (!ext || !bersih.includes(".")) return "";
  return "image";
}

const contohGift = { name: "", emoji: "🎁", icon: "", price: 100, mediaUrl: "", mediaType: "", special: false, rocket: false, cashback: false, jpRate: 0, jpMult: 0, cbRate: 0, cbPrice: 0 };

async function gambarGift() {
  const gifts = await ambilSemua("gifts", 300);
  $("aksiTopbar").innerHTML = `<button class="tombolAtas" id="tambahGift">Tambah gift</button>`;
  $("tambahGift").onclick = () => formGift(null);
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Katalog gift</h3><div class="sub">dibaca aplikasi dari koleksi gifts</div>
        <div class="filter"><div class="pil on">${gifts.length} item</div></div></div>
      ${gifts.length ? `<table><tr><th>GIFT</th><th>HARGA</th><th>MEDIA</th><th>TAMBAHAN</th><th>AKSI</th></tr>
        ${gifts.map((g) => `<tr>
          <td><div class="user"><div class="mini">${g.icon ? `<img src="${aman(g.icon)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%">` : aman(g.emoji || "🎁")}</div>${aman(g.name || g.id)}</div></td>
          <td>${rupiah(g.price)} koin</td>
          <td>${g.mediaUrl ? `<a class="aksi" href="${aman(g.mediaUrl)}" target="_blank" rel="noopener">${aman(g.mediaType || "tautan")}</a>` : "—"}</td>
          <td>${[g.special && "special", g.rocket && "rocket", g.cashback && "cashback"].filter(Boolean).map((t) => `<span class="tag aktif">${t}</span>`).join(" ") || "—"}</td>
          <td><button class="aksi" data-edit="${aman(g.id)}">Edit</button> · <button class="aksi" data-hapus="${aman(g.id)}">Hapus</button></td>
        </tr>`).join("")}</table>` : '<div class="kosong">Belum ada gift. Tekan Tambah gift di kanan atas.</div>'}
    </div>`;
  $("isiHal").querySelectorAll("[data-edit]").forEach((b) => (b.onclick = () => formGift(gifts.find((g) => g.id === b.dataset.edit))));
  $("isiHal").querySelectorAll("[data-hapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus gift ini dari katalog?")) return;
    try {
      await deleteDoc(doc(db, "gifts", b.dataset.hapus));
      catatLog("Hapus gift", b.dataset.hapus);
      toast("Gift dihapus");
      gambarGift();
    } catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  }));
}

function formGift(gift) {
  const g = { ...contohGift, ...(gift || {}) };
  modal(gift ? "Edit gift" : "Tambah gift", `
    <div class="grid2">
      <div class="isian"><label>Nama gift</label><input id="gNama" value="${aman(g.name)}" placeholder="Mawar"></div>
      <div class="isian"><label>Emoji</label><input id="gEmoji" value="${aman(g.emoji)}" placeholder="🌹"></div>
      <div class="isian"><label>Harga (koin)</label><input id="gHarga" type="number" value="${Number(g.price) || 0}"></div>
      <div class="isian"><label>Jenis media</label><select id="gJenis">
        ${["", "image", "gif", "svga", "video"].map((t) => `<option value="${t}" ${g.mediaType === t ? "selected" : ""}>${t || "(tanpa media)"}</option>`).join("")}
      </select></div>
    </div>
    <div class="isian" style="margin-top:10px">
      <label>Ikon gift 1:1 (opsional, dari perangkat atau tautan)</label>
      ${htmlSumber("gi", g.icon, "image/png,image/jpeg,image/webp")}
      <div class="catatan">Kosongkan saja. Kalau berkas media di bawah berupa SVGA atau MP4, ikon PNG 1:1 dibuat otomatis dari frame animasinya, sama seperti unggah frame di Store. Isi kolom ini hanya kalau ingin ikon sendiri.</div>
    </div>
    <div style="margin-top:10px">${htmlSumber("g", g.mediaUrl)}
      <div class="catatan">Berkas media yang diputar saat gift dikirim: SVGA, MP4, GIF, atau PNG. Untuk SVGA, ikon tab Hadiah dibuat otomatis dari frame pertama.</div></div>
    <div class="grid3" style="margin-top:10px">
      <div class="isian"><label>Jackpot rate</label><input id="gJp" type="number" value="${Number(g.jpRate) || 0}"></div>
      <div class="isian"><label>Jackpot multiplier</label><input id="gJpMult" type="number" value="${Number(g.jpMult) || 0}"></div>
      <div class="isian"><label>Cashback rate</label><input id="gCb" type="number" value="${Number(g.cbRate) || 0}"></div>
    </div>
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>Harga dasar cashback</label><input id="gCbHarga" type="number" value="${Number(g.cbPrice) || 0}"></div>
      <div class="isian"><label>Penanda</label>
        <div style="display:flex;gap:12px;padding-top:6px;font-size:11px;color:#a4aebf">
          <label style="display:flex;gap:5px;align-items:center;margin:0"><input type="checkbox" id="gSpecial" ${g.special ? "checked" : ""} style="width:auto">special</label>
          <label style="display:flex;gap:5px;align-items:center;margin:0"><input type="checkbox" id="gRocket" ${g.rocket ? "checked" : ""} style="width:auto">rocket</label>
          <label style="display:flex;gap:5px;align-items:center;margin:0"><input type="checkbox" id="gCashback" ${g.cashback ? "checked" : ""} style="width:auto">cashback</label>
        </div>
      </div>
    </div>
    <div class="catatan">Nama dokumen: <b>${aman(gift?.id || "otomatis")}</b>. Perubahan langsung terbaca aplikasi saat katalog gift dimuat ulang.</div>`,
    async () => {
      const mediaUrl = await urlDariSumber("g", "gift");
      // Ikon tab Hadiah: pakai berkas ikon kalau diunggah sendiri. Kalau tidak,
      // ikon PNG dibuat otomatis dari frame animasi SVGA/MP4 (seperti frame Store).
      let ikon = "";
      try { ikon = await urlDariSumber("gi", "gift"); } catch (e) { ikon = ""; }
      const jenisMedia = jenisMediaGift(mediaUrl);
      if (!ikon && mediaUrl && (jenisMedia === "svga" || jenisMedia === "video")) {
        const mediaBerubah = !gift || (gift.mediaUrl || "") !== mediaUrl;
        if (mediaBerubah || !g.icon) {
          ikon = await buatSampul(mediaUrl, jenisMedia === "video" ? "video" : "svga", "gift");
          if (ikon) toast("Ikon PNG dibuat otomatis dari animasi gift");
        }
      }
      if (!ikon) ikon = g.icon || "";
      const data = {
        name: $("gNama").value.trim(),
        emoji: $("gEmoji").value.trim() || "🎁",
        icon: ikon,
        price: Number($("gHarga").value) || 0,
        mediaUrl: mediaUrl,
        mediaType: jenisMedia || $("gJenis").value,
        special: $("gSpecial").checked,
        rocket: $("gRocket").checked,
        cashback: $("gCashback").checked,
        jpRate: Number($("gJp").value) || 0,
        jpMult: Number($("gJpMult").value) || 0,
        cbRate: Number($("gCb").value) || 0,
        cbPrice: Number($("gCbHarga").value) || 0,
        diperbarui: serverTimestamp()
      };
      if (!data.name) return toast("Nama gift wajib diisi", true);
      const idGift = gift?.id || `gift_${Date.now()}`;
      await setDoc(doc(db, "gifts", idGift), data, { merge: true });
      // Salin ke Realtime Database supaya aplikasi dan server dompet membaca data
      // yang sama (server butuh penanda cashback untuk hitung diamond 5%).
      try {
        await dSet(dRef(rtdb, "giftCfg/" + idGift), {
          name: data.name, emoji: data.emoji, icon: data.icon || "",
          price: data.price, mediaUrl: data.mediaUrl || "", mediaType: data.mediaType || "",
          special: !!data.special, rocket: !!data.rocket, cashback: !!data.cashback,
          jpRate: data.jpRate, jpMult: data.jpMult, cbRate: data.cbRate, cbPrice: data.cbPrice,
        });
      } catch (e) { toast("Tersimpan, tapi gagal salin ke RTDB: " + (e.message || e), true); }
      catatLog(gift ? "Edit gift" : "Tambah gift", data.name);
      toast("Gift disimpan");
      gambarGift();
    });
}

/* ================= frame & banner ================= */
async function gambarFrame() {
  const [banners, frames] = await Promise.all([
    ambilSemua("banners", 100).catch(() => []),
    ambilSemua("frames", 100).catch(() => [])
  ]);
  $("aksiTopbar").innerHTML = `<button class="tombolAtas" id="tambahBanner">Tambah banner</button>`;
  $("tambahBanner").onclick = () => formBanner(null);
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Banner beranda</h3><div class="sub">koleksi banners</div>
        <div class="filter"><div class="pil on">${banners.length} banner</div></div></div>
      ${banners.length ? `<table><tr><th>JUDUL</th><th>GAMBAR</th><th>URUTAN</th><th>STATUS</th><th>AKSI</th></tr>
        ${banners.map((b) => `<tr>
          <td>${aman(b.title || "(tanpa judul)")}<div style="font-size:10px;color:#6d778a">${aman(b.subtitle || "")}</div></td>
          <td>${b.imageUrl || b.imageB64 ? `<a class="aksi" href="${aman(b.imageUrl || "#")}" target="_blank" rel="noopener">lihat</a>` : "—"}</td>
          <td>${Number(b.order) || 0}</td>
          <td>${b.active === false ? '<span class="tag blokir">nonaktif</span>' : '<span class="tag aktif">tampil</span>'}</td>
          <td><button class="aksi" data-bedit="${aman(b.id)}">Edit</button> · <button class="aksi" data-bhapus="${aman(b.id)}">Hapus</button></td>
        </tr>`).join("")}</table>` : '<div class="kosong">Belum ada banner.</div>'}
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Frame profil</h3><div class="sub">koleksi frames</div>
        <div class="filter"><div class="pil" id="tambahFrame">+ Tambah frame</div></div></div>
      ${frames.length ? `<table><tr><th>FRAME</th><th>GAMBAR</th><th>HARGA</th><th>STATUS</th><th>AKSI</th></tr>
        ${frames.map((f) => `<tr>
          <td>${aman(f.name || f.id)}</td>
          <td>${f.imageUrl ? `<a class="aksi" href="${aman(f.imageUrl)}" target="_blank" rel="noopener">lihat</a>` : "—"}</td>
          <td>${rupiah(f.price)} koin</td>
          <td>${f.active === false ? '<span class="tag blokir">nonaktif</span>' : '<span class="tag aktif">aktif</span>'}</td>
          <td><button class="aksi" data-fedit="${aman(f.id)}">Edit</button> · <button class="aksi" data-fhapus="${aman(f.id)}">Hapus</button></td>
        </tr>`).join("")}</table>` : '<div class="kosong">Belum ada frame di koleksi frames.<br>Tambahkan, lalu aplikasi bisa memakainya setelah build berikutnya.</div>'}
      <div class="catatan" style="padding:0 14px 14px">File gambar tidak disimpan di panel. Unggah gambar ke hosting (Firebase Storage, GitHub, atau server VPS), lalu tempel tautannya di sini.</div>
    </div>`;

  $("tambahFrame").onclick = () => formFrame(null);
  $("isiHal").querySelectorAll("[data-bedit]").forEach((b) => (b.onclick = () => formBanner(banners.find((x) => x.id === b.dataset.bedit))));
  $("isiHal").querySelectorAll("[data-bhapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus banner ini?")) return;
    await deleteDoc(doc(db, "banners", b.dataset.bhapus)).then(() => { toast("Banner dihapus"); catatLog("Hapus banner", b.dataset.bhapus); gambarFrame(); })
      .catch((e) => toast("Gagal: " + (e.code || e.message), true));
  }));
  $("isiHal").querySelectorAll("[data-fedit]").forEach((b) => (b.onclick = () => formFrame(frames.find((x) => x.id === b.dataset.fedit))));
  $("isiHal").querySelectorAll("[data-fhapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus frame ini?")) return;
    await deleteDoc(doc(db, "frames", b.dataset.fhapus)).then(() => { toast("Frame dihapus"); gambarFrame(); })
      .catch((e) => toast("Gagal: " + (e.code || e.message), true));
  }));
}

function formBanner(b) {
  const d = b || { title: "", subtitle: "", imageUrl: "", link: "", order: 0, active: true };
  modal(b ? "Edit banner" : "Tambah banner", `
    <div class="isian"><label>Judul</label><input id="bJudul" value="${aman(d.title)}"></div>
    <div class="isian" style="margin-top:10px"><label>Subjudul</label><input id="bSub" value="${aman(d.subtitle)}"></div>
    <div style="margin-top:10px">${htmlSumber("b", d.imageUrl)}</div>
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>Tautan saat diketuk</label><input id="bLink" value="${aman(d.link)}"></div>
      <div class="isian"><label>Urutan</label><input id="bOrder" type="number" value="${Number(d.order) || 0}"></div>
    </div>
    <div class="isian" style="margin-top:10px"><label>Tampilkan</label>
      <div class="saklar ${d.active !== false ? "on" : ""}" id="bAktif"></div></div>`,
    async () => {
      const gambarBanner = await urlDariSumber("b", "banner");
      await setDoc(doc(db, "banners", b?.id || `banner_${Date.now()}`), {
        title: $("bJudul").value.trim(), subtitle: $("bSub").value.trim(),
        imageUrl: gambarBanner, link: $("bLink").value.trim(),
        order: Number($("bOrder").value) || 0, active: $("bAktif").classList.contains("on"),
        diperbarui: serverTimestamp()
      }, { merge: true });
      catatLog(b ? "Edit banner" : "Tambah banner", $("bJudul").value);
      toast("Banner disimpan");
      gambarFrame();
    }, () => $("bAktif").classList.toggle("on"));
}

function formFrame(f) {
  const d = f || { name: "", imageUrl: "", price: 0, active: true };
  modal(f ? "Edit frame" : "Tambah frame", `
    <div class="isian"><label>Nama frame</label><input id="fNama" value="${aman(d.name)}" placeholder="SVIP 6"></div>
    <div style="margin-top:10px">${htmlSumber("f", d.imageUrl)}</div>
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>Harga (koin)</label><input id="fHarga" type="number" value="${Number(d.price) || 0}"></div>
      <div class="isian"><label>Aktif</label><div class="saklar ${d.active !== false ? "on" : ""}" id="fAktif"></div></div>
    </div>`,
    async () => {
      const gambarFrame = await urlDariSumber("f", "frame");
      await setDoc(doc(db, "frames", f?.id || `frame_${Date.now()}`), {
        name: $("fNama").value.trim(), imageUrl: gambarFrame,
        price: Number($("fHarga").value) || 0, active: $("fAktif").classList.contains("on"),
        diperbarui: serverTimestamp()
      }, { merge: true });
      toast("Frame disimpan");
      gambarFrame();
    }, () => $("fAktif").classList.toggle("on"));
}

/* ================= staf & seller ================= */
const PERAN_PANEL = ["owner", "admin", "manager", "moderator", "staf", "seller"];
/* ================= Panel Staf (manager / admin di APK) — sama seperti Rezo ================= */
const fmtKoin = (n) => {
  const v = Number(n) || 0;
  if (v >= 1e12) return (v / 1e12).toFixed(v % 1e12 ? 2 : 0) + " T";
  if (v >= 1e9) return (v / 1e9).toFixed(v % 1e9 ? 2 : 0) + " M";
  if (v >= 1e6) return (v / 1e6).toFixed(v % 1e6 ? 1 : 0) + " jt";
  return v.toLocaleString("id-ID");
};
const pstCacheProfil = new Map();
async function pstUid(dariId) {
  const mentah = String(dariId || "").trim();
  if (!mentah) throw new Error("Isi ID user dulu");
  const uid = await uidDariMasukan(mentah);
  if (!uid) throw new Error("ID " + mentah + " tidak ditemukan");
  return { uid, id: mentah };
}
async function pstProfil(uid) {
  if (pstCacheProfil.has(uid)) return pstCacheProfil.get(uid);
  let nama = "", id = "";
  try { const s = await dGet(dRef(rtdb, "pub/" + uid)); if (s.exists()) { nama = s.val().name || ""; id = s.val().userId || ""; } } catch (e) { }
  if (!nama) { try { const d = await getDoc(doc(db, "users", uid)); if (d.exists()) { nama = d.data().name || d.data().nickname || ""; id = id || d.data().userId || ""; } } catch (e) { } }
  const hasil = { nama, id };
  pstCacheProfil.set(uid, hasil);
  return hasil;
}
let pstItemCache = null;
async function pstItems() {
  if (pstItemCache) return pstItemCache;
  const semua = await ambilSemua("vipConfig", 500).catch(() => []);
  pstItemCache = semua.filter((d) => d.id && !d.meta && (d.slot === "frame" || d.slot === "entry"))
    .map((d) => ({ id: "sx_" + d.id, kind: d.slot, name: d.name || d.id, days: Number(d.days) || 30 }))
    .sort((a, b) => (a.kind === b.kind ? String(a.name).localeCompare(String(b.name)) : (a.kind === "frame" ? -1 : 1)));
  return pstItemCache;
}

async function gambarStaf() {
  const tampilSeller = window.__pstTampilCabut === true;
  let seller = null, galatSeller = "";
  try { seller = (await walletAdmin({ op: "seller_list" })).seller || []; } catch (e) { galatSeller = e.message || String(e); }
  const staf = await ambilSemua("panelAdmins", 200).catch(() => []);
  const items = await pstItems().catch(() => []);

  $("aksiTopbar").innerHTML = '<button class="tombolAtas" id="tambahSeller">Tambah seller</button>';
  $("tambahSeller").onclick = () => formSeller(null);

  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Kirim panel ke user</h3></div>
      <div style="padding:0 14px 14px">
        <div class="catatan" style="padding:0 0 10px">Panel muncul di tab Saya user itu. Manager: coin, VIP, frame/efek, blokir user, reset nama dan foto. Admin: VIP, frame/efek, blokir user biasa.</div>
        <div class="isian"><label>ID user (angka)</label><input id="pstId" inputmode="numeric"></div>
        <div class="isian" style="margin-top:10px"><label>Manager dari admin (khusus admin, isi ID manager)</label><input id="pstMgr" placeholder="kosongkan untuk manager"></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
          <button class="tombolUtama" id="pstManager">Kirim panel manager</button>
          <button class="tombol polos" id="pstAdmin">Kirim panel admin</button>
          <button class="tombol polos bahaya" id="pstCabut">Cabut panel user ini</button>
        </div>
        <div class="catatan" id="pstStatus" style="padding:8px 0 0"></div>
      </div>
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Stok frame &amp; efek masuk</h3></div>
      <div style="padding:0 14px 14px">
        <div class="catatan" style="padding:0 0 10px">Item di sini yang bisa dikirim manager/admin ke user lewat panel di aplikasi.</div>
        <div class="isian"><label>ID staf penerima stok (angka)</label><input id="pstStokId" inputmode="numeric"></div>
        <div class="isian" style="margin-top:10px"><label>Pilih item</label><select id="pstItem">
          ${items.length ? items.map((x) => `<option value="${aman(x.id)}">${x.kind === "frame" ? "⭕" : "✨"} ${aman(x.name)}</option>`).join("") : '<option value="">Belum ada item frame/efek di Aset &amp; VIP</option>'}
        </select></div>
        <div class="isian" style="margin-top:10px"><label>Durasi untuk user (hari)</label><input id="pstHari" type="number" value="30"></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
          <button class="tombolUtama" id="pstTambahStok">Tambah ke stok</button>
          <button class="tombol polos" id="pstMuatStok">Muat stok staf ini</button>
        </div>
        <div id="pstStokDaftar" class="catatan" style="padding:10px 0 0"></div>
      </div>
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Stok coin staf</h3></div>
      <div style="padding:0 14px 14px">
        <div class="catatan" style="padding:0 0 10px">Manager hanya bisa kirim coin dari stok ini. Kalau habis, manager tidak bisa kirim lagi sampai Anda tambah.</div>
        <div class="isian"><label>ID staf (angka)</label><input id="pstCoinId" inputmode="numeric"></div>
        <div class="isian" style="margin-top:10px"><label>Peran</label><select id="pstCoinPeran">
          <option value="manager">Manager (bisa kirim coin)</option><option value="admin">Admin</option></select></div>
        <div class="isian" style="margin-top:10px"><label>Jumlah coin (boleh angka besar, contoh 5000000000)</label><input id="pstCoinN" inputmode="numeric" value="1000000000"></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
          <button class="tombolUtama" id="pstCoinTambah">Tambah stok</button>
          <button class="tombol polos" id="pstCoinSet">Set stok</button>
          <button class="tombol polos bahaya" id="pstCoinNol">Nolkan stok</button>
        </div>
        <div class="catatan" id="pstCoinStatus" style="padding:8px 0 0"></div>
      </div>
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Daftar staf</h3><button class="tombolAtas" id="pstToggle">${tampilSeller ? "Sembunyikan yang sudah dicabut" : "Tampilkan yang sudah dicabut"}</button></div>
      <div id="pstDaftar" style="padding:0 14px 14px">Memuat…</div>
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Seller coin</h3><div class="sub">yang muncul di tab Saya sebagai Panel Seller</div></div>
      ${galatSeller ? `<div class="kosong">Gagal memuat daftar seller: ${aman(galatSeller)}<br>Tombol <b>Tambah seller</b> di kanan atas tetap bisa dicoba.</div>`
        : (seller && seller.length ? `<table>
            <tr><th>SELLER</th><th>TOKO</th><th>WHATSAPP</th><th>STOK COIN</th><th>STATUS</th><th>AKSI</th></tr>
            ${seller.map((s) => `<tr>
              <td>${aman(s.name || s.uid)}</td><td>${aman(s.store || "-")}</td><td>${aman(s.wa || "-")}</td>
              <td>${fmtKoin(s.stock ?? s.coins ?? 0)}</td>
              <td>${s.active ? '<span class="tag aktif">aktif</span>' : '<span class="tag blokir">nonaktif</span>'}</td>
              <td><button class="aksi" data-selstok="${aman(s.uid)}" data-stok="${Number(s.stock ?? s.coins ?? 0)}">Stok</button> ·
                  <button class="aksi" data-selaktif="${aman(s.uid)}" data-nilai="${s.active ? 0 : 1}">${s.active ? "Nonaktifkan" : "Aktifkan"}</button> ·
                  <button class="aksi" data-seledit="${aman(s.uid)}">Edit</button> ·
                  <button class="aksi" data-selhapus="${aman(s.uid)}">Hapus</button></td>
            </tr>`).join("")}</table>` : '<div class="kosong">Belum ada seller terdaftar di dompet.</div>')}
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Akses panel developer</h3><div class="sub">siapa yang boleh membuka web panel ini (bukan jabatan di aplikasi)</div>
        <button class="tombolAtas" id="tambahStaf">Tambah staf panel</button></div>
      ${staf.length ? `<table><tr><th>NAMA</th><th>EMAIL</th><th>PERAN</th><th>STATUS</th><th>AKSI</th></tr>
        ${staf.map((s) => `<tr><td>${aman(s.nama || s.name || s.id)}</td><td>${aman(s.email || s.id)}</td><td>${aman(s.role || "staf")}</td>
          <td>${s.aktif === false ? '<span class="tag blokir">nonaktif</span>' : '<span class="tag aktif">aktif</span>'}</td>
          <td><button class="aksi" data-sedit="${aman(s.id)}">Edit</button> · <button class="aksi" data-shapus="${aman(s.id)}">Hapus</button></td></tr>`).join("")}</table>`
        : '<div class="kosong">Belum ada staf panel.</div>'}
    </div>`;

  const say = (id, teks) => { const e = $(id); if (e) e.textContent = teks; };

  // ---- kirim / cabut panel (panel_grant, panel_revoke di server dompet) ----
  const kirim = async (peran) => {
    const tombol = peran === "manager" ? $("pstManager") : $("pstAdmin");
    tombol.disabled = true; say("pstStatus", "Memproses…");
    try {
      const u = await pstUid($("pstId").value);
      let manager = "";
      if (peran === "admin" && $("pstMgr").value.trim()) manager = (await pstUid($("pstMgr").value)).uid;
      await walletAdmin({ op: "panel_grant", uid: u.uid, role: peran, manager });
      // cermin per UID untuk APK yang membaca langsung dari Firestore
      await setDoc(doc(db, "stafApk", u.uid), { uid: u.uid, jabatanApk: peran, aktif: true, diperbarui: serverTimestamp() }, { merge: true }).catch(() => {});
      catatLog("Kirim panel " + peran, "ID " + u.id);
      say("pstStatus", "Panel " + peran + " dikirim ke ID " + u.id + " ✅ (muncul di tab Saya)");
      gambarStaf();
    } catch (e) { say("pstStatus", "Gagal: " + (e.message || e)); }
    tombol.disabled = false;
  };
  $("pstManager").onclick = () => kirim("manager");
  $("pstAdmin").onclick = () => kirim("admin");
  $("pstCabut").onclick = async () => {
    if (!confirm("Cabut panel user ini?")) return;
    try {
      const u = await pstUid($("pstId").value);
      await walletAdmin({ op: "panel_revoke", uid: u.uid });
      await deleteDoc(doc(db, "stafApk", u.uid)).catch(() => {});
      catatLog("Cabut panel", "ID " + u.id);
      say("pstStatus", "Panel ID " + u.id + " dicabut ✅");
      gambarStaf();
    } catch (e) { say("pstStatus", "Gagal: " + (e.message || e)); }
  };

  // ---- stok frame & efek ----
  const muatStok = async (uid) => {
    const kotak = $("pstStokDaftar"); kotak.textContent = "Memuat stok…";
    try {
      const r = await walletAdmin({ op: "panel_stock_list", uid });
      const daftar = r.list || [];
      if (!daftar.length) { kotak.textContent = "Stok staf ini masih kosong."; return; }
      kotak.innerHTML = daftar.map((x) => `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #232c3c">
        <span>${x.kind === "frame" ? "⭕" : "✨"} ${aman(x.name || x.item_id)} · ${aman(String(x.days))} hari</span>
        <button class="aksi" data-hapusitem="${aman(x.item_id)}">Hapus</button></div>`).join("");
      kotak.querySelectorAll("[data-hapusitem]").forEach((b) => (b.onclick = async () => {
        try { await walletAdmin({ op: "panel_stock_del", uid, itemId: b.dataset.hapusitem }); muatStok(uid); }
        catch (e) { toast("Gagal: " + e.message, true); }
      }));
    } catch (e) { kotak.textContent = "Gagal memuat stok: " + e.message; }
  };
  $("pstTambahStok").onclick = async () => {
    const tombol = $("pstTambahStok"); tombol.disabled = true;
    try {
      const u = await pstUid($("pstStokId").value);
      const id = $("pstItem").value; if (!id) throw new Error("Pilih item dulu");
      const it = items.find((x) => x.id === id) || { kind: "", name: id, days: 30 };
      const hari = parseInt($("pstHari").value, 10) || it.days;
      await walletAdmin({ op: "panel_stock_add", uid: u.uid, itemId: id, kind: it.kind, name: it.name, days: hari });
      catatLog("Stok item staf", "ID " + u.id + " · " + it.name);
      toast("Item masuk ke stok ID " + u.id);
      muatStok(u.uid);
    } catch (e) { toast("Gagal: " + (e.message || e), true); }
    tombol.disabled = false;
  };
  $("pstMuatStok").onclick = async () => { try { muatStok((await pstUid($("pstStokId").value)).uid); } catch (e) { toast(e.message, true); } };

  // ---- stok coin staf ----
  const coin = async (op, nol) => {
    try {
      const u = await pstUid($("pstCoinId").value);
      const n = nol ? 0 : Math.trunc(Number(String($("pstCoinN").value).replace(/[^0-9]/g, "")) || 0);
      const r = await walletAdmin({ op, uid: u.uid, coins: n, role: $("pstCoinPeran").value });
      say("pstCoinStatus", "Stok coin ID " + u.id + " sekarang " + fmtKoin(r.coins) + " coin");
      catatLog("Stok coin staf", "ID " + u.id + " · " + op);
      gambarStaf();
    } catch (e) { say("pstCoinStatus", "Gagal: " + (e.message || e)); }
  };
  $("pstCoinTambah").onclick = () => coin("panel_coin_add", false);
  $("pstCoinSet").onclick = () => coin("panel_coin_set", false);
  $("pstCoinNol").onclick = () => { if (confirm("Nolkan stok coin staf ini?")) coin("panel_coin_set", true); };

  // ---- daftar staf (panel_list) ----
  $("pstToggle").onclick = () => { window.__pstTampilCabut = !window.__pstTampilCabut; gambarStaf(); };
  (async () => {
    const kotak = $("pstDaftar");
    try {
      let r = null, galat = null;
      for (let c = 0; c < 3 && !r; c++) {
        try { r = await walletAdmin({ op: "panel_list" }); }
        catch (e) { galat = e; if (/Belum login|Hanya admin|Token tidak valid/i.test(String(e.message))) break; await new Promise((s) => setTimeout(s, 900 * (c + 1))); }
      }
      if (!r) throw galat || new Error("tidak ada jawaban");
      const semua = r.list || [];
      const tampil = semua.filter((x) => tampilSeller || x.active);
      if (!tampil.length) { kotak.textContent = semua.length ? "Semua staf sudah dicabut." : "Belum ada staf. Kirim panel ke user di atas."; return; }
      kotak.innerHTML = "";
      for (const x of tampil) {
        const baris = document.createElement("div");
        baris.style.cssText = "display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #232c3c";
        baris.innerHTML = `<div style="flex:1"><b class="pnama">memuat…</b><div class="catatan pinfo" style="padding:0"></div></div>
          <button class="aksi" data-stokstaf="${aman(x.uid)}">Stok</button> <button class="aksi" data-cabutstaf="${aman(x.uid)}" data-peran="${aman(x.role)}">Cabut</button>`;
        kotak.appendChild(baris);
        pstProfil(x.uid).then((pp) => {
          baris.querySelector(".pnama").textContent = (pp.nama || "Pengguna tanpa nama") + " · " + (x.role === "manager" ? "Manager" : "Admin");
          baris.querySelector(".pinfo").textContent = "ID " + (pp.id || "-") + (x.active ? "" : " · dicabut") + " · " + (x.stok || 0) + " item · coin " + fmtKoin(x.coins || 0);
        });
        baris.querySelector("[data-stokstaf]").onclick = () => { $("pstStokId").value = ""; muatStok(x.uid); window.scrollTo({ top: 0, behavior: "smooth" }); };
        baris.querySelector("[data-cabutstaf]").onclick = async () => {
          if (!confirm("Cabut panel " + x.role + " milik user ini?")) return;
          try { await walletAdmin({ op: "panel_revoke", uid: x.uid, role: x.role }); await deleteDoc(doc(db, "stafApk", x.uid)).catch(() => {}); toast("Panel " + x.role + " dicabut"); baris.remove(); }
          catch (e) { toast("Gagal: " + e.message, true); }
        };
      }
    } catch (e) { kotak.innerHTML = "Gagal memuat staf: " + aman(e.message || String(e)); }
  })();

  // ---- seller ----
  const daftarSeller = seller || [];
  $("isiHal").querySelectorAll("[data-seledit]").forEach((b) => (b.onclick = () => formSeller(daftarSeller.find((x) => String(x.uid) === b.dataset.seledit))));
  $("isiHal").querySelectorAll("[data-selstok]").forEach((b) => (b.onclick = () => formStokSeller(b.dataset.selstok, Number(b.dataset.stok || 0))));
  $("isiHal").querySelectorAll("[data-selhapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus seller ini dari daftar dompet?")) return;
    try { await walletAdmin({ op: "seller_del", uid: b.dataset.selhapus }); catatLog("Hapus seller", b.dataset.selhapus); toast("Seller dihapus"); gambarStaf(); }
    catch (e) { toast("Gagal: " + e.message, true); }
  }));
  $("isiHal").querySelectorAll("[data-selaktif]").forEach((b) => (b.onclick = async () => {
    try { await walletAdmin({ op: "seller_set_active", uid: b.dataset.selaktif, active: Number(b.dataset.nilai) }); toast("Status seller diubah"); gambarStaf(); }
    catch (e) { toast("Gagal: " + e.message, true); }
  }));

  // ---- akses panel developer ----
  $("tambahStaf").onclick = () => formStaf(null);
  $("isiHal").querySelectorAll("[data-sedit]").forEach((b) => (b.onclick = () => formStaf(staf.find((x) => x.id === b.dataset.sedit))));
  $("isiHal").querySelectorAll("[data-shapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus akses web panel untuk akun ini?")) return;
    await deleteDoc(doc(db, "panelAdmins", b.dataset.shapus))
      .then(() => { catatLog("Hapus staf panel", b.dataset.shapus); toast("Akses dihapus"); gambarStaf(); })
      .catch((e) => toast("Gagal: " + (e.code || e.message), true));
  }));
}

/** Daftarkan atau ubah seller dompet (muncul di aplikasi). */
function formSeller(s) {
  const d = s || { uid: "", store: "", wa: "", link: "" };
  modal(s ? "Edit seller" : "Tambah seller", `
    <div class="isian"><label>ID user calon seller (ID angka, ID unik, atau UID)</label><input id="selUid" value="${aman(d.uid || "")}" ${s ? "readonly" : ""} placeholder="923146051900"></div>
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>Nama toko</label><input id="selToko" value="${aman(d.store || "")}" placeholder="Toko Coin Contoh"></div>
      <div class="isian"><label>Nomer HP / WhatsApp</label><input id="selWa" value="${aman(d.wa || "")}" placeholder="6281234567890"></div>
    </div>
    <div class="isian" style="margin-top:10px"><label>Link WhatsApp (kosongkan untuk dibuat otomatis dari nomer)</label><input id="selLink" value="${aman(d.link || "")}" placeholder="https://wa.me/6281234567890"></div>
    ${s ? "" : '<div class="isian" style="margin-top:10px"><label>Stok coin awal (opsional)</label><input id="selStok" type="number" value="0"></div>'}
    <div class="catatan">Setelah disimpan, seller langsung tampil di daftar seller pada aplikasi dan di dompet. Stok coin awal dipotong dari saldo coin akun panelmu.</div>`,
    async () => {
      const masukan = $("selUid").value.trim();
      const uid = s ? d.uid : await uidDariMasukan(masukan);
      if (!uid) return toast("ID user tidak ditemukan", true);
      const nomer = $("selWa").value.replace(/[^0-9]/g, "");
      let link = $("selLink").value.trim();
      if (!link && nomer) link = "https://wa.me/" + (nomer.startsWith("0") ? "62" + nomer.slice(1) : nomer);
      await walletAdmin({
        op: "seller_save", uid,
        store: $("selToko").value.trim(),
        wa: nomer,
        link,
        active: 1
      });
      const stok = Number($("selStok")?.value || 0);
      if (stok > 0) await walletAdmin({ op: "seller_stock", uid, mode: "add", coins: stok });
      catatLog(s ? "Edit seller" : "Tambah seller", `${$("selToko").value.trim() || uid}${stok ? " · stok " + stok : ""}`);
      toast("Seller disimpan" + (stok ? ", stok coin ditambahkan" : ""));
      gambarStaf();
    });
}

/** Tambah atau potong stok coin seller. */
function formStokSeller(uid, stokSekarang) {
  modal("Stok coin seller", `
    <div class="catatan" style="margin-bottom:10px">Stok coin sekarang: <b>${fmtKoin(Number(stokSekarang || 0))}</b> coin</div>
    <div class="isian"><label>Jumlah coin</label><input id="stokNilai" type="number" value="100000"></div>
    <div class="filter" style="margin-top:12px">
      <div class="pil on" data-mode="add">Tambah stok</div>
      <div class="pil" data-mode="cut">Potong stok</div>
    </div>
    <div class="catatan">Menambah stok memotong saldo coin milik akun panelmu. Memotong stok mengembalikan coin ke saldo panel.</div>`,
    async () => {
      const mode = document.querySelector('[data-mode].on')?.dataset.mode || "add";
      const n = Math.abs(Number($("stokNilai").value) || 0);
      if (!n) return toast("Isi jumlah coin", true);
      await walletAdmin({ op: "seller_stock", uid, mode, coins: n });
      catatLog("Stok seller", `${mode} ${n} · ${uid}`);
      toast("Stok seller diperbarui");
      gambarStaf();
    },
    (e) => {
      const pil = e && e.target && e.target.closest("[data-mode]");
      if (pil) document.querySelectorAll("[data-mode]").forEach((x) => x.classList.toggle("on", x === pil));
    });
}

function formStaf(d) {
  const s = d || { nama: "", email: "", role: "staf", aktif: true };
  modal(d ? "Edit staf" : "Tambah staf / seller", `
    <div class="grid2">
      <div class="isian"><label>Nama</label><input id="sNama" value="${aman(s.nama || s.name)}"></div>
      <div class="isian"><label>Email untuk login panel</label><input id="sEmail" value="${aman(s.email || (d ? d.id : ""))}" ${d ? "readonly" : ""}></div>
    </div>
    ${d ? "" : '<div class="isian" style="margin-top:10px"><label>Password (opsional, dibuatkan akun login)</label><input id="sSandi" placeholder="kosongkan kalau akun sudah ada"></div>'}
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>Peran</label><select id="sPeran">
        ${PERAN_PANEL.map((p) => `<option value="${p}" ${(s.role || "staf") === p ? "selected" : ""}>${p}</option>`).join("")}
      </select></div>
      <div class="isian"><label>Boleh masuk panel</label><div class="saklar ${s.aktif !== false ? "on" : ""}" id="sAktif"></div></div>
    </div>
    <div class="isian" style="margin-top:10px"><label>Jabatan di APK (bukan akses panel)</label><select id="sJabatan">
      ${["tidak ada", "seller", "manager", "admin"].map((j) => `<option value="${j}" ${((s.jabatanApk || "tidak ada") === j) ? "selected" : ""}>${j}</option>`).join("")}
    </select></div>
    <div class="catatan">Jabatan di APK membuat menu Panel muncul di aplikasi: seller lihat daftar seller, manager bisa kirim coin, blokir user, reset nama/foto, dan kirim aset Store, admin sama seperti manager.</div>`,
    async () => {
      const nama = $("sNama").value.trim();
      const email = $("sEmail").value.trim().toLowerCase();
      const jabatan = ($("sJabatan")?.value || "tidak ada");
      if (!nama || !email) return toast("Nama dan email wajib diisi", true);
      const sandi = ($("sSandi")?.value || "").trim();
      let catatanAkun = "";
      if (sandi) {
        try {
          const app2 = getApps().find((x) => x.name === "panelKedua") || initializeApp(firebaseConfig, "panelKedua");
          await createUserWithEmailAndPassword(getAuth(app2), email, sandi);
          await signOut(getAuth(app2));
          catatanAkun = " · akun login dibuat";
        } catch (e) { catatanAkun = " · akun login: " + (e.code || e.message); }
      }
      const jabatanApk = ($("sJabatan")?.value || "tidak ada");
      await setDoc(doc(db, "panelAdmins", email), {
        nama, email, role: $("sPeran").value, jabatanApk,
        aktif: $("sAktif").classList.contains("on")
      }, { merge: true });
      catatLog(d ? "Edit staf" : "Tambah staf", `${nama} · ${$("sPeran").value}`);
      toast("Staf disimpan" + catatanAkun);
      gambarStaf();
    }, () => $("sAktif").classList.toggle("on"));
}

/** Stok yang dipakai menu Panel di APK: coin dan daftar item yang boleh dikirim. */
async function formStokPanel(email) {
  const id = String(email || "").toLowerCase();
  let sekarang = { coins: 0, aset: [] };
  try {
    const d = await getDoc(doc(db, "panelStok", id));
    if (d.exists()) sekarang = d.data() || sekarang;
  } catch (e) { }
  const asetTeks = (sekarang.aset || []).map((a) => (typeof a === "string" ? a : (a && a.id) || "")).filter(Boolean).join(", ");
  modal("Stok panel " + id, `
    <div class="isian"><label>Stok coin untuk kirim coin ke user</label>
      <input id="stCoin" value="${sekarang.coins || 0}" inputmode="numeric"></div>
    <div class="isian" style="margin-top:10px"><label>Item yang boleh dikirim (ID item, pisah koma)</label>
      <textarea id="stAset" rows="3" placeholder="frame_gold, medal_1">${aman(asetTeks)}</textarea></div>
    <div class="catatan">Menu Panel di APK membaca stok ini. Kalau stok coin 0, manager bebas kirim coin tanpa batas.</div>`,
    async () => {
      const coins = Number(($("stCoin").value || "0").replace(/[^0-9]/g, "")) || 0;
      const aset = ($("stAset").value || "").split(",").map((x) => x.trim()).filter(Boolean);
      await setDoc(doc(db, "panelStok", id), { coins, aset, email: id, diperbarui: serverTimestamp() }, { merge: true });
      catatLog("Stok panel", `${id} · ${coins} coin · ${aset.length} item`);
      toast("Stok disimpan");
      gambarStaf();
    });
}

/* ================= foto bawaan (sama dengan aset APK) ================= */
const FOTO_BAWAAN = {
  M: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCABpAGkDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKQnFAC0xpFHTmo3lLcDpUJOaTdhpExmJ74prEnqTXj/7QX7S/w/8A2ffDcms+KL6F5yP3Nru+eT8MV8Kah/wWQnGsuLDwdbHT84Hmtlv5Uk7j2P1JpysR0Jr82PH3/BX/AMMQeCbG58DeGWbxDdB/OhmO9ISOnHfPPWvlO9/4Km/tLXOrDUF8R7IAwYWwHyce3ahKwz91RKR3zUiyBuO9fD37Hv8AwUK8NfGXQpLP4h3drpOq2KgSSudolPc4r6z8L/EvwJ4y+Xw54osL2TGdkcwJoTuJo7GiolkwcHpUgIYZFNO5ItFFFMAqCR8nAqSRsDHrVVjzQxpCkjFZPibxHpnhPRLrX9YnWG0s4zJIzHHArUryb9qLwvrXi/4Na/omhiQ3Ets5ATvgd6i9xn40/t9/tCr8afinOdGvjJplmzRRgHIJBOf1NfLNb/jjwrrnhPxJe6Xr1nLBcxTOh3jG4g8msECqRD1GkZprL71Yt7S5u5PLtoJJG9FUnH5VabQtYTGdOn5/2DScktyrNkFhquo6W5k0+8kgY9ShxmvcP2W/jn4/8C/FPSTp+vTtBd3CJLE7naw3dP1rxq28M67fSiG20ydn9Nh/pX0/+yD+yL8S/H/j7StbudCnttOt7hXaSQFRgHP454pc0Xsymmj9zvCV/LrHhvTtUuMLJdW6SMAe5Fb0bHODWH4e00aPotlpi9LaBI+PUDmtaPvRtqQW6KZG25fcU+rArXDZfA7CoqfJ95j6mmVEhpBTZkSVSjqGRhgqRkEU6igo/Gr/AIKcfDc3fx60fT9B01Yft7eSjIPvMSO3/wBevO/F/wDwT88X6B4HHiDS75L2/SEzyW0Z+cj0A5z3/Sv0H/4KNfDRrnwZZfFHR7QNf+HbhLlto5ZAcn/ODXP/AAR+MfhX4s+ELO80y8ikuVhX7XbswLo+OT9K+a4hx+Ly+MKmH21v+B9FkWAwuPnKniN9LHzH+wF8EfD1/wCDvEWs+OfDAmvo9TSCFrhPuqqZIH4n+VfVx+Bvwuc7pPCNk3/AK7K003TdMhMGm2MNsjMXYRIFDMe5xVlT6cV+f47Nq2Mryrczjfoj7rA5XRwtFUeVO3VnG2Xwd+Gdi++28I2KZxkbetfUXwr07TNL8NQQaZp8NsoReUUZPFeIZ9697+H0Ji0GHPeNa97hPETliZc0m9Dw+KaFOlho8sUtTqRSg4oHQ0lfo60Pz8nhbDY9anquowwPoasVSdyClSU5htYj0NNqSwooooA5T4p+DLPx/wCAtZ8K3sKypfWkkQDDIyRX5zfswfsjat8EfHfibxH4unDXInltbCONhgxFj85wT27HB5NfqFcD9xJz/Ca+dfGAxr1wCMdP618pxbiKlDCqEHZS0Z9RwzQp1sW5zV3FXRiO0cePMkRc9NxxmhWA7ZqtrGl2+sWbWVyPlbkEdVPYg9Qa4e4t/iH4duo0s7xr+ykYIFf5nVM4x+v6V+YqN3ZH6LKVkejwp5soj6Z74r6J8MWrWWj29vIPmCDNcj4M+GtpbJa6pdzNPKybxvHCk16HsCcAYxX6Zw1k1fL+arWt7y0PzriLNaeMcaVPox45opQMAikr60+XJVBqzVcfeA9TVinBWRBXmXEm71FQ1cddwqpjBwaGNMSorm7tbKIz3dxHCg7scVx3xM+Knhz4caTPd394gmVSY13Y3EdR/KviL4rftK+LfHVzLb2N21pYsSAkTYOPevr+HODMfxE+emuWHdnkZjnVDALllrLsfXniv9o/4ceHbiTT5NSW4cfKzRt8oyPpzXnN5rVt4gu5dTtpS6SsSCa+JJ7ie5cyXEruzHJLHJra0nxz4k0fC22oO0Y6KxzivouL/A15rh6awFa04782z/yM+G/ECGWVpTxNO6fbofXeaWR9gzjNfLP/AAtjxX0Nx+v/ANaq938SfE13F5cl8y57ivzyl9HnPpzSqVoJd9T7Wp4r5XyPkpyb7H3h4b/aH8CoYdE1DUfKuIVEbg9sd/fNep6drFjq1ul3YXEc0TjIZGz+Y7V+S895NLKZ2lZnbruOa9N+Gfx/8VeALpV+1zz2uR8jSbgvrwa/U8T4R1cJgofVa3NUS1TW/p2PzePF0K+Kk68OWLenkfpSG3A8UlebfCn40+HfiXp8bW00cV3sBeLfkg16SDk8CvyjHYKvgKzoYiLjJH1dGtCvDng9CxGMtn0qamouBTq5loigrP1a5TTrOe/dSywoXIHfFaFV7+yh1Gzmsbld0U6FHHqDVwcVJc23UT20PzE+N/xG1Dxx4uvG+1sbOKQrGgPA5rzcDFfUH7QH7K2s6Fc3XijwpEk1iSZJI0U5XucgA18xywTW8zQTxtHIjYZWGCDX9a8M43LsZlsP7OknFJJrqn5o/J81p4mGLbxKs3+JHRk0UV9Ijzjs9H0XwxcfDTVNZv73y9fhukitoQcF0IXJHrgHP4e9ccR05rstGuvCA+FmtWN/p8p197xGt5F5VIvlyT9cN+dcWhPOTXl5dOc6lfmb0lpftZbeRvidOTbboFOB45pDT7e3nupkt7aJpJZDtRFGSTXptpK7Oe3NodZ8NPHGq+CfElrqFhdtEquNwzwRX6deB9bj8UeGdP8AECIUF5Csm0jpkV8dfAL9lbUdauIPEPjGCWG2Vgywsm3cMeuc/wAq+29L0yz0ewh02whWKCBQqKowAK/njxNzTLcfioU8I+apH4mtvQ/QeGcLiqNNyraReyLdFFFflh9UFFFFADZI45UMcqK6sMEMMg1418Uv2W/h98SBJdpE+l6gwOJ7cLyffIJr2eiu7AZli8rqqtg6jhLyMK+Go4qPJWimvM/Pfxz+xf8AFnw5JJN4dtoNftFBK+RKFlPttOMn8q8g1n4dePvD0jx654K1yxMfDGewlVR/wIrg/nX6z0V+kYHxazPDwUMVSjU89Yv52uvwPnK/CeFm70puP4/8H8T8q9L8XWmm/DjV/h3J4SE+qahdLcxXxXEtugCEqBjOMJj6MaytD+GfxB8SSLHoHgrXL7eQA0NhKyD6tjaPxNfrTRW9PxWnhlP6tg0nJ8zvNvWyW1l22TMnwpGbXtKzdtNrafez8+PBX7FPxW8QvHP4jht9CtmAYiaQNLjuNozg9PWvqL4X/su/D34c+XeNaJqOoJ/y8TIDg+2eRXstFfKZzx3nWdRdKpU5IP7MdF83dt/eetg8iweCfPGPNLu9f+AMiijhQRxIqKowABgAU+iivjdz2QooooA//9k=",
  F: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCABpAGkDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKQkAZNAC00sBUTyE8Cg80AOMme+KQsOpb8zUFzd21nGZbiVUQDOSa+efiv8W7+9vJtF0S4EUK5DOnBPp/Wvns/wCI8Lw9hvrGI16JLds9vJsjxGdV/Y0dF1fRHu0/inw1byGG41mzRx1HmipLXxP4fu38q01i2lfH3UkBNfFFxeXs0hle5cuepJNFvqeoWz+ZHdSBh0OTX5jHxdlf3qCa9WffPw1TWld39P8Agn3Us24BlIYGpA4NfNXw4+NeoadMNP8AEE5lgbCo7Hp+NfQunajbanaJeWkgeNxkEGv03h/iXA8RUvaYaWvVPdHwOdZFisjqcuJWnRrZmlRUatjrTwc19EeILRRRQAVGzZ4pzHAqOgAPSsTxX4gi8N6LNqEj7dnetonNeS/H24lj0JI42xvcZrx8/wAdLL8uq4iC1S0PWyfBRx2Np0J7NnjXif4ia/rl5K4vXSJz0BxmuVLs7F3JLMcknuakZQTwKYV9TX8r43HYjMKrqYibk/M/onC4SjhIezoxSQ0rupDFt7Vv6X4P1bWNKbVLBA6RuY2X3AB6/jRH4P16SQIbMjPfNJZXjJJSVNtPayI+v4ZScXNXWjMBBg17b8D/AB/PDN/wj95OWjwPL3GuCl+Gevx2hutucfw7f/r1h6bLd6PqYcExyRMM8V7WT18dwxj6WJnFxT3TWjR5Oa0cJn2DqUISUmtvJn20rqyhgcgjNKp2nrwa5/wnqD6loVrPI252jUk/hW+pyK/qLD1o4ijGtDZq5+AVqXspum90ySikBpa1MCNzk02lJyc0mM0FIK8++Lvh+TXPDspiXLRndjHpXoBHIGa4/wCJXiKLQPD108hxuUhRnkmvF4hjSnl1WNb4bHp5POrTx1J0F71z5f07SJr7Uk01Pld32k4ziu+u/gzKFX7FceY3Uh+9cVo2sRWGurqc0ZKF8kA9Oa968P8AiTTNfj3WEwfaoJ55FfinCmU5Zj4zhXs5X07teSP1biDMMxwjjOldK2tir4W8OQeGtHXT4wN7uZZCOhYgA/yrWMUZ6xqfwq0yDOc0m33r9Pw+Hp4WlGlHZaI+EniJ1ZOct3qyAopQoyggjGK8B8WWkUHiOQRqBufn86+hGGFzmvKNP0JvEXj/AMlY9wikDEg9Bnp+OK+X4uwP1+FCglq5o+g4dxf1R1qreiie1eBLaW08M2cM4w4QZ/KumWq0ECwQpEi4CjGKsJ0r9VwdL2FCNLskj83xFX21edTu7kiHDVJUQ4OalrpMGQ59qKU8HFJQPcD0rwH4/X102pxWgkIhAB2179XmXxl8PW97pS3hUCVTgGvluMsLPF5RUhDdan0PC+Ijh8ypyn3PnJo8DpXqHwaXEl5x/Cn8zXDPpEoH3hXonwqtGtGupHORsX+Zr8W4Uw1SnmlOUvP8j9V4gxMKmAnGPl+Z1t34w0jS777DrMjWW/mGaYARSj/ZcHA+hweRWrBf2d3GJbO5hmQ87o5Aw/Q1U1XRrHWbY2t9AkqHsy5rzzxF4LTwun2zQru4jMzgMoYgD0xX6hjsViMDF1JQ5ortoz4HC4ehi5KkpcsvwO+8Sa1aaRpck07DcVOxc8tj/wDWK5/4KSfaNXu7ph88kjbq8yvbi/1J/MvLx5m9+ldT8N9Zk8P64hLny5yAfTNfKUM++u5xSqVI8tOL6nv1cm+rZbWowd5yV2fSO0Madt96rW0yzxLKjZDAEHNWq/a4SUoqx+VSjyuzGVNUQ5NS1RDI3GGptSOMj6VGehoGhv1ry34x+MNF0uxW2vruOLYDIxLf0rL+O/x/0D4V6XLbtLG+o4IC5+6a/PP4i/F7xT8QNXnu77UZRA5O2NWIXr6V8/nGJVSk8NTe+/ofsHh54a47iGosfWXJRWzfX0PpfR/jD4Z1vxnaeFtPEdx5zlHZjn6YGPrX1VF4bS00uKKxCqSuckdTX5M+HPEdz4a1601u3djLbyB+Dgmvr/T/ANuywt/D8dve2Gb2JQqkY9K8TLsJhMJBxtbz6n3XH/hvmNOdB5LBzhtK76n0ZJbaxHcrah4i7ZIUthio6kDvjI/OtuDQnng2aiI3BGCpGa/PDX/2qfHOr/EG28Zw6g8Udn+7EP8ACUYjdnH0Fe1Rft5WC6KkV3YEXxjBBUg5zXfRo4RXvJv11R8rmvhdxLg4UZUYRk5LXlfwvsy18SPiZ4f8DeOpfDl7CiR5JMgP3fw/H1rpvDGs6Nre2802/imGM4GM18RfEfx7f/ELxTc+Ir4t+9+4rHOPXn8qi8G/EXxB4NvkurC8lVUP3Q5xXzOJyjD1anPFWP1ir4YTq5XTlGbWIUVddG+p+uPhtiNLhz/dH8q21ORXzn+zx+0toXxBs4tD1RltdSVQNrkLuP8AjX0VGwIyDkHpX6NgqkJ0YqL6H8p8QZPjMlx08NjYOMr/ACa7ocgyakpqDA+tOrsPBYVkeJtQbRtDvtURSTbwM4xWvVe/srfUbOaxukDxTIUcHuDQzWjKEasZVFeKav6XPyF+MfjnU/HfjS91C5u3lh81ggJ4FcTtK/jX2N+0f+x7qenT3HivwLC9zbMTJLbAZZc8kgV8iahp97ply1nfWskE0ZIZHGCDXxmKoVKNV86P9AOCM+yjOsqpf2VJcsUk49U/NFbqATSNQOlLWB9mdzo0vhU/CrWob2ykOtG8ie2dRlY4sqCCfxb864V1yARXf6P4hgtvhNrXh7/hGzNJd3kUn9oeXnyvunbu7fd/WuDyK1qq1rdjw8oUlVxPPf49Lu+nLHbsvIbjAwKTGOaWprSyutRnS1srd55ZCAqIpJJNY2uz25SjBc0nZGp4K8Sal4X1+21XS7h4pY3BG3vzX62fCvxBP4q8EaXrd1C0ck8ILKwwQcV8X/s6/se6trs9v4n8bwfZ7MFZEgYfMRnI4PToOor700jSrLRNOg0vToRFb26BEUdgK+jyrD1aa5qisfyN438S5NnGJp4bAPnq0370lsl/L6lyiiivYPwEKKKKAGuiupV1DA8EEV478Uf2V/hh8TlknutNXT718kXFuuOfUj617JRUThGorSVz0cszbHZNXWIwFWVOa6p2/wCH+Z+dHj39gb4naFcSy+DprbW7QElFWQJIB9GI/TNeLeIPgh8W/DDTDWfh5r0CQctKbGQxkeobHPSv2AorzZ5TSlrBtfifsWU+PfEGCgqeMpQrW6u8ZfNq6/A/HvTfG3izSfAOqfDCLRUaz1O5W6naS2JmVgVyORkDKKPpkU3w98G/ir4mZRo3w68QXSvyHjsZCmPXcQAK/Yais/7HT+KbfyPQj491sNzywWXwhKb5pPnbTlte3Ku3c/N/wL+wf8XfELxz+J1tNAtjywllDyEf7q5IP1FfWfwo/ZN+GfwxSG7+xf2pqUeCbm4UcN6gAV7bRXZh8voYfWKu/PU+B4j8UuJOJoulXrezpv7MFyr5u7b+bGxxxxII4kCqOgAwBTqKK7T863CiiigD/9k="
};
async function genderUser(uid) {
  try {
    const s = await dGet(dRef(rtdb, `pub/${uid}/gender`));
    const g = s.exists() ? String(s.val() || "") : "";
    if (g) return g.trim().toUpperCase().startsWith("F") ? "F" : "M";
  } catch (e) {}
  try {
    const d = await getDoc(doc(db, "users", uid));
    const g = d.exists() ? String(d.data().gender || "") : "";
    if (g) return g.trim().toUpperCase().startsWith("F") ? "F" : "M";
  } catch (e) {}
  return "M";
}

/* ================= dompet: coin, diamond, reset ================= */
const DOMPET_ALAMAT = "https://viza.43-156-99-4.sslip.io/admin";
// Kalau panel dibuka dari server dompet sendiri, pakai jalur senama supaya bebas CORS.
const DOMPET_SEHOST = /^viza\.43-156-99-4\.sslip\.io$/i.test(location.hostname);
const WALLET_VPS = DOMPET_SEHOST ? location.origin + "/admin" : DOMPET_ALAMAT;
const WALLET_CAD = WALLET_VPS;
/** Alamat asas dompet, dipakai untuk unggah aset ke VPS. */
const DOMPET_BASE = DOMPET_SEHOST ? location.origin : "https://viza.43-156-99-4.sslip.io";
const WALLET_KEY = "sb_publishable_4PxD2LedOsBgIJyHLkM47A_bImSQI2W";
const OPS_TANPA_UID = ["coin_all", "reset_all", "reset_gem_all", "reset_all_assets", "delete_users", "manual_pending", "manual_all", "pay_get", "pay_set"];

async function walletAdmin(p) {
  const u = auth.currentUser;
  if (!u) throw new Error("Belum login");
  if (OPS_TANPA_UID.includes(p.op) && !p.uid) p = { ...p, uid: "-" };
  const t = await u.getIdToken();
  const kirim = (url) => fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: WALLET_KEY },
    body: JSON.stringify({ a: "admin", t, p })
  });
  let res = null, galat = "";
  try { res = await kirim(WALLET_VPS); } catch (e) { galat = "VPS(" + WALLET_VPS + "): " + (e.message || e); }
  if (!res || !res.ok) {
    try { const cad = await kirim(WALLET_CAD); if (cad.ok || !res) res = cad; }
    catch (e) { galat += (galat ? " | " : "") + "cadangan: " + (e.message || e); }
  }
  if (!res) throw new Error("Server tidak terjangkau (" + (galat || "jaringan") + ")");
  const out = await res.json().catch(() => ({}));
  if (!out.ok) throw new Error(out.e || ("HTTP " + res.status));
  return out;
}

async function gambarWallet() {
  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Kirim coin, VIP, dan reset</h3><div class="sub">server dompet Viza dan Rezo memakai jalur yang sama</div></div>
      <div style="padding:0 14px 14px">
        <div class="grid3">
          <div class="isian"><label>ID user (angka, ID unik, atau UID)</label><input id="wUser" placeholder="923146051900"></div>
          <div class="isian"><label>Jumlah coin / diamond</label><input id="wJumlah" type="number" value="0"></div>
          <div class="isian"><label>VIP tier (1-9) dan hari</label>
            <div style="display:flex;gap:6px"><input id="wTier" type="number" value="1" style="width:60px"><input id="wHari" type="number" value="30"></div></div>
        </div>
        <div class="filter" style="margin-top:14px">
          <div class="pil on" data-op="add">Kirim coin</div>
          <div class="pil" data-op="vip">Kirim VIP</div>
          <div class="pil" data-op="coin_all">Kirim coin semua user</div>
          <div class="pil" data-op="reset">Reset coin (1 user)</div>
          <div class="pil" data-op="reset_all">Reset coin semua user</div>
          <div class="pil" data-op="reset_gem">Reset diamond (1 user)</div>
          <div class="pil" data-op="reset_gem_all">Reset diamond semua user</div>
          <div class="pil" data-op="reset_user">Reset exp / level (1 user)</div>
          <div class="pil" data-op="reset_all_assets">Reset aset My Item semua user</div>
          <div class="pil" data-op="manual_pending">Cek topup manual</div>
          <div class="pil" data-op="delete_user">Hapus akun user</div>
          <div class="pil" data-op="nama">Reset nama jadi Unknown</div>
          <div class="pil" data-op="foto">Reset foto profil</div>
        </div>
        <div style="display:flex;gap:8px;margin-top:14px;align-items:center">
          <button class="tombolUtama" id="wJalan">Jalankan</button>
          <span class="catatan" id="wHasil" style="padding:0"></span>
        </div>
        <div class="isian" style="margin-top:16px"><label>Perintah lain (op dan parameter bebas)</label>
          <div style="display:flex;gap:6px"><input id="wOp" placeholder="mis. panel_coin_add" style="max-width:220px">
          <input id="wExtra" placeholder='{"coins":100}'></div></div>
        <div class="catatan" style="margin-top:12px">
          Reset nama menulis "Unknown" ke Realtime Database dan Firestore. Reset foto mengosongkan foto profil supaya aplikasi memakai foto bawaan sesuai jenis kelamin akun.
          Tombol dengan tulisan "semua user" langsung mengubah data massal, jadi pastikan dulu sebelum menekan.
          Kirim coin semua user memberi jumlah di kolom "Jumlah coin" ke setiap dompet yang ada.
        </div>
      </div>
    </div>

    <div class="panel" style="margin-top:14px">
      <div class="panelAtas"><h3>Topup manual (DANA / GoPay / QRIS)</h3>
        <div class="filter"><div class="pil on" id="payMuat">Muat ulang</div></div>
      </div>
      <div style="padding:12px">
        <div class="isian"><label>Nomor DANA atau tautan resmi DANA</label><input id="payDana" placeholder="08xxxxxxxxxx atau https://qr.dana.id/..."></div>
        <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
          <div class="isian" style="flex:1;min-width:140px"><label>Nama pemilik</label><input id="payNama" placeholder="Nama sesuai akun"></div>
          <div class="isian" style="flex:1;min-width:140px"><label>Nomor GoPay</label><input id="payGopay" placeholder="08xxxxxxxxxx"></div>
        </div>
        <div class="isian" style="margin-top:10px"><label>Gambar QRIS</label>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <input id="payQris" placeholder="tautan gambar atau tekan Unggah" style="flex:1;min-width:160px">
            <label class="tombolAtas" for="payQrisFile" role="button" id="payUnggah" style="color:#fff;cursor:pointer">Unggah</label>
            <input type="file" id="payQrisFile" accept="image/*" style="position:absolute;width:1px;height:1px;opacity:0;pointer-events:none">
          </div>
          <div id="payQrisLihat" style="margin-top:8px"></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:12px;align-items:center;flex-wrap:wrap">
          <button class="tombolUtama" id="paySimpan">Simpan info pembayaran</button>
          <span class="catatan" id="payHasil" style="padding:0"></span>
        </div>
        <div class="catatan" style="margin-top:10px">Nomor dan QRIS ini yang dilihat user saat mengajukan topup manual di aplikasi. Kosongkan salah satu kalau tidak dipakai.</div>
      </div>
      <div id="payDaftar" style="padding:0 12px 12px"></div>
    </div>

    <div class="panel" style="margin-top:14px">
      <div class="panelAtas"><h3>Paket coin (jumlah dan harga)</h3>
        <div class="filter"><div class="pil on" id="paketTambah">Tambah paket</div></div>
      </div>
      <div style="padding:12px">
        <div id="paketTabel"></div>
        <div style="display:flex;gap:8px;margin-top:12px;align-items:center;flex-wrap:wrap">
          <button class="tombolUtama" id="paketSimpan">Simpan paket</button>
          <span class="catatan" id="paketHasil" style="padding:0"></span>
        </div>
        <div class="catatan" style="margin-top:10px">Isi coin dalam angka, contoh 1000000. Harga dalam rupiah tanpa titik, contoh 6000. Paket yang tampil di aplikasi adalah paket yang dicentang aktif.</div>
      </div>
    </div>`;

  let opTerpilih = "add";
  $("isiHal").querySelectorAll("[data-op]").forEach((p) => (p.onclick = () => {
    $("isiHal").querySelectorAll("[data-op]").forEach((x) => x.classList.toggle("on", x === p));
    opTerpilih = p.dataset.op;
  }));

  $("wJalan").onclick = async () => {
    const t = $("wJalan");
    const masukan = $("wUser").value.trim();
    t.disabled = true; t.textContent = "Menjalankan…";
    $("wHasil").textContent = "";
    try {
      const opManual = $("wOp").value.trim();
      let uid = masukan;
      if (masukan && !OPS_TANPA_UID.includes(opTerpilih)) {
        const cari = await uidDariMasukan(masukan);
        if (cari) uid = cari;
      }
      const jumlah = Number($("wJumlah").value) || 0;
      if (opManual) {
        const isi = $("wExtra").value.trim() ? JSON.parse($("wExtra").value) : {};
        const out = await walletAdmin({ op: opManual, uid: uid || "-", ...isi });
        $("wHasil").textContent = "Selesai: " + JSON.stringify(out).slice(0, 300);
        catatLog("Wallet op", opManual);
        return;
      }
      if (opTerpilih === "nama") {
        if (!uid) throw new Error("Isi ID user dulu");
        await dSet(dRef(rtdb, `pub/${uid}/name`), "Unknown");
        await setDoc(doc(db, "users", uid), { name: "Unknown", nickname: "Unknown" }, { merge: true });
        $("wHasil").textContent = "Nama diganti menjadi Unknown.";
        catatLog("Reset nama", uid);
        return;
      }
      if (opTerpilih === "foto") {
        if (!uid) throw new Error("Isi ID user dulu");
        const g = await genderUser(uid);
        const ikon = FOTO_BAWAAN[g] || FOTO_BAWAAN.M;
        let ok = 0;
        // 1) Realtime Database: "av" = foto yang dibaca profil publik, "photo" dikosongkan
        try {
          await dUpdate(dRef(rtdb, `pub/${uid}`), { av: ikon, photo: "" });
          ok++;
        } catch (e) { console.warn("RTDB foto:", e.code || e.message); }
        // 2) Cermin Firestore
        try {
          await setDoc(doc(db, "users", uid), { avatarB64: ikon, photoUrl: null, photo: "" }, { merge: true });
          ok++;
        } catch (e) { console.warn("Firestore foto:", e.code || e.message); }
        try {
          const ids = await getDocs(query(collection(db, "userIds"), where("uid", "==", uid), limit(5)));
          for (const d of ids.docs) await setDoc(doc(db, "userIds", d.id), { avatarB64: ikon, photoUrl: null }, { merge: true });
        } catch (e) { console.warn("userIds foto:", e.code || e.message); }
        if (!ok) throw new Error("Foto gagal ditulis, cek rules database");
        $("wHasil").textContent = "Foto profil diganti ke foto bawaan " + (g === "F" ? "cewek" : "cowok") + ".";
        catatLog("Reset foto", uid + " · " + g);
        return;
      }
      const p = { op: opTerpilih, uid };
      // Tombol massal wajib dikonfirmasi dengan mengetik HAPUS: dulu sekali
      // terpencet, seluruh saldo coin user langsung kosong.
      if (["reset_all", "reset_gem_all", "reset_all_assets"].includes(opTerpilih)) {
        const tulis = prompt("PERINGATAN: ini mengosongkan data SEMUA user. Ketik HAPUS untuk lanjut.");
        if (String(tulis || "").trim().toUpperCase() !== "HAPUS") {
          $("wHasil").textContent = "Dibatalkan.";
          t.disabled = false; t.textContent = "Jalankan";
          return;
        }
        p.konfirmasi = "HAPUS";
      }
      if (opTerpilih === "coin_all") {
        if (!(jumlah > 0)) throw new Error("Isi jumlah coin dulu");
        const tulis = prompt(
          "Kirim " + jumlah.toLocaleString("id-ID") + " coin ke SEMUA user. Ketik KIRIM untuk lanjut."
        );
        if (String(tulis || "").trim().toUpperCase() !== "KIRIM") {
          $("wHasil").textContent = "Dibatalkan.";
          t.disabled = false; t.textContent = "Jalankan";
          return;
        }
        p.coins = jumlah;
        p.konfirmasi = "KIRIM";
      }
      if (opTerpilih === "add") { p.coins = jumlah; }
      if (opTerpilih === "vip") { p.tier = Number($("wTier").value) || 1; p.days = Number($("wHari").value) || 30; }
      const out = await walletAdmin(p);
      $("wHasil").textContent = opTerpilih === "coin_all"
        ? "Selesai: " + Number(out.coins || 0).toLocaleString("id-ID") + " coin dikirim ke " + Number(out.jumlah || 0) + " user."
        : "Selesai: " + (out.coins !== undefined ? "saldo " + out.coins : JSON.stringify(out).slice(0, 240));
      catatLog("Wallet " + opTerpilih, uid || "semua user");
      toast("Perintah dijalankan");
    } catch (e) {
      toast("Gagal: " + (e.message || e.code || "tidak diketahui"), true);
    } finally {
      t.disabled = false; t.textContent = "Jalankan";
    }
  };

  /* ---------- topup manual: info pembayaran + pengajuan ---------- */
  function lihatQris(url) {
    const kotak = $("payQrisLihat");
    if (!kotak) return;
    kotak.innerHTML = url
      ? `<img src="${aman(url)}" alt="QRIS" style="max-width:180px;border-radius:10px;background:#fff;padding:6px">`
      : "";
  }

  async function muatPengajuan() {
    const kotak = $("payDaftar");
    if (!kotak) return;
    kotak.innerHTML = '<div class="kosong">Memuat pengajuan…</div>';
    try {
      const out = await walletAdmin({ op: "manual_all", limit: 40 });
      const baris = out.list || [];
      if (!baris.length) { kotak.innerHTML = '<div class="kosong">Belum ada pengajuan topup.</div>'; return; }
      kotak.innerHTML = `<table>
        <tr><th>WAKTU</th><th>USER</th><th>COIN</th><th>NOMINAL</th><th>METODE</th><th>PENGIRIM</th><th>STATUS</th><th>AKSI</th></tr>
        ${baris.map((b) => {
          const waktu = b.created_at ? new Date(Number(b.created_at)).toLocaleString("id-ID") : "—";
          const status = String(b.status || "");
          const tag = status === "ok" ? '<span class="tag aktif">disetujui</span>'
            : status === "tolak" ? '<span class="tag blokir">ditolak</span>'
            : '<span class="tag">menunggu</span>';
          const aksi = status === "pending"
            ? `<button class="aksi" data-setuju="${aman(b.id)}">Setujui</button> · <button class="aksi" data-tolak="${aman(b.id)}">Tolak</button>`
            : "—";
          return `<tr>
            <td>${aman(waktu)}</td>
            <td>${aman(String(b.uid || "").slice(0, 12))}…</td>
            <td>${aman(String(b.coins ?? ""))}</td>
            <td>${aman(b.amount ? rupiah(Number(b.amount)) : "—")}</td>
            <td>${aman(b.method || "—")}</td>
            <td>${aman(b.payer || "—")}</td>
            <td>${tag}</td>
            <td>${aksi}</td>
          </tr>`;
        }).join("")}
      </table><div class="kaki">${baris.length} pengajuan terakhir</div>`;

      kotak.querySelectorAll("[data-setuju]").forEach((b) => (b.onclick = () => putusPengajuan(b.dataset.setuju, true)));
      kotak.querySelectorAll("[data-tolak]").forEach((b) => (b.onclick = () => putusPengajuan(b.dataset.tolak, false)));
    } catch (e) {
      kotak.innerHTML = `<div class="kosong">${aman(e.message || "Gagal memuat")}</div>`;
    }
  }

  async function putusPengajuan(id, setuju) {
    try {
      await walletAdmin({ op: "manual_decide", id, ok: setuju });
      catatLog("Topup manual", (setuju ? "Setujui " : "Tolak ") + id);
      toast(setuju ? "Coin sudah ditambahkan" : "Pengajuan ditolak");
      muatPengajuan();
    } catch (e) {
      toast("Gagal: " + (e.message || e), true);
    }
  }

  async function muatInfoBayar() {
    try {
      const out = await walletAdmin({ op: "pay_get" });
      const p = out.pay || {};
      $("payDana").value = p.dana || "";
      $("payNama").value = p.name || "";
      $("payGopay").value = p.gopay || "";
      $("payQris").value = p.qris || "";
      lihatQris(p.qris);
    } catch (e) {
      toast("Info pembayaran gagal dimuat: " + (e.message || e), true);
    }
  }

  $("payMuat").onclick = () => { muatInfoBayar(); muatPengajuan(); };
  $("payQris").oninput = (e) => lihatQris(e.target.value.trim());
  // Label "Unggah" membuka galeri HP langsung lewat input file yang ada di
  // halaman. Dulu input dibuat lewat skrip lalu diklik, dan di WebView Android
  // itu diabaikan sehingga galeri tidak pernah terbuka.
  $("payQrisFile").onchange = async (e) => {
    const berkas = e.target.files && e.target.files[0];
    if (!berkas) return;
    const tombol = $("payUnggah");
    tombol.textContent = "0%";
    try {
      const url = await unggahBerkas(berkas, "qris", (persen) => { tombol.textContent = persen + "%"; });
      $("payQris").value = url;
      lihatQris(url);
      toast("Gambar QRIS diunggah, tekan Simpan info pembayaran");
    } catch (err) {
      toast("Unggah gagal: " + (err.message || err), true);
      window.__galatVps && console.warn("Unggah QRIS:", window.__galatVps);
    } finally {
      tombol.textContent = "Unggah";
      try { e.target.value = ""; } catch (err) {}
    }
  };
  $("paySimpan").onclick = async () => {
    const tombol = $("paySimpan");
    tombol.disabled = true;
    try {
      await walletAdmin({
        op: "pay_set",
        dana: $("payDana").value.trim(),
        name: $("payNama").value.trim(),
        gopay: $("payGopay").value.trim(),
        qris: $("payQris").value.trim()
      });
      $("payHasil").textContent = "Info pembayaran tersimpan.";
      catatLog("Info pembayaran", "DANA/GoPay/QRIS disimpan");
      toast("Info pembayaran disimpan");
    } catch (e) {
      $("payHasil").textContent = "";
      toast("Gagal menyimpan: " + (e.message || e), true);
    } finally {
      tombol.disabled = false;
    }
  };

  muatInfoBayar();
  muatPengajuan();

  /* ---------- paket coin: jumlah dan harga bisa diubah ---------- */
  let paketBaris = [];

  function rupiahTeks(n) {
    return "Rp " + Number(n || 0).toLocaleString("id-ID");
  }

  function gambarPaket() {
    const kotak = $("paketTabel");
    if (!kotak) return;
    if (!paketBaris.length) { kotak.innerHTML = '<div class="kosong">Belum ada paket. Tekan Tambah paket.</div>'; return; }
    kotak.innerHTML = `<table>
      <tr><th>COIN</th><th>HARGA (Rp)</th><th>TAMPIL DI APP</th><th>AKSI</th></tr>
      ${paketBaris.map((x, i) => `<tr>
        <td><input type="number" data-paket-coin="${i}" value="${aman(String(x.coins))}" style="width:130px"></td>
        <td><input type="number" data-paket-harga="${i}" value="${aman(String(x.harga))}" style="width:110px"></td>
        <td><input type="checkbox" data-paket-aktif="${i}" ${Number(x.aktif) ? "checked" : ""}></td>
        <td><button class="aksi" data-paket-hapus="${i}">Hapus</button></td>
      </tr>`).join("")}
    </table><div class="kaki">${paketBaris.length} paket · harga tampil ${paketBaris.filter((x) => Number(x.aktif)).map((x) => rupiahTeks(x.harga)).join(", ") || "—"}</div>`;

    // Jangan gambar ulang tabel saat mengetik: kolom input diganti elemen baru
    // sehingga fokus hilang dan keyboard HP langsung menutup setiap satu angka.
    // Cukup simpan nilainya, dan perbarui ringkasan di bawah tabel saja.
    const ringkasan = () => {
      const kaki = kotak.querySelector(".kaki");
      if (kaki) kaki.textContent = paketBaris.length + " paket · harga tampil "
        + (paketBaris.filter((x) => Number(x.aktif)).map((x) => rupiahTeks(x.harga)).join(", ") || "—");
    };
    kotak.querySelectorAll("[data-paket-coin]").forEach((inp) => (inp.oninput = () => {
      paketBaris[Number(inp.dataset.paketCoin)].coins = Number(inp.value) || 0; ringkasan();
    }));
    kotak.querySelectorAll("[data-paket-harga]").forEach((inp) => (inp.oninput = () => {
      paketBaris[Number(inp.dataset.paketHarga)].harga = Number(inp.value) || 0; ringkasan();
    }));
    kotak.querySelectorAll("[data-paket-aktif]").forEach((inp) => (inp.onchange = () => {
      paketBaris[Number(inp.dataset.paketAktif)].aktif = inp.checked ? 1 : 0; ringkasan();
    }));
    kotak.querySelectorAll("[data-paket-hapus]").forEach((b) => (b.onclick = () => {
      paketBaris.splice(Number(b.dataset.paketHapus), 1); gambarPaket();
    }));
  }

  async function muatPaket() {
    try {
      const out = await walletAdmin({ op: "paket_get" });
      paketBaris = (out.paket || []).map((x) => ({ coins: Number(x.coins), harga: Number(x.harga), aktif: Number(x.aktif) }));
      gambarPaket();
    } catch (e) {
      $("paketTabel").innerHTML = `<div class="kosong">${aman(e.message || "Gagal memuat paket")}</div>`;
    }
  }

  $("paketTambah").onclick = () => {
    paketBaris.push({ coins: 0, harga: 0, aktif: 1 });
    gambarPaket();
  };

  $("paketSimpan").onclick = async () => {
    const tombol = $("paketSimpan");
    const paket = paketBaris.filter((x) => Number(x.coins) > 0 && Number(x.harga) >= 0)
      .map((x) => ({ coins: Number(x.coins), harga: Number(x.harga), aktif: Number(x.aktif) }));
    if (!paket.length) return toast("Isi dulu jumlah coin dan harganya", true);
    tombol.disabled = true;
    try {
      await walletAdmin({ op: "paket_set", paket });
      // Aplikasi membaca daftar ini dari Firestore, dengan cermin di Realtime Database.
      const isi = paket.filter((x) => x.aktif).map((x) => ({ coins: x.coins, price: rupiahTeks(x.harga) }));
      try {
        await setDoc(doc(db, "vipConfig", "topupPacks"), { packs: isi, updated: Date.now() }, { merge: true });
      } catch (e) { console.warn("Firestore paket:", e.code || e.message); }
      try {
        const peta = {};
        isi.forEach((x, i) => { peta[String(i + 1)] = { coins: x.coins, price: x.price }; });
        await dSet(dRef(rtdb, "rocketCfg/topupPacks"), peta);
      } catch (e) { console.warn("RTDB paket:", e.code || e.message); }
      $("paketHasil").textContent = "Paket tersimpan: " + isi.length + " tampil di aplikasi.";
      catatLog("Paket coin", isi.map((x) => x.coins + "=" + x.price).join(", "));
      toast("Paket coin disimpan");
    } catch (e) {
      $("paketHasil").textContent = "";
      toast("Gagal menyimpan paket: " + (e.message || e), true);
    } finally {
      tombol.disabled = false;
    }
  };

  muatPaket();
}

/* ================= kirim item ke user ================= */
/** Cari UID dari ID angka, ID unik, atau UID yang diketik admin. */
async function uidDariMasukan(masukan) {
  const teks = String(masukan || "").trim();
  if (!teks) return null;
  const bersih = teks.replace(/\s+/g, "");
  if (bersih.length > 20) return bersih;             // sudah berupa UID
  try {
    const d = await getDoc(doc(db, "userIds", bersih));
    if (d.exists() && d.data().uid) return d.data().uid;
  } catch (e) { }
  try {
    const d = await fsBacaJalur("userIds/" + bersih);
    if (d && d.uid) return d.uid;
    if (d) return bersih;
  } catch (e) { }
  for (const medan of ["userId", "uid"]) {
    try {
      const s = await getDocs(query(collection(db, "userIds"), where(medan, "==", bersih), limit(1)));
      if (!s.empty) { const u = s.docs[0].data().uid; if (u) return u; }
    } catch (e) { }
    try {
      const baris = await fsCari("userIds", medan, bersih, 1);
      if (baris.length && baris[0].uid) return baris[0].uid;
    } catch (e) { }
  }
  try {
    const s = await getDocs(query(collection(db, "users"), where("userId", "==", bersih), limit(1)));
    if (!s.empty) return s.docs[0].id;
  } catch (e) { }
  try {
    const baris = await fsCari("users", "userId", bersih, 1);
    if (baris.length && baris[0].id) return baris[0].id;
  } catch (e) { }
  return null;
}

async function gambarKirim() {
  const semua = await ambilSemua("vipConfig", 400).catch(() => []);
  const item = semua.filter((d) => d.id && d.slot && !d.meta)
    .sort((a, b) => (Number(a.order) || 0) - (Number(b.order) || 0));
  $("aksiTopbar").innerHTML = "";

  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Kirim item ke user</h3><div class="sub">langsung masuk ke tas user, tanpa beli di Store</div></div>
      <div style="padding:0 14px 14px">
        <div class="grid2">
          <div class="isian"><label>ID user (ID angka, ID unik, atau UID)</label><input id="kUser" placeholder="mis. 923146051900"></div>
          <div class="isian"><label>Durasi (hari)</label><input id="kHari" type="number" value="30"></div>
        </div>
        <div class="isian" style="margin-top:10px"><label>Cari item (nama, nomor ID unik, atau jenis)</label>
          <input id="kCari" placeholder="mis. 1000 atau Sultan atau frame"></div>
        <div class="isian" style="margin-top:10px"><label>Item</label><select id="kItem">
          ${item.length ? item.map((d) => `<option value="${aman(d.id)}">${aman(d.name || d.id)} · ${aman(namaSlot(d.slot))}${Number(d.price) ? " · " + rupiah(d.price) + " koin" : ""}${d.customId ? " · ID " + aman(d.customId) : ""}</option>`).join("") : '<option value="">Belum ada item, buat di Aset & VIP</option>'}
        </select></div>
        <div style="display:flex;gap:8px;margin-top:14px;align-items:center">
          <button class="tombolUtama" id="kirimSekarang">Kirim ke user</button>
          <span class="catatan" id="kHasil" style="padding:0"></span>
        </div>
        <div class="catatan" style="margin-top:12px">
          Lencana, medali, frame, efek masuk, banner, dan ID unik semuanya dikirim dari sini.
          Item yang dipilih harus sudah dibuat di halaman <b>Aset & VIP</b> supaya gambarnya ada di aplikasi.
          Item tercatat di tas user lewat Realtime Database, jadi langsung terlihat setelah aplikasi dibuka ulang.
        </div>
      </div>
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Buat &amp; kirim item baru (lencana, frame, medali)</h3><div class="sub">tidak perlu bikin dulu di Store atau Aset &amp; VIP</div></div>
      <div style="padding:0 14px 14px">
        <div class="grid2">
          <div class="isian"><label>Nama lencana</label><input id="lncNama" placeholder="mis. Lencana Sultan"></div>
          <div class="isian"><label>Jenis item</label><select id="lncSlot">
            <option value="badge" selected>Lencana</option>
            <option value="medal">Medali</option>
            <option value="frame">Frame</option>
            <option value="entry">Efek masuk</option>
            <option value="banner">Banner</option>
            <option value="emote">Emote room</option>
            <option value="uid">ID unik</option>
            <option value="bubble">Gelembung</option>
          </select></div>
        </div>
        <div class="filter" style="margin-top:8px">
          <div class="pil" data-jenis="badge">Lencana</div>
          <div class="pil" data-jenis="frame">Frame avatar</div>
          <div class="pil" data-jenis="medal">Medali</div>
          <div class="pil" data-jenis="entry">Efek masuk</div>
          <div class="pil" data-jenis="banner">Banner</div>
          <div class="pil" data-jenis="emote">Emote room</div>
          <div class="pil" data-jenis="uid">ID unik</div>
        </div>
        <div class="isian" id="lncBlokNomor" style="margin-top:10px;display:none">
          <label>Nomor ID unik (agar bisa dicari di pencarian)</label>
          <input id="lncNomor" inputmode="numeric" placeholder="mis. 1000">
          <div class="catatan" style="padding:4px 0 0">Nomor ini didaftarkan ke pencarian: user lain bisa mencarinya di kolom cari ID dan profil penerima menampilkan gambar ID ini.</div>
        </div>
        <div class="grid2" style="margin-top:10px">
          <div class="isian"><label>Harga di Store (koin, opsional)</label><input id="lncHarga" type="number" placeholder="0"></div>
          <div class="isian"><label>Tampilkan juga di Store</label><div class="saklar" id="lncToko"></div></div>
        </div>
        <div style="margin-top:10px">${htmlSumber("lnc", "", ".png,.jpg,.jpeg,.webp,.gif,.svga,.mp4,.webm")}</div>
        <div class="grid2" style="margin-top:10px">
          <div class="isian"><label>ID user penerima</label><input id="lncUser" placeholder="mis. 923146051900"></div>
          <div class="isian"><label>Durasi (hari)</label><input id="lncHari" type="number" value="30"></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:14px;align-items:center">
          <button class="tombolUtama" id="lncKirim">Buat &amp; kirim ke user</button>
          <span class="catatan" id="lncHasil" style="padding:0"></span>
        </div>
        <div class="catatan" style="margin-top:12px">Gambar boleh dari perangkat atau tautan (PNG, WEBP, GIF, MP4, SVGA). Pratinjau di atas menunjukkan tampilan aslinya. Item langsung dibuat, lalu masuk ke tas user sebagai lencana yang bisa dipakai.</div>
      </div>
    </div>`;

  aktifkanPratinjau("lnc");
  const tampilNomor = () => { $("lncBlokNomor").style.display = $("lncSlot").value === "uid" ? "" : "none"; };
  $("lncSlot").onchange = tampilNomor;
  $("isiHal").querySelectorAll("[data-jenis]").forEach((pil) => (pil.onclick = () => {
    $("lncSlot").value = pil.dataset.jenis;
    $("isiHal").querySelectorAll("[data-jenis]").forEach((x) => x.classList.toggle("on", x === pil));
    tampilNomor();
  }));
  tampilNomor();
  $("lncToko").onclick = () => $("lncToko").classList.toggle("on");
  $("lncKirim").onclick = async () => {
    const tombol = $("lncKirim");
    const hasil = $("lncHasil");
    const nama = $("lncNama").value.trim();
    if (!nama) return toast("Nama lencana wajib diisi", true);
    tombol.disabled = true; tombol.textContent = "Memproses…";
    try {
      const url = await urlDariSumber("lnc", "lencana");
      if (!url) throw new Error("Pilih berkas atau isi tautan dulu");
      const uid = await uidDariMasukan($("lncUser").value);
      if (!uid) throw new Error("ID user tidak ditemukan");
      const slot = $("lncSlot").value;
      const hari = Number($("lncHari").value) || 30;
      const idItem = "lnc_" + Date.now().toString(36);
      const nomorUnik = slot === "uid" ? $("lncNomor").value.replace(/[^0-9]/g, "") : "";
      if (slot === "uid" && !nomorUnik) throw new Error("Isi nomor ID unik dulu supaya bisa dicari");
      await simpanVip("item_" + idItem, {
        id: idItem, slot, name: nama,
        customId: nomorUnik,
        price: Number($("lncHarga").value) || 0,
        days: hari, order: 0, kind: cabangBerkas(url), url,
        hasData: false, updatedAt: Date.now(), chunks: 0,
        store: $("lncToko").classList.contains("on"),
        dibuatOleh: (auth.currentUser && auth.currentUser.email) || "", dibuat: Date.now()
      });
      // Lewat server: aturan /pub menolak tulisan staf panel dari browser.
      await walletAdmin({ op: "kirim_item", uid, item: idItem, hari });
      const namaJenis = { frame: "Bingkai", badge: "Lencana", medal: "Medali", bubble: "Gelembung", entry: "Efek masuk", banner: "Banner", emote: "Emote", uid: "ID unik" }[slot] || "Item";
      hasil.textContent = namaJenis + " " + nama + " terkirim, berlaku " + hari + " hari." +
        (nomorUnik ? " ID " + nomorUnik + " sekarang bisa dicari di pencarian." : "");
      catatLog("Kirim lencana", nama + " ke " + $("lncUser").value.trim());
      toast("Lencana dibuat dan dikirim");
    } catch (e) {
      hasil.textContent = e.message || "Gagal";
      toast(e.message || "Gagal", true);
    } finally {
      tombol.disabled = false; tombol.textContent = "Buat & kirim ke user";
    }
  };

  // Pencarian item: ketik nama, nomor ID unik, atau jenis, daftar langsung menyempit.
  const semuaOpsi = Array.from($("kItem").options).map((o) => ({ v: o.value, t: o.textContent }));
  $("kCari").oninput = () => {
    const q = $("kCari").value.trim().toLowerCase();
    const cocok = q ? semuaOpsi.filter((o) => o.t.toLowerCase().includes(q) ||
      (item.find((x) => x.id === o.v)?.customId || "").toString().includes(q)) : semuaOpsi;
    $("kItem").innerHTML = cocok.length
      ? cocok.map((o) => `<option value="${aman(o.v)}">${aman(o.t)}</option>`).join("")
      : '<option value="">Tidak ada item yang cocok</option>';
  };

  $("kirimSekarang").onclick = async () => {
    const tombol = $("kirimSekarang");
    const idItem = $("kItem").value;
    if (!idItem) return toast("Pilih item dulu", true);
    const hari = Number($("kHari").value) || 30;
    tombol.disabled = true; tombol.textContent = "Mengirim…";
    try {
      const uid = await uidDariMasukan($("kUser").value);
      if (!uid) throw new Error("ID user tidak ditemukan");
      // Lewat server supaya staf panel tidak kena PERMISSION_DENIED.
      await walletAdmin({ op: "kirim_item", uid, item: idItem, hari });
      const nama = item.find((x) => x.id === idItem)?.name || idItem;
      catatLog("Kirim item", `${nama} · ${hari} hari · ke ${uid}`);
      const nomorTerkirim = item.find((x) => x.id === idItem)?.customId;
      $("kHasil").textContent = `Terkirim: ${nama}, ${hari} hari.` +
        (nomorTerkirim ? ` ID ${nomorTerkirim} sekarang bisa dicari di pencarian.` : "");
      toast("Item terkirim");
    } catch (e) {
      $("kHasil").textContent = "";
      toast("Gagal: " + (e.message || e.code || "tidak diketahui"), true);
    } finally {
      tombol.disabled = false; tombol.textContent = "Kirim ke user";
    }
  };
}

/* ================= aset & VIP (sama seperti Rezo) ================= */
// Aplikasi membaca vipConfig dengan dua bentuk dokumen:
//  1. aset milik tier  : { n: 1..9, slot, kind, url, meta: true, hasData, updatedAt, chunks }
//  2. item toko/kiriman: { id, slot, name, price, days, order, kind, url, hasData, updatedAt,
//                          chunks, targetUid, customId, store }
const SLOT_ASET = [
  { k: "cardbg", n: "Kartu profil VIP (latar kartu)" },
  { k: "frame", n: "Bingkai avatar (frame)" },
  { k: "entry", n: "Efek masuk room" },
  { k: "bubble", n: "Gelembung chat" },
  { k: "title", n: "Gelar" },
  { k: "medal", n: "Medali" },
  { k: "badge", n: "Lencana (badge)" },
  { k: "banner", n: "Banner masuk" },
  { k: "emote", n: "Emote room (GIF/PNG)" },
  { k: "uid", n: "Unique ID (gambar ID)" },
  { k: "avatar", n: "Avatar" }
];
const namaSlot = (k) => SLOT_ASET.find((s) => s.k === k)?.n || k || "—";
const jenisDariUrl = (url) => {
  const bersih = String(url || "").split("?")[0].toLowerCase();
  const ext = bersih.split(".").pop();
  if (ext === "svga") return "svga";
  if (["mp4", "webm"].includes(ext)) return "video";
  return "image";
};

/** Halaman daftar aset yang sudah tersimpan di VPS dompet. */
async function gambarAsetVps() {
  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Aset di VPS</h3>
        <div class="sub">semua berkas hasil unggahan panel, disajikan langsung dari server Viza</div></div>
      <div style="padding:0 14px 14px">
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
          <button class="tombolUtama" id="asetVpsMuat">Muat ulang</button>
        </div>
        <div id="asetVpsIsi" class="sub">Memuat…</div>
      </div>
    </div>`;

  const kecil = (f) => {
    const ext = String(f.nama).split(".").pop().toLowerCase();
    if (["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) {
      return `<img src="${aman(f.url)}" alt="" style="width:52px;height:52px;object-fit:cover;border-radius:10px;background:#0d1117">`;
    }
    return `<code style="font-size:11px">${aman(ext)}</code>`;
  };

  const muat = async () => {
    const kotak = $("asetVpsIsi");
    kotak.className = "sub";
    kotak.textContent = "Memuat…";
    try {
      const t = await auth.currentUser?.getIdToken();
      const r = await fetch(DOMPET_BASE + "/aset-list?t=" + encodeURIComponent(t || ""), { method: "GET" });
      const j = await r.json().catch(() => null);
      if (!j || !j.ok) throw new Error((j && j.e) || ("HTTP " + r.status));
      if (!j.list || !j.list.length) {
        kotak.innerHTML = 'Belum ada aset. Unggah dulu dari halaman <b>Frame &amp; banner</b>, <b>Aset &amp; VIP</b>, atau <b>Kirim ke user</b>.';
        return;
      }
      const total = j.list.reduce((n, f) => n + (Number(f.ukuran) || 0), 0);
      kotak.className = "";
      kotak.innerHTML = `
        <div class="sub" style="margin-bottom:8px">${j.list.length} berkas · ${(total / 1024 / 1024).toFixed(1)} MB</div>
        <table>
          <thead><tr><th>Berkas</th><th>Ukuran</th><th>Disimpan di</th><th>Alamat</th><th></th></tr></thead>
          <tbody>${j.list.map((f) => `<tr>
            <td>${kecil(f)}</td>
            <td>${Math.max(1, Math.round((Number(f.ukuran) || 0) / 1024))} KB</td>
            <td>${f.simpan === "disk" ? "VPS berkas" : "VPS database"}</td>
            <td><code style="font-size:11px;word-break:break-all">${aman(f.url)}</code></td>
            <td style="white-space:nowrap">
              <button class="tombolKecil" data-salin="${aman(f.url)}">Salin</button>
              <button class="tombolKecil" data-hapusaset="${aman(f.nama)}">Hapus</button>
            </td>
          </tr>`).join("")}</tbody>
        </table>`;
      kotak.querySelectorAll("[data-salin]").forEach((b) => b.addEventListener("click", async () => {
        try { await navigator.clipboard.writeText(b.dataset.salin); toast("Alamat disalin"); }
        catch (e) { toast(b.dataset.salin); }
      }));
      kotak.querySelectorAll("[data-hapusaset]").forEach((b) => b.addEventListener("click", async () => {
        if (!confirm("Hapus berkas ini dari VPS?")) return;
        try {
          const t2 = await auth.currentUser?.getIdToken();
          const r2 = await fetch(DOMPET_BASE + "/aset-hapus", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ t: t2, nama: b.dataset.hapusaset })
          });
          const j2 = await r2.json().catch(() => null);
          if (!j2 || !j2.ok) throw new Error((j2 && j2.e) || ("HTTP " + r2.status));
          toast("Berkas dihapus");
          muat();
        } catch (e) { toast("Gagal menghapus: " + (e?.message || e), true); }
      }));
    } catch (e) {
      kotak.className = "sub";
      kotak.innerHTML = `Gagal memuat daftar aset: ${aman(e?.message || e)}`;
    }
  };

  $("asetVpsMuat").addEventListener("click", muat);
  await muat();
}

async function gambarAset() {
  const semua = await ambilSemuaVip(400).catch(() => []);
  const disalin = await sinkronVipRtdb(semua);
  if (disalin > 0) toast(disalin + " item disalin ke RTDB, sekarang terbaca APK");
  const asetVip = semua.filter((d) => d.meta === true && Number(d.n) >= 1 && Number(d.n) <= 9);
  const itemToko = semua.filter((d) => d.id && d.slot && !d.meta);

  $("aksiTopbar").innerHTML = `
    <button class="tombolAtas" id="tambahAsetVip">+ Aset VIP</button>
    <button class="tombolAtas" id="tambahItem" style="margin-left:6px">+ Item toko</button>`;
  $("tambahAsetVip").onclick = () => formAsetVip(null);
  $("tambahItem").onclick = () => formItemToko(null);

  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Aset VIP 1-9</h3><div class="sub">vipConfig · meta=true · n dan slot</div>
        <div class="filter"><div class="pil on">${asetVip.length} aset</div></div></div>
      ${asetVip.length ? `<div class="gulirTabel"><table class="tabelKartu">
        <thead><tr><th>PRATINJAU</th><th>TIER</th><th>SLOT</th><th>JENIS</th><th>TAUTAN</th><th>AKSI</th></tr></thead>
        <tbody>${asetVip.sort((x, y) => (Number(x.n) - Number(y.n)) || namaSlot(x.slot).localeCompare(namaSlot(y.slot))).map((d) => `<tr>
          <td data-l="Pratinjau">${pratinjauAset(d.url)}</td>
          <td data-l="Tier" class="vip">VIP ${Number(d.n)}</td>
          <td data-l="Slot">${aman(namaSlot(d.slot))}</td>
          <td data-l="Jenis">${aman(d.kind || jenisDariUrl(d.url))}</td>
          <td data-l="Tautan"><span class="kodekecil" title="${aman(d.url)}">${aman(d.url)}</span></td>
          <td data-l="Aksi" data-aksi>
            <button class="tombolKecil" data-vedit="${aman(d.id)}">Edit</button>
            <button class="tombolKecil" data-salin="${aman(d.url)}">Salin</button>
            <button class="tombolKecil bahaya" data-vhapus="${aman(d.id)}" data-kunci="${aman(d._kunci || "")}">Hapus</button>
          </td>
        </tr>`).join("")}</tbody></table></div>` : '<div class="kosong">Belum ada aset VIP. Tekan + Aset VIP.</div>'}
    </div>

    <div class="panel">
      <div class="panelAtas"><h3>Item toko, frame, efek, dan ID unik</h3><div class="sub">vipConfig · dijual di Store atau dikirim ke akun</div>
        <div class="filter"><div class="pil on">${itemToko.length} item</div></div></div>
      ${itemToko.length ? `<div class="gulirTabel"><table class="tabelKartu">
        <thead><tr><th>PRATINJAU</th><th>NAMA</th><th>SLOT</th><th>HARGA</th><th>HARI</th><th>ID UNIK</th><th>KUNCI AKUN</th><th>JUAL</th><th>AKSI</th></tr></thead>
        <tbody>${itemToko.sort((x, y) => (Number(x.order) || 0) - (Number(y.order) || 0)).map((d) => `<tr>
          <td data-l="Pratinjau">${pratinjauAset(d.url)}</td>
          <td data-l="Nama"><b>${aman(d.name || d.id)}</b></td>
          <td data-l="Slot">${aman(namaSlot(d.slot))}</td>
          <td data-l="Harga">${Number(d.price) ? rupiah(d.price) + " koin" : "gratis"}</td>
          <td data-l="Hari">${Number(d.days) || 7}</td>
          <td data-l="ID unik">${d.customId ? aman(d.customId) : "—"}</td>
          <td data-l="Kunci akun">${d.targetUid ? aman(d.targetUid) : "—"}</td>
          <td data-l="Jual">${d.store === false ? '<span class="tag blokir">kiriman</span>' : '<span class="tag aktif">dijual</span>'}</td>
          <td data-l="Aksi" data-aksi>
            <button class="tombolKecil" data-iedit="${aman(d.id)}">Edit</button>
            <button class="tombolKecil" data-tarik="${aman(d.id)}">${d.store === false ? "Jual lagi" : "Tarik dari Store"}</button>
            <button class="tombolKecil" data-salin="${aman(d.url)}">Salin</button>
            <button class="tombolKecil" data-icek="${aman(d.id)}">Cek</button>
            <button class="tombolKecil bahaya" data-ihapus="${aman(d.id)}" data-kunci="${aman(d._kunci || "")}">Hapus</button>
          </td>
        </tr>`).join("")}</tbody></table></div>` : '<div class="kosong">Belum ada item toko.</div>'}
      <div class="catatan" style="padding:0 14px 14px">
        Item dengan ID unik memakai kolom customId, dan bisa dikunci ke satu akun lewat kolom kunci akun (UID atau ID angka user).
        Jenis berkas yang didukung: PNG, WEBP, GIF, MP4, dan animasi SVGA. Unggahan disimpan di Firebase Storage folder aset/&lt;slot&gt;.
      </div>
    </div>`;

  $("isiHal").querySelectorAll("[data-salin]").forEach((b) => (b.onclick = async () => {
    try { await navigator.clipboard.writeText(b.dataset.salin); toast("Tautan disalin"); }
    catch (e) { toast(b.dataset.salin); }
  }));
  $("isiHal").querySelectorAll("[data-vedit]").forEach((b) => (b.onclick = () => formAsetVip(semua.find((x) => x.id === b.dataset.vedit))));
  $("isiHal").querySelectorAll("[data-iedit]").forEach((b) => (b.onclick = () => formItemToko(semua.find((x) => x.id === b.dataset.iedit))));
  // Cek apakah berkas item benar-benar bisa dibuka. APK MENYEMBUNYIKAN item yang
  // tautannya mati, jadi ini penyebab paling sering "item tidak muncul di Store".
  const cekTautan = async (it, tombol) => {
    if (!it) return;
    const asli = tombol.textContent;
    tombol.disabled = true;
    tombol.textContent = "Cek…";
    try {
      const t = await auth.currentUser?.getIdToken();
      const r = await fetch(DOMPET_BASE + "/aset-cek", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ t, url: it.url }),
      });
      const j = await r.json().catch(() => null);
      if (!j || !j.ok) throw new Error((j && j.e) || ("HTTP " + r.status));
      if (j.hidup) {
        toast("Tautan hidup (HTTP " + j.status + (j.ukuran ? ", " + ukuranTeks(j.ukuran) : "") + ")");
        tombol.textContent = "OK";
      } else {
        toast("Tautan MATI (HTTP " + j.status + "), item disembunyikan dari Store. Unggah ulang berkasnya.", true);
        tombol.textContent = "Mati";
      }
    } catch (e) {
      toast("Cek gagal: " + (e?.message || e), true);
      tombol.textContent = asli;
    } finally {
      tombol.disabled = false;
    }
  };
  $("isiHal").querySelectorAll("[data-icek]").forEach((b) => (b.onclick = () => cekTautan(semua.find((x) => x.id === b.dataset.icek), b)));
  const hapusAset = async (id, kunci, pesan, tombol) => {
    if (!confirm(pesan)) return;
    const baris = tombol?.closest("tr");
    if (tombol) { tombol.disabled = true; tombol.textContent = "Menghapus…"; }
    // Hilangkan barisnya lebih dulu supaya langsung terlihat, lalu cocokkan ulang
    // dengan isi server. Kalau gagal, gambarAset() memunculkannya kembali.
    baris?.remove();
    try {
      await hapusVip(id, kunci || undefined);
      catatLog("Hapus aset vipConfig", id);
      toast("Terhapus. Slotnya siap diisi ulang");
    } catch (e) {
      toast("Gagal menghapus: " + (e.code || e.message), true);
    }
    gambarAset();
  };
  $("isiHal").querySelectorAll("[data-vhapus]").forEach((b) => (b.onclick = () => hapusAset(
    b.dataset.vhapus, b.dataset.kunci,
    "Hapus aset VIP ini? Gambar untuk slot tersebut akan hilang dari aplikasi.", b)));
  $("isiHal").querySelectorAll("[data-ihapus]").forEach((b) => (b.onclick = () => hapusAset(
    b.dataset.ihapus, b.dataset.kunci,
    "Hapus item ini? Item hilang dari Store dan dari tas semua user yang memakainya.", b)));
  $("isiHal").querySelectorAll("[data-tarik]").forEach((b) => (b.onclick = async () => {
    const it = semua.find((x) => x.id === b.dataset.tarik);
    if (!it) return;
    const jual = it.store === false;
    b.disabled = true; b.textContent = "Menyimpan…";
    try {
      await setStoreVip(it, jual);
      catatLog(jual ? "Jual item di Store" : "Tarik item dari Store", it.name || it.id);
      toast(jual ? "Item dijual lagi di Store" : "Item ditarik dari Store");
      gambarAset();
    } catch (e) {
      b.disabled = false; b.textContent = jual ? "Jual lagi" : "Tarik dari Store";
      toast("Gagal: " + (e.code || e.message), true);
    }
  }));
}

function formAsetVip(aset) {
  const d = aset || { n: 1, slot: "frame", url: "" };
  modal(aset ? "Edit aset VIP" : "Tambah aset VIP", `
    <div class="grid2">
      <div class="isian"><label>Tier VIP</label><select id="vTier">
        ${Array.from({ length: 9 }, (_, i) => i + 1).map((n) => `<option value="${n}" ${Number(d.n) === n ? "selected" : ""}>VIP ${n}</option>`).join("")}
      </select></div>
      <div class="isian"><label>Slot</label><select id="vSlot">
        ${SLOT_ASET.map((s) => `<option value="${s.k}" ${d.slot === s.k ? "selected" : ""}>${s.n}</option>`).join("")}
      </select></div>
    </div>
    <div style="margin-top:12px">${htmlSumber("v", d.url)}</div>
    <div class="isian" style="margin-top:10px"><label>Sampul PNG (ikon di Ransel/Store)</label>
      <input id="vSampul" value="${aman(d.poster || "")}" placeholder="https://.../sampul.png"></div>
    <div class="catatan">Sampul PNG ini yang tampil sebagai ikon kartu di Ransel dan Store. Saat pratinjau dibuka, animasi aslinya tetap diputar. Kalau dikosongkan, aplikasi membuat sampul otomatis dari frame animasi.</div>
    <div class="catatan"><b>Kartu VIP</b> ada di slot <b>Kartu profil VIP (latar kartu)</b>. Gambar atau animasi itu tampil di belakang nama dan medali pada semua sheet profil, otomatis sesuai tier VIP user. Ukuran yang cocok: lebar sekitar 3 banding tinggi 2, misalnya 900x600.<br>Berkas PNG, WEBP, GIF, MP4, atau SVGA. Hasil unggahan langsung dipakai aplikasi untuk tier dan slot ini.</div>`,
    async () => {
      const n = Number($("vTier").value);
      const slot = $("vSlot").value;
      const url = await urlDariSumber("v", `vip${n}`);
      if (!url) return toast("Pilih berkas atau isi tautan", true);
      const jenisV = jenisDariUrl(url);
      let sampul = (document.getElementById("vSampul")?.value || "").trim();
      if (!sampul && aset && aset.url === url && aset.poster) sampul = aset.poster;
      if (!sampul && (jenisV === "svga" || jenisV === "mp4")) sampul = await buatSampul(url, jenisV === "mp4" ? "video" : "svga", `vip${n}`);
      await simpanVip(`vip_${n}_${slot}`, {
        id: `vip_${n}_${slot}`, n, slot, kind: jenisV, url, poster: sampul, meta: true, hasData: false,
        updatedAt: Date.now(), chunks: 0
      });
      catatLog("Simpan aset VIP", `VIP ${n} · ${namaSlot(slot)}`);
      toast("Aset VIP disimpan");
      gambarAset();
    });
}

function formItemToko(item) {
  const d = item || { id: "", slot: "frame", name: "", price: 0, days: 7, order: 0, url: "", customId: "", targetUid: "", store: true };
  modal(item ? "Edit item" : "Tambah item toko", `
    <div class="grid2">
      <div class="isian"><label>Nama item</label><input id="iNama" value="${aman(d.name)}" placeholder="Frame Neon"></div>
      <div class="isian"><label>Slot</label><select id="iSlot">
        ${SLOT_ASET.map((s) => `<option value="${s.k}" ${d.slot === s.k ? "selected" : ""}>${s.n}</option>`).join("")}
      </select></div>
    </div>
    <div style="margin-top:12px">${htmlSumber("i", d.url)}</div>
    <div class="isian" style="margin-top:10px"><label>Sampul PNG (ikon di Ransel/Store)</label>
      <input id="iSampul" value="${aman(d.poster || "")}" placeholder="https://.../sampul.png"></div>
    <div class="grid3" style="margin-top:10px">
      <div class="isian"><label>Harga (koin)</label><input id="iHarga" type="number" value="${Number(d.price) || 0}"></div>
      <div class="isian"><label>Berlaku (hari)</label><input id="iHari" type="number" value="${Number(d.days) || 7}"></div>
      <div class="isian"><label>Urutan</label><input id="iUrut" type="number" value="${Number(d.order) || 0}"></div>
    </div>
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>ID unik (opsional)</label><input id="iCustom" value="${aman(d.customId)}" placeholder="mis. 1000"></div>
      <div class="isian"><label>Kunci ke akun (opsional)</label><input id="iTarget" value="${aman(d.targetUid)}" placeholder="UID atau ID angka user"></div>
    </div>
    <div class="isian" style="margin-top:10px"><label>Dijual di Store</label>
      <div class="saklar ${d.store !== false ? "on" : ""}" id="iToko"></div>
      <div class="catatan">Matikan kalau item ini hanya untuk dikirim ke akun tertentu lewat panel.</div></div>`,
    async () => {
      const nama = $("iNama").value.trim();
      if (!nama) return toast("Nama item wajib diisi", true);
      const url = await urlDariSumber("i", "item");
      if (!url) return toast("Pilih berkas atau isi tautan", true);
      const jenisI = jenisDariUrl(url);
      let sampulItem = (document.getElementById("iSampul")?.value || "").trim();
      if (!sampulItem && item && item.url === url && item.poster) sampulItem = item.poster;
      if (!sampulItem && (jenisI === "svga" || jenisI === "mp4")) sampulItem = await buatSampul(url, jenisI === "mp4" ? "video" : "svga", "item");
      // Awalan sx_ wajib: aplikasi hanya mengenali item katalog berawalan sx_.
      // Dulu item dibuat tanpa awalan sehingga bingkai kiriman panel tidak dipakai
      // dan yang tampil malah bingkai VIP bawaan user.
      // ID disimpan polos (tanpa sx_): aplikasi dan server yang menambah awalan sx_,
      // sama seperti item Store yang sudah terbukti jalan.
      const idItem = item?.id || (nama.toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 20) + "_" + Date.now().toString().slice(-4));
      await simpanVip(`item_${idItem}`, {
        id: idItem, slot: $("iSlot").value, name: nama,
        price: Number($("iHarga").value) || 0,
        days: Number($("iHari").value) || 7,
        order: Number($("iUrut").value) || 0,
        kind: jenisDariUrl(url), url, poster: sampulItem, hasData: false, updatedAt: Date.now(), chunks: 0,
        targetUid: $("iTarget").value.trim(), customId: $("iCustom").value.trim(),
        store: $("iToko").classList.contains("on")
      });
      catatLog(item ? "Edit item toko" : "Tambah item toko", nama);
      toast("Item disimpan");
      gambarAset();
    }, () => $("iToko").classList.toggle("on"));
}

/* ================= game ================= */
async function gambarKatalog() {
  const games = await ambilSemua("games", 200).catch(() => []);
  $("aksiTopbar").innerHTML = `<button class="tombolAtas" id="kePasang">Pasang game</button>`;
  $("kePasang").onclick = () => (location.hash = "#pasang");
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Game terpasang</h3><div class="sub">koleksi games</div>
        <div class="filter"><div class="pil on">${games.length} game</div></div></div>
      ${games.length ? `<table><tr><th>GAME</th><th>ALAMAT</th><th>KEY</th><th>STATUS</th><th>AKSI</th></tr>
        ${games.map((g) => `<tr>
          <td><div class="user"><div class="mini">${aman(g.emoji || "🎮")}</div>${aman(g.name || g.id)}</div></td>
          <td><a class="aksi" href="${aman(g.url)}" target="_blank" rel="noopener">buka</a></td>
          <td>${g.key ? aman(String(g.key).slice(0, 8)) + "…" : "—"}</td>
          <td>${g.active === false ? '<span class="tag blokir">nonaktif</span>' : '<span class="tag aktif">aktif</span>'}</td>
          <td><button class="aksi" data-ghapus="${aman(g.id)}">Hapus</button></td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada game terpasang.<br>Buka menu Pasang game untuk menambahkan.</div>'}
      <div class="catatan" style="padding:0 14px 14px">Daftar ini dibaca aplikasi dari koleksi games. Supaya game baru muncul di HP user tanpa build ulang APK, aplikasi versi berikutnya perlu membaca koleksi ini.</div>
    </div>`;
  $("isiHal").querySelectorAll("[data-ghapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus game ini dari daftar?")) return;
    await deleteDoc(doc(db, "games", b.dataset.ghapus)).then(() => { toast("Game dihapus"); catatLog("Hapus game", b.dataset.ghapus); gambarKatalog(); })
      .catch((e) => toast("Gagal: " + (e.code || e.message), true));
  }));
}

async function gambarPasang() {
  const games = await ambilSemua("games", 200).catch(() => []);
  $("isiHal").innerHTML = `
    <div class="panel" style="max-width:620px">
      <div class="panelAtas"><h3>Pasang game baru</h3><div class="sub">tempel alamat dan key production</div></div>
      <div class="panelIsi">
        <div class="grid2">
          <div class="isian"><label>Nama game</label><input id="pNama" placeholder="Greedy King"></div>
          <div class="isian"><label>Emoji</label><input id="pEmoji" placeholder="🎰" value="🎮"></div>
        </div>
        <div class="isian" style="margin-top:10px"><label>Alamat game (URL)</label><input id="pUrl" placeholder="https://…/index.html"></div>
        <div class="isian" style="margin-top:10px"><label>Key production</label><input id="pKey" placeholder="tempel key dari penyedia game"></div>
        <div class="isian" style="margin-top:10px"><label>Jenis</label><select id="pJenis">
          <option value="web">Web game (buka di WebView)</option>
          <option value="wallet">Game dompet (pakai saldo koin)</option>
        </select></div>
        <button class="tombol" id="pSimpan" style="margin-top:14px">Pasang game</button>
        <div class="catatan">Game tersimpan di koleksi games dan langsung tampil di Katalog game. Aplikasi membaca daftar ini pada versi yang sudah mendukung.</div>
      </div>
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Sudah terpasang</h3><div class="filter"><div class="pil on">${games.length}</div></div></div>
      ${games.length ? `<table><tr><th>GAME</th><th>ALAMAT</th><th>JENIS</th></tr>
        ${games.map((g) => `<tr><td>${aman(g.emoji || "🎮")} ${aman(g.name || g.id)}</td>
        <td style="font-size:10.5px;color:#96a1b4">${aman(String(g.url || "").slice(0, 46))}</td><td>${aman(g.kind || "web")}</td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada game.</div>'}
    </div>`;

  $("pSimpan").onclick = async () => {
    const nama = $("pNama").value.trim(), url = $("pUrl").value.trim(), key = $("pKey").value.trim();
    if (!nama || !url) return toast("Nama dan alamat game wajib diisi", true);
    try {
      await setDoc(doc(db, "games", `game_${Date.now()}`), {
        name: nama, url, key, emoji: $("pEmoji").value.trim() || "🎮",
        kind: $("pJenis").value, active: true, order: Date.now(),
        dibuat: serverTimestamp(), oleh: auth.currentUser.email
      });
      catatLog("Pasang game", `${nama} · ${url}`);
      toast("Game terpasang");
      gambarPasang();
    } catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  };
}

/**
 * Greedy King: chip bet dan RTP.
 * RTP 75 = standar. Naikkan (mis. 100) supaya hasil besar (steak, pizza, salad)
 * lebih sering keluar, jadi JP sering kena. Disimpan lewat server dompet karena
 * aturan RTDB menolak tulisan langsung dari browser panel.
 */
/**
 * Kartu unggah gambar pelat banner pemenang game (Greedy King & Crazy Fruit).
 * Gambarnya disimpan di server (betCfg/gameWinBanner) dan dipakai aplikasi
 * sebagai latar banner terbang, jadi bisa diganti tanpa build ulang.
 */
function kartuBannerMenang() {
  return `
    <div style="margin-top:18px;padding-top:14px;border-top:1px solid #2a2f3a">
      <h3 style="margin:0 0 4px;font-size:15px">Banner pemenang game</h3>
      <div class="catatan">Gambar pelat emas untuk banner terbang Top 1/2/3 di Greedy King dan Crazy Fruit.
        Rasio lebar:tinggi sekitar 5:1 (mis. 1000x200). Foto, nama, coin, dan ikon game digambar aplikasi di atasnya.</div>
      ${htmlSumber("bannerMenang")}
      <button class="tombol" id="bannerMenangSimpan" style="margin-top:10px">Simpan banner</button>
    </div>`;
}

function pasangBannerMenang() {
  if (!$("bannerMenangUrl")) return;
  aktifkanPratinjau("bannerMenang", "gambar");
  walletAdmin({ op: "win_banner_get" }).then((j) => {
    if (j && j.url && $("bannerMenangUrl") && !$("bannerMenangUrl").value) {
      $("bannerMenangUrl").value = j.url;
      tampilkanPratinjau("bannerMenang", j.url);
    }
  }).catch(() => {});
  const simpan = $("bannerMenangSimpan");
  if (simpan) simpan.onclick = async () => {
    try {
      // urlDariSumber: pakai tautan yang diketik atau berkas yang diunggah.
      const url = await urlDariSumber("bannerMenang", "gamewin");
      await walletAdmin({ op: "win_banner_set", url });
      catatLog("Banner pemenang game", url ? "banner diganti" : "banner dihapus");
      toast("Banner pemenang game disimpan");
    } catch (e) { toast("Gagal menyimpan banner: " + (e.message || e), true); }
  };
}

async function gambarGreedy() {
  let cfg = { bet: [100, 500, 1000, 5000, 50000], rtp: 75 };
  try { cfg = Object.assign(cfg, await walletAdmin({ op: "gk_cfg_get" })); }
  catch (e) { toast("Gagal memuat pengaturan greedy: " + (e.message || e), true); }
  const chipTeks = (cfg.bet || []).join(", ");
  $("isiHal").innerHTML = `
    <div class="panel" style="max-width:620px">
      <div class="panelAtas"><h3>Greedy King</h3><div class="sub">chip bet &amp; RTP</div></div>
      <div class="panelIsi">
        <div class="isian"><label>Pilihan chip bet (pisahkan dengan koma)</label>
          <input id="gkBet" value="${aman(chipTeks)}" placeholder="100,500,1000,5000,50000"></div>
        <div class="isian" style="margin-top:10px"><label>RTP game (%)</label>
          <input id="gkRtp" type="number" min="40" max="200" value="${aman(String(cfg.rtp ?? 75))}"></div>
        <div class="catatan">75 = standar. 100 = hasil besar lebih sering (JP sering kena).
          Batas 40 sampai 200. Chip bet ikut berubah di aplikasi tanpa build ulang.</div>
        <button class="tombol" id="gkSimpan" style="margin-top:14px">Simpan pengaturan</button>
        ${kartuBannerMenang()}
      </div>
    </div>`;
  pasangBannerMenang();
  $("gkSimpan").onclick = async () => {
    const bet = $("gkBet").value.split(",").map((x) => Number(String(x).trim())).filter((x) => x > 0);
    if (!bet.length) return toast("Isi minimal satu chip bet", true);
    const rtp = Math.max(40, Math.min(200, Math.floor(Number($("gkRtp").value) || 75)));
    try {
      await walletAdmin({ op: "gk_cfg_set", bet, rtp });
      catatLog("Atur Greedy", "rtp " + rtp + " | chip " + bet.join(","));
      toast("Pengaturan Greedy disimpan");
      gambarGreedy();
    } catch (e) { toast("Gagal menyimpan: " + (e.message || e), true); }
  };
}

/**
 * Crazy Fruit: chip bet dan RTP.
 * RTP 92 = standar. Angka ini yang menentukan pengali buah: naikkan ke 100
 * supaya pemain balik modal, turunkan (mis. 80) supaya keuntungan rumah lebih
 * besar. Semua pengali buah ikut menyesuaikan, jadi tidak ada satu buah yang
 * bisa dipakai menembus RTP. Disimpan lewat server dompet karena aturan RTDB
 * menolak tulisan langsung dari browser panel.
 */
async function gambarFruit() {
  let cfg = { bet: [1000, 5000, 10000, 50000, 100000], rtp: 88 };
  try { cfg = Object.assign(cfg, await walletAdmin({ op: "cf_cfg_get" })); }
  catch (e) { toast("Gagal memuat pengaturan Crazy Fruit: " + (e.message || e), true); }
  const chipTeks = (cfg.bet || []).join(", ");
  $("isiHal").innerHTML = `
    <div class="panel" style="max-width:620px">
      <div class="panelAtas"><h3>Crazy Fruit</h3><div class="sub">chip bet &amp; RTP</div></div>
      <div class="panelIsi">
        <div class="isian"><label>Pilihan chip bet (pisahkan dengan koma)</label>
          <input id="cfBet" value="${aman(chipTeks)}" placeholder="1000,5000,10000,50000,100000"></div>
        <div class="isian" style="margin-top:10px"><label>RTP game (%)</label>
          <input id="cfRtp" type="number" min="50" max="120" value="${aman(String(cfg.rtp ?? 88))}"><div class="catatan">Makin kecil = pola besar (Super Lucky, apel, semangka, mangga, stroberi) makin jarang keluar. 85-90 paling aman.</div></div>
        <div class="catatan">92 = standar. 100 = pemain balik modal, 80 = keuntungan rumah lebih besar.
          Batas 50 sampai 120. Pengali buah ikut menyesuaikan otomatis, chip bet berubah tanpa build ulang.</div>
        <button class="tombol" id="cfSimpan" style="margin-top:14px">Simpan pengaturan</button>
        ${kartuBannerMenang()}
      </div>
    </div>`;
  pasangBannerMenang();
  $("cfSimpan").onclick = async () => {
    const bet = $("cfBet").value.split(",").map((x) => Number(String(x).trim())).filter((x) => x > 0);
    if (!bet.length) return toast("Isi minimal satu chip bet", true);
    const rtp = Math.max(50, Math.min(120, Math.floor(Number($("cfRtp").value) || 88)));
    try {
      await walletAdmin({ op: "cf_cfg_set", bet, rtp });
      catatLog("Atur Crazy Fruit", "rtp " + rtp + " | chip " + bet.join(","));
      toast("Pengaturan Crazy Fruit disimpan");
      gambarFruit();
    } catch (e) { toast("Gagal menyimpan: " + (e.message || e), true); }
  };
}

async function gambarRoket() {
  let cfg = { lv: {}, rank: {} };
  try { cfg = Object.assign(cfg, await walletAdmin({ op: "rocket_cfg_get" })); }
  catch (e) { toast("Gagal memuat hadiah roket: " + (e.message || e), true); }
  const isiLv = (n) => {
    let html = "";
    for (let k = 1; k <= 6; k++) {
      const x = cfg.lv?.[n]?.["r" + k] || {};
      html += `<div class="grid3" style="margin-top:6px">
        <div class="catatan" style="align-self:center">Hadiah ${k}</div>
        <div class="isian"><label>Coin</label><input id="rk${n}_${k}c" type="number" min="0" value="${Number(x.coins || 0)}"></div>
        <div class="isian"><label>VIP (0 = tanpa VIP)</label><input id="rk${n}_${k}v" type="number" min="0" max="9" value="${Number(x.vip || 0)}"></div>
      </div>`;
    }
    return html;
  };
  const isiRank = (k, nama) => {
    const x = cfg.rank?.[k] || {};
    return `<div class="grid3" style="margin-top:6px">
      <div class="catatan" style="align-self:center">${nama}</div>
      <div class="isian"><label>Coin</label><input id="tp${k}c" type="number" min="0" value="${Number(x.coins || 0)}"></div>
      <div class="isian"><label>VIP (0 = tanpa VIP)</label><input id="tp${k}v" type="number" min="0" max="9" value="${Number(x.vip || 0)}"></div>
    </div>`;
  };
  $("isiHal").innerHTML = `
    <div class="panel" style="max-width:760px">
      <div class="panelAtas"><h3>Roket</h3><div class="sub">energi (EXP) &amp; hadiah level 1-5</div></div>
      <div class="panelIsi">
        <div class="catatan">Hadiah roket 1 sampai 5: setiap roket punya 6 kartu hadiah. Saat roket meluncur,
          satu kartu dipilih acak untuk peluncurnya. Isi 0 kalau tidak dipakai.</div>
        <h4 style="margin-top:16px">Energi (EXP) tiap roket</h4>
        <div class="catatan">Energi yang harus terkumpul sebelum roket itu meluncur. Energi datang dari koin gift
          yang dikirim di room. Angka roket 1 paling kecil, lalu naik sampai roket 5. Contoh: 100000000 = 100 juta.</div>
        <div class="grid3" style="margin-top:6px">
          ${[1, 2, 3, 4, 5].map((n) => `<div class="isian"><label>Roket ${n}</label>
            <input id="rkExp${n}" type="number" min="1" step="1000" value="${Number(cfg.exp?.[n - 1] || 0)}">
            <div class="catatan" id="rkExpKet${n}">${fmtKoin(cfg.exp?.[n - 1] || 0)}</div></div>`).join("")}
        </div>
        ${[1, 2, 3, 4, 5].map((n) => `<h4 style="margin-top:16px">Roket level ${n}</h4>${isiLv(n)}`).join("")}
        <h4 style="margin-top:18px">Hadiah peringkat (papan roket)</h4>
        <div class="catatan">Diberikan ke Top 1, Top 2, dan Top 3 penyumbang energi roket.</div>
        ${isiRank(1, "Top 1")}${isiRank(2, "Top 2")}${isiRank(3, "Top 3")}${isiRank(4, "Top 4 (cadangan)")}
        <button class="tombol" id="rkSimpan" style="margin-top:16px">Simpan hadiah roket</button>
      </div>
    </div>`;
  // Angka besar ditampilkan ringkas di bawah isian supaya tidak salah nol.
  for (let n = 1; n <= 5; n++) {
    const el = $(`rkExp${n}`);
    if (el) el.oninput = () => { $(`rkExpKet${n}`).textContent = fmtKoin(Number(el.value) || 0); };
  }
  $("rkSimpan").onclick = async () => {
    const lv = {}, rank = {};
    for (let n = 1; n <= 5; n++) {
      lv[n] = {};
      for (let k = 1; k <= 6; k++) {
        lv[n]["r" + k] = {
          coins: Math.max(0, Math.floor(Number($(`rk${n}_${k}c`).value) || 0)),
          vip: Math.max(0, Math.min(9, Math.floor(Number($(`rk${n}_${k}v`).value) || 0))),
          days: 30,
        };
      }
    }
    for (let k = 1; k <= 4; k++) {
      rank[k] = {
        coins: Math.max(0, Math.floor(Number($(`tp${k}c`).value) || 0)),
        vip: Math.max(0, Math.min(9, Math.floor(Number($(`tp${k}v`).value) || 0))),
        days: 30,
      };
    }
    const exp = [];
    for (let n = 1; n <= 5; n++) exp.push(Math.max(1, Math.floor(Number($(`rkExp${n}`).value) || 0)));
    try {
      await walletAdmin({ op: "rocket_cfg_set", lv, rank, exp });
      catatLog("Atur roket", "Energi " + exp.join(" / ") + " | Top1 " + rank[1].coins + " | Top2 " + rank[2].coins);
      toast("Roket disimpan");
      gambarRoket();
    } catch (e) { toast("Gagal menyimpan: " + (e.message || e), true); }
  };
}

async function gambarBet() {
  const [konfig, games] = await Promise.all([
    ambilSemua("gameConfig", 100).catch(() => []),
    ambilSemua("games", 200).catch(() => [])
  ]);
  // Pengaturan Game Bikini (bet dan RTP) dibaca dari RTDB bikiniCfg.
  let bw = { bets: [25, 50, 100, 200, 500, 1000, 2000, 5000], rtp: 85 };
  try { bw = Object.assign(bw, await walletAdmin({ op: "bikini_cfg_get" })); }
  catch (e) { /* pengaturan bawaan */ }
  const betsBw = Array.isArray(bw.bets) && bw.bets.length ? bw.bets : bw.bets;
  const rtpBw = Number(bw.rtp) || 85;
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Game Bikini: bet &amp; RTP</h3><div class="sub">langsung dipakai game, tanpa build ulang</div></div>
      <div class="panelIsi">
        <div class="isian"><label>Pilihan bet (pisahkan dengan koma)</label><input id="bwBet" value="${aman((betsBw || []).join(", "))}"></div>
        <div class="grid2" style="margin-top:10px">
          <div class="isian"><label>RTP</label><select id="bwRtp">
            <option value="85" ${rtpBw < 95 ? "selected" : ""}>85% — standar biasa</option>
            <option value="95" ${rtpBw >= 95 && rtpBw < 100 ? "selected" : ""}>95% — scater 4 lebih sering</option>
            <option value="100" ${rtpBw >= 100 ? "selected" : ""}>100% — scater 5 sering turun</option>
          </select></div>
          <div class="isian"><label>Peluang scater per gulungan</label><input id="bwScatter" readonly></div>
        </div>
        <button class="tombol" id="bwSimpan" style="margin-top:14px">Simpan bet &amp; RTP Bikini</button>
        <div class="catatan">85% memakai peluang standar 13% per gulungan, 95% menaikkan scater 4, 100% membuat scater 5 paling sering turun. Game membaca pengaturan ini setiap kali dibuka, jadi tidak perlu build ulang.</div>
      </div>
    </div>
    <div class="panel" style="max-width:620px">
      <div class="panelAtas"><h3>Atur nilai bet</h3><div class="sub">berlaku untuk game dompet</div></div>
      <div class="panelIsi">
        <div class="isian"><label>Game</label><input id="tGame" placeholder="zeus, greedy, fruitsparty…"></div>
        <div class="grid3" style="margin-top:10px">
          <div class="isian"><label>Bet minimum</label><input id="tMin" type="number" value="100"></div>
          <div class="isian"><label>Bet maksimum</label><input id="tMax" type="number" value="50000"></div>
          <div class="isian"><label>Pilihan chip</label><input id="tChip" placeholder="100,500,1000"></div>
        </div>
        <button class="tombol" id="tSimpan" style="margin-top:14px">Simpan pengaturan bet</button>
        <div class="catatan">Disimpan di koleksi gameConfig dengan nama dokumen = nama game.</div>
      </div>
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Pengaturan tersimpan</h3><div class="filter"><div class="pil on">${konfig.length}</div></div></div>
      ${konfig.length ? `<table><tr><th>GAME</th><th>MIN</th><th>MAKS</th><th>CHIP</th><th>AKSI</th></tr>
        ${konfig.map((k) => `<tr><td>${aman(k.id)}</td><td>${rupiah(k.minBet)}</td><td>${rupiah(k.maxBet)}</td>
        <td>${aman((k.chips || []).join(", "))}</td>
        <td><button class="aksi" data-hapusbet="${aman(k.id)}">Hapus</button></td></tr>`).join("")}</table>`
        : `<div class="kosong">Belum ada pengaturan bet.${games.length ? " Game terdaftar: " + games.map((g) => aman(g.name)).join(", ") : ""}</div>`}
    </div>`;
  $("tSimpan").onclick = async () => {
    const nama = $("tGame").value.trim().toLowerCase();
    if (!nama) return toast("Nama game wajib diisi", true);
    try {
      await setDoc(doc(db, "gameConfig", nama), {
        minBet: Number($("tMin").value) || 0,
        maxBet: Number($("tMax").value) || 0,
        chips: $("tChip").value.split(",").map((x) => Number(x.trim())).filter((x) => x > 0),
        diperbarui: serverTimestamp()
      }, { merge: true });
      catatLog("Atur bet", nama);
      toast("Pengaturan bet disimpan");
      gambarBet();
    } catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  };
  $("isiHal").querySelectorAll("[data-hapusbet]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus pengaturan bet ini?")) return;
    await deleteDoc(doc(db, "gameConfig", b.dataset.hapusbet)).then(() => { toast("Dihapus"); gambarBet(); })
      .catch((e) => toast("Gagal: " + (e.code || e.message), true));
  }));

  // --- Game Bikini: peluang scater mengikuti RTP ---
  const hitungScater = (rtp) => (rtp >= 100 ? 0.42 : rtp >= 95 ? 0.28 : 0.13);
  const tampilScater = () => {
    const rtp = Number($("bwRtp").value) || 85;
    $("bwScatter").value = Math.round(hitungScater(rtp) * 100) + "% per gulungan";
  };
  if ($("bwRtp")) {
    tampilScater();
    $("bwRtp").onchange = tampilScater;
  }
  if ($("bwSimpan")) $("bwSimpan").onclick = async () => {
    const bets = $("bwBet").value.split(",").map((x) => Number(x.trim())).filter((x) => x > 0);
    if (bets.length < 2) return toast("Isi minimal dua nilai bet", true);
    const rtp = Number($("bwRtp").value) || 85;
    try {
      await walletAdmin({ op: "bikini_cfg_set", bets, rtp });
      catatLog("Atur bet & RTP Bikini", bets.join(", ") + " | RTP " + rtp + "%");
      toast("Pengaturan Bikini disimpan");
    } catch (e) { toast("Gagal: " + (e.message || e), true); }
  };
}

/* ================= database ================= */
const koleksiUmum = ["userIds", "users", "wallets", "rooms", "gifts", "banners", "frames", "banned", "games", "gameConfig", "panelAdmins", "adminLogs", "vipConfig", "counters", "families", "moments", "chats"];
let koleksiPilih = "userIds";
async function gambarDatabase() {
  $("aksiTopbar").innerHTML = `
    <select id="pilihKoleksi" class="cari" style="width:190px">
      ${koleksiUmum.map((k) => `<option value="${k}" ${k === koleksiPilih ? "selected" : ""}>${k}</option>`).join("")}
    </select>
    <input id="koleksiManual" class="cari" style="width:150px" placeholder="koleksi lain…">
    <button class="tombolAtas" id="muatKoleksi">Muat</button>`;
  $("muatKoleksi").onclick = () => {
    const manual = $("koleksiManual").value.trim();
    koleksiPilih = manual || $("pilihKoleksi").value;
    gambarDatabase();
  };
  $("pilihKoleksi").onchange = () => { koleksiPilih = $("pilihKoleksi").value; gambarDatabase(); };

  const docs = await ambilSemua(koleksiPilih, 60);
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>${aman(koleksiPilih)}</h3><div class="sub">60 dokumen pertama</div>
        <div class="filter"><div class="pil on">${docs.length} dokumen</div></div></div>
      ${docs.length ? `<table><tr><th>ID DOKUMEN</th><th>ISI</th><th>AKSI</th></tr>
        ${docs.map((d) => {
          const salinan = { ...d }; delete salinan.id;
          const ringkas = JSON.stringify(salinan);
          return `<tr>
            <td style="font-family:ui-monospace,monospace;font-size:10.5px">${aman(d.id.slice(0, 22))}</td>
            <td style="font-size:10.5px;color:#96a1b4">${aman(ringkas.slice(0, 110))}${ringkas.length > 110 ? "…" : ""}</td>
            <td><button class="aksi" data-doc="${aman(d.id)}">Buka</button></td></tr>`;
        }).join("")}</table>` : '<div class="kosong">Koleksi kosong atau belum ada.</div>'}
    </div>`;
  $("isiHal").querySelectorAll("[data-doc]").forEach((b) => (b.onclick = () => bukaDokumen(koleksiPilih, b.dataset.doc, docs)));
}

function bukaDokumen(namaKoleksi, id, semua) {
  const asli = semua.find((x) => x.id === id) || {};
  const salinan = { ...asli }; delete salinan.id;
  modal(`${namaKoleksi}/${id}`, `
    <div class="isian"><label>Isi dokumen (JSON)</label><textarea id="docIsi" style="min-height:220px">${aman(JSON.stringify(salinan, null, 2))}</textarea></div>
    <div class="catatan">Ubah nilai lalu simpan. Untuk menghapus, tekan tombol Hapus dokumen.</div>`,
    async () => {
      let data;
      try { data = JSON.parse($("docIsi").value); } catch (e) { return toast("JSON tidak valid", true); }
      await setDoc(doc(db, namaKoleksi, id), data);
      catatLog("Ubah dokumen", `${namaKoleksi}/${id}`);
      toast("Dokumen disimpan");
      gambarDatabase();
    }, null, async () => {
      if (!confirm(`Hapus dokumen ${id} dari ${namaKoleksi}?`)) return;
      await deleteDoc(doc(db, namaKoleksi, id));
      catatLog("Hapus dokumen", `${namaKoleksi}/${id}`);
      toast("Dokumen dihapus");
      gambarDatabase();
    });
}

/* ================= log admin ================= */

/* ================= background tab ================= */
const TAB_LATAR = [
  { k: "party",  n: "Tab Party",  ket: "layar belakang beranda Party" },
  { k: "moment", n: "Tab Moment", ket: "layar belakang Moment" },
  { k: "family", n: "Tab Family", ket: "layar belakang Family" },
  { k: "pesan",  n: "Tab Chat / Pesan", ket: "layar belakang daftar chat" },
  { k: "saya",   n: "Tab Saya",   ket: "layar belakang profil Saya" },
  { k: "nav",    n: "Bilah bawah", ket: "latar menu tab di bagian bawah" }
];

async function bacaLatar() {
  const hasil = {};
  try {
    const d = await getDoc(doc(db, "vipConfig", "tabbg"));
    if (d.exists()) Object.assign(hasil, d.data());
  } catch (e) { console.warn("tabbg firestore:", e.code || e.message); }
  if (!Object.keys(hasil).length) {
    try {
      const s = await dGet(dRef(rtdb, "tabBg"));
      if (s.exists()) Object.assign(hasil, s.val());
    } catch (e) { console.warn("tabBg rtdb:", e.code || e.message); }
  }
  return hasil;
}

async function simpanLatar(tab, isi) {
  let ok = 0, galat = "";
  try { await setDoc(doc(db, "vipConfig", "tabbg"), { [tab]: isi }, { merge: true }); ok++; }
  catch (e) { galat = e.code || e.message; }
  try { await dSet(dRef(rtdb, "tabBg/" + tab), isi); ok++; }
  catch (e) { galat = galat || e.code || e.message; }
  if (!ok) throw new Error("Ditolak server: " + galat);
}

async function gambarLatar() {
  const data = await bacaLatar();
  $("aksiTopbar").innerHTML = "";
  const ringkas = (b) => !b || b.mode === "default" || !b.mode ? "bawaan (kerajaan)" : b.mode === "image" ? "gambar" : "gradien";
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Background layar belakang tab</h3><div class="sub">berlaku untuk semua user begitu dipasang</div></div>
      <table><tr><th>TAB</th><th>KETERANGAN</th><th>SAAT INI</th><th>AKSI</th></tr>
        ${TAB_LATAR.map((x) => {
          const b = data[x.k] || {};
          const mini = b.mode === "image" && b.url
            ? `<img src="${aman(b.url)}" style="width:34px;height:52px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:8px">`
            : b.mode === "gradient"
              ? `<span style="display:inline-block;width:34px;height:52px;border-radius:6px;vertical-align:middle;margin-right:8px;background:linear-gradient(${aman(b.c1 || "#1A0B2E")},${aman(b.c2 || "#0B0B0B")})"></span>` : "";
          return `<tr><td><b>${aman(x.n)}</b></td><td>${aman(x.ket)}</td><td>${mini}${aman(ringkas(b))}</td>
            <td><button class="aksi" data-latar="${x.k}">Atur</button></td></tr>`;
        }).join("")}
      </table>
      <div class="catatan" style="padding:0 14px 14px">Pilih Default untuk kembali ke tampilan kerajaan bawaan. Gambar bisa diunggah dari perangkat atau ditempel tautan. Aplikasi menyimpan cache 5 menit, jadi user melihatnya begitu aplikasi dibuka ulang.</div>
    </div>`;
  $("isiHal").querySelectorAll("[data-latar]").forEach((b) => (b.onclick = () => formLatar(b.dataset.latar, data[b.dataset.latar] || {})));
}

function formLatar(kunci, b) {
  const x = TAB_LATAR.find((y) => y.k === kunci);
  const mode = b.mode || "default";
  modal("Background · " + x.n, `
    <div class="isian"><label>Mode</label><select id="ltMode">
      <option value="default" ${mode === "default" ? "selected" : ""}>Default (kerajaan bawaan)</option>
      <option value="image" ${mode === "image" ? "selected" : ""}>Gambar (unggah atau tautan)</option>
      <option value="gradient" ${mode === "gradient" ? "selected" : ""}>Gradien 2 warna</option>
    </select></div>
    <div id="ltGambar" style="margin-top:10px;${mode === "image" ? "" : "display:none"}">
      <label style="font-size:12px;opacity:.7">Gambar latar (disarankan tinggi, mis. 1080x2400)</label>
      ${htmlSumber("lt", b.url || "", ".png,.jpg,.jpeg,.webp,.gif")}
    </div>
    <div id="ltGradien" class="grid2" style="margin-top:10px;${mode === "gradient" ? "" : "display:none"}">
      <div class="isian"><label>Warna atas (hex)</label><input id="ltC1" value="${aman(b.c1 || "#1A0B2E")}"></div>
      <div class="isian"><label>Warna bawah (hex)</label><input id="ltC2" value="${aman(b.c2 || "#0B0B0B")}"></div>
    </div>
    <div id="ltPra" style="margin-top:10px;height:150px;border-radius:12px;border:1px solid #2c3648"></div>`,
    async () => {
      const m = $("ltMode").value;
      const isi = { mode: m, url: "", c1: "", c2: "", ts: Date.now() };
      if (m === "image") {
        isi.url = (await urlDariSumber("lt", "latar")) || "";
        if (!isi.url) throw new Error("Pilih gambar atau isi tautan dulu");
      }
      if (m === "gradient") {
        isi.c1 = $("ltC1").value.trim(); isi.c2 = $("ltC2").value.trim();
        const hex = /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
        if (!hex.test(isi.c1) || !hex.test(isi.c2)) throw new Error("Warna harus format hex, mis. #1A0B2E");
      }
      await simpanLatar(kunci, isi);
      catatLog("Background tab", x.n + " · " + m);
      toast("Background " + x.n + " dipasang");
      gambarLatar();
    });
  const atur = () => {
    const m = $("ltMode").value;
    $("ltGambar").style.display = m === "image" ? "" : "none";
    $("ltGradien").style.display = m === "gradient" ? "" : "none";
    const pra = $("ltPra");
    if (m === "gradient") pra.style.background = `linear-gradient(${$("ltC1").value},${$("ltC2").value})`;
    else if (m === "image") {
      const u = (document.getElementById("ltUrl")?.value || "").trim();
      pra.style.background = u ? `center/cover no-repeat url("${u.replace(/"/g, "")}")` : "#111";
    } else pra.style.background = "linear-gradient(#2a1c4e,#0b0b0b)";
  };
  ["ltMode", "ltC1", "ltC2", "ltUrl"].forEach((id) => document.getElementById(id)?.addEventListener("input", atur));
  document.getElementById("ltMode").addEventListener("change", atur);
  atur();
}

/* ================= customer service ================= */
/* Akun CS disimpan di Realtime Database: _cs/{id,nama,uid,at}.
   APK membaca _cs/uid lebih dulu, jadi berpindah akun tanpa build baru. */
async function gambarCs() {
  $("aksiTopbar").innerHTML = "";
  let info = null;
  try { const s = await dGet(dRef(rtdb, "_cs")); info = s.val() || null; }
  catch (e) { toast("Gagal membaca data CS: " + (e.code || e.message), true); }

  const aktif = info && info.uid && info.aktif !== false ? info : null;
  const dimatikan = info && info.aktif === false;
  const sejak = aktif && aktif.at ? new Date(Number(aktif.at)).toLocaleString("id-ID") : "";

  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Akun Customer Service</h3>
        <div class="sub">semua pesan dari tombol Customer Service di tab Pesan masuk ke akun ini</div></div>
      <div style="padding:0 14px 14px">
        <div class="kartu" style="padding:14px;border-radius:14px;background:${aktif ? "rgba(46,160,67,.12)" : "rgba(255,255,255,.05)"}">
          <div style="font-size:13px;color:#9aa4b2">Status</div>
          <div style="font-size:17px;font-weight:700;margin-top:4px">${aktif ? "AKTIF" : (dimatikan ? "DICABUT" : "BELUM DIATUR")}</div>
          ${aktif ? `
            <div style="margin-top:10px;font-size:14px;line-height:1.7">
              Nama: <b>${aman(aktif.nama || "-")}</b><br>
              ID user: <b>${aman(String(aktif.id || "-"))}</b><br>
              UID: <span class="mono">${aman(String(aktif.uid))}</span>
              ${sejak ? `<br>Diaktifkan: ${aman(sejak)}` : ""}
            </div>` : `
            <div style="margin-top:8px;font-size:13px;color:#9aa4b2">
              Belum ada akun yang ditunjuk. Isi ID user di bawah lalu tekan Aktifkan CS.
            </div>`}
        </div>

        <div class="isian" style="margin-top:14px">
          <label>ID user yang dijadikan Customer Service</label>
          <input id="csId" placeholder="mis. 100005 (ID angka atau UID)" value="${aktif ? aman(String(aktif.id || "")) : ""}">
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
          <button id="csAktif" class="utama">Aktifkan CS</button>
          <button id="csCabut" class="polos">Cabut CS</button>
          <button id="csMuat" class="polos">Muat ulang</button>
        </div>
        <div class="ket" style="margin-top:12px">
          Aktifkan CS: chat Customer Service di aplikasi langsung tersambung ke akun itu, tanpa perlu build APK baru.
          Cabut CS: tombol Customer Service dimatikan dan pesan user tidak lagi masuk ke akun tersebut.
        </div>
      </div>
    </div>`;

  $("csMuat").onclick = () => gambarCs();
  $("csAktif").onclick = async () => {
    const teks = String($("csId").value || "").trim();
    if (!teks) return toast("Isi ID user dulu", true);
    const tombol = $("csAktif");
    tombol.disabled = true;
    try {
      const uid = await uidDariMasukan(teks);
      if (!uid) { tombol.disabled = false; return toast("User dengan ID " + teks + " tidak ditemukan", true); }
      let nama = "", idPakai = teks;
      try {
        const p = await getDoc(doc(db, "users", uid));
        if (p.exists()) {
          const d = p.data();
          nama = d.name || d.nickname || "";
          if (d.userId) idPakai = String(d.userId);
        }
      } catch (e) { }
      await dSet(dRef(rtdb, "_cs"), {
        uid, id: String(idPakai), nama, aktif: true, at: Date.now(),
        oleh: auth.currentUser?.email || "?"
      });
      try { await dSet(dRef(rtdb, "ids/i/" + idPakai + "/uid"), uid); } catch (e) { }
      catatLog("Aktifkan CS", "ID " + idPakai + (nama ? " · " + nama : ""));
      toast("Customer Service aktif untuk ID " + idPakai);
      gambarCs();
    } catch (e) {
      tombol.disabled = false;
      toast("Gagal: " + (e.code || e.message), true);
    }
  };
  $("csCabut").onclick = async () => {
    if (!confirm("Cabut Customer Service? Chat CS tidak akan sampai ke akun mana pun.")) return;
    try {
      await dSet(dRef(rtdb, "_cs"), {
        uid: null, id: aktif ? String(aktif.id || "") : "", nama: aktif ? (aktif.nama || "") : "",
        aktif: false, at: Date.now(), oleh: auth.currentUser?.email || "?"
      });
      catatLog("Cabut CS", aktif ? "ID " + (aktif.id || "") : "");
      toast("Customer Service dicabut");
      gambarCs();
    } catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  };
}

/* ================= pengumuman resmi ================= */
/** Halaman khusus emote room: daftar, unggah, dan hapus emote.
 *  Emote disimpan di vipCfg slot "emote", sumber yang sama dibaca bar emote
 *  dalam room, jadi tidak perlu build APK saat menambah atau menghapus. */
async function gambarEmote() {
  let daftar = [];
  try {
    daftar = (await ambilSemuaVip(400)).filter((d) => String(d.slot || "") === "emote");
    daftar.sort((a, b) => (Number(a.order) || 0) - (Number(b.order) || 0)
      || String(a.name || "").localeCompare(String(b.name || "")));
  } catch (e) { toast("Gagal membaca emote: " + (e.code || e.message), true); }

  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Tambah emote</h3><div class="sub">GIF atau PNG, tampil di bar emote semua room</div></div>
      <div class="grid2">
        <div class="isian"><label>Nama emote</label><input id="emotNama" placeholder="mis. Tawa"></div>
        <div class="isian"><label>Urutan tampil</label><input id="emotUrut" type="number" value="${daftar.length}"></div>
      </div>
      <div style="margin-top:10px">${htmlSumber("emot", "", ".png,.jpg,.jpeg,.webp,.gif")}</div>
      <div style="display:flex;gap:8px;margin-top:14px;align-items:center">
        <button class="tombolUtama" id="emotSimpan">Simpan emote</button>
        <span class="catatan" id="emotHasil" style="padding:0"></span>
      </div>
      <div class="catatan" style="margin-top:12px">Boleh dari perangkat atau tautan, maksimal 4 MB dan sebaiknya kotak. Setelah disimpan emote langsung tampil di tab emot dalam room, tanpa build ulang.</div>
    </div>
    <div class="panel" style="margin-top:12px">
      <div class="panelAtas"><h3>Emote terpasang</h3><div class="sub">${rupiah(daftar.length)} emote</div></div>
      ${daftar.length ? `<table><tr><th>GAMBAR</th><th>NAMA</th><th>URUTAN</th><th>BERKAS</th><th>AKSI</th></tr>
        ${daftar.map((x) => `<tr>
          <td><img src="${aman(x.url || "")}" style="width:48px;height:48px;object-fit:contain;border-radius:8px" loading="lazy"></td>
          <td>${aman(x.name || x.id)}</td>
          <td>${rupiah(Number(x.order) || 0)}</td>
          <td>${aman(cabangBerkas(x.url || ""))}</td>
          <td><button class="aksi" data-emothapus="${aman(x.id)}">Hapus</button></td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada emote. Tambahkan lewat form di atas.</div>'}
    </div>`;

  aktifkanPratinjau("emot");

  $("emotSimpan").onclick = async () => {
    const tombol = $("emotSimpan");
    const hasil = $("emotHasil");
    const nama = $("emotNama").value.trim();
    if (!nama) return toast("Nama emote wajib diisi", true);
    tombol.disabled = true; tombol.textContent = "Menyimpan…";
    try {
      const url = await urlDariSumber("emot", "emote");
      if (!url) throw new Error("Pilih berkas atau isi tautan dulu");
      const id = "emot_" + Date.now().toString(36);
      await simpanVip(id, {
        id, slot: "emote", name: nama, price: 0, days: 0,
        order: Number($("emotUrut").value) || 0,
        kind: cabangBerkas(url), url,
        hasData: false, updatedAt: Date.now(), chunks: 0, store: false,
      });
      catatLog("Tambah emote", nama);
      toast("Emote disimpan");
      await gambarEmote();
    } catch (e) {
      if (hasil) hasil.textContent = "Gagal: " + (e.message || "tidak diketahui");
      toast("Gagal: " + (e.message || "tidak diketahui"), true);
    } finally {
      tombol.disabled = false; tombol.textContent = "Simpan emote";
    }
  };

  $("isiHal").querySelectorAll("[data-emothapus]").forEach((b) => (b.onclick = async () => {
    const id = b.dataset.emothapus;
    if (!confirm("Hapus emote ini?")) return;
    try {
      await hapusVip(id, kunciVip(id));
      toast("Emote dihapus");
      await gambarEmote();
    } catch (e) { toast("Gagal menghapus: " + (e.message || ""), true); }
  }));
}

/** Laporan user dari sheet profil room (koleksi userReports). */
async function gambarLaporan() {
  $("aksiTopbar").innerHTML = '<button class="tombolAtas" id="lapMuat">Muat ulang</button>';
  let daftar = [];
  try {
    daftar = (await ambilSemua("userReports", 500))
      .sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
  } catch (e) { toast("Gagal membaca laporan: " + (e.code || e.message), true); }

  const baru = daftar.filter((d) => (d.status || "baru") !== "selesai").length;
  const baris = daftar.map((d) => {
    const waktu = d.createdAt ? new Date(Number(d.createdAt)).toLocaleString("id-ID") : "-";
    const selesai = d.status === "selesai";
    return `<tr>
      <td>${aman(waktu)}</td>
      <td><b>${aman(d.targetName || "-")}</b><br><span class="mono">ID ${aman(String(d.targetUserId || "-"))}</span><br><span class="mono" style="font-size:11px;opacity:.7">${aman(String(d.targetUid || ""))}</span></td>
      <td>${aman(d.reason || "-")}</td>
      <td>${aman(d.reporterName || "-")}<br><span class="mono" style="font-size:11px;opacity:.7">${aman(String(d.reporterUid || ""))}</span></td>
      <td class="mono">${aman(String(d.roomId || "-"))}</td>
      <td>${selesai ? '<span style="color:#7bd88f">Selesai</span>' : '<span style="color:#ffb74d">Baru</span>'}</td>
      <td style="white-space:nowrap">
        ${selesai ? "" : `<button class="polos" data-lap-selesai="${aman(d.id)}">Selesai</button>`}
        <button class="polos" data-lap-hapus="${aman(d.id)}">Hapus</button>
      </td>
    </tr>`;
  }).join("");

  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Laporan user</h3>
        <div class="sub">${rupiah(daftar.length)} laporan, ${rupiah(baru)} belum ditangani</div></div>
      ${daftar.length ? `<div style="overflow:auto"><table>
        <thead><tr><th>Waktu</th><th>User dilaporkan</th><th>Alasan</th><th>Pelapor</th><th>Room</th><th>Status</th><th></th></tr></thead>
        <tbody>${baris}</tbody></table></div>`
        : '<div class="kosong">Belum ada laporan. Laporan dari sheet profil room muncul di sini.</div>'}
    </div>`;

  $("lapMuat").onclick = () => gambarLaporan();
  document.querySelectorAll("[data-lap-selesai]").forEach((b) => (b.onclick = async () => {
    try {
      await setDoc(doc(kumpulan("userReports"), b.dataset.lapSelesai), { status: "selesai", handledAt: Date.now() }, { merge: true });
      catatLog("Laporan user selesai", b.dataset.lapSelesai);
      toast("Laporan ditandai selesai");
      await gambarLaporan();
    } catch (e) { toast("Gagal: " + (e.message || e.code || ""), true); }
  }));
  document.querySelectorAll("[data-lap-hapus]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus laporan ini?")) return;
    try {
      await deleteDoc(doc(kumpulan("userReports"), b.dataset.lapHapus));
      toast("Laporan dihapus");
      await gambarLaporan();
    } catch (e) { toast("Gagal menghapus: " + (e.message || e.code || ""), true); }
  }));
}

async function gambarPengumuman() {
  let daftar = [];
  try {
    const s = await dGet(dRef(rtdb, "pengumuman"));
    if (s.exists()) {
      const v = s.val();
      daftar = Object.keys(v).map((k) => ({ id: k, ...v[k] }))
        .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (b.at || 0) - (a.at || 0));
    }
  } catch (e) { toast("Gagal membaca pengumuman: " + (e.code || e.message), true); }

  $("aksiTopbar").innerHTML = '<button class="tombolAtas" id="umBaru">+ Pengumuman</button>';
  $("umBaru").onclick = () => formPengumuman(null);

  const tgl = (ms) => ms ? new Date(ms).toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "-";
  $("isiHal").innerHTML = `
    <div class="kartu">
      <div class="stat"><b>${rupiah(daftar.length)}</b><span>Total</span></div>
      <div class="stat"><b>${rupiah(daftar.filter((x) => x.active !== false).length)}</b><span>Tampil di aplikasi</span></div>
      <div class="stat"><b>${rupiah(daftar.filter((x) => x.pinned).length)}</b><span>Disematkan</span></div>
    </div>
    <div class="panel">
      <div class="panelAtas"><h3>Pengumuman resmi</h3><div class="sub">tampil di chat, Pengumuman Resmi, di aplikasi</div></div>
      ${daftar.length ? `<table><tr><th>FOTO</th><th>JUDUL</th><th>ISI</th><th>WAKTU</th><th>STATUS</th><th>AKSI</th></tr>
        ${daftar.map((x) => `<tr>
          <td>${x.img ? `<img src="${aman(x.img)}" style="width:54px;height:54px;object-fit:cover;border-radius:8px" loading="lazy">` : "—"}</td>
          <td>${x.pinned ? "📌 " : ""}${aman(x.title || "")}</td>
          <td>${aman((x.body || "").slice(0, 70))}${(x.body || "").length > 70 ? "…" : ""}</td>
          <td>${aman(tgl(x.at))}</td>
          <td>${x.active === false ? '<span class="tag blokir">disembunyikan</span>' : '<span class="tag aktif">tampil</span>'}</td>
          <td><button class="aksi" data-umedit="${aman(x.id)}">Edit</button> ·
              <button class="aksi" data-umpin="${aman(x.id)}">${x.pinned ? "Lepas semat" : "Sematkan"}</button> ·
              <button class="aksi" data-umtampil="${aman(x.id)}">${x.active === false ? "Tampilkan" : "Sembunyikan"}</button> ·
              <button class="aksi" data-umhapus="${aman(x.id)}">Hapus</button></td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada pengumuman. Tekan + Pengumuman di kanan atas.</div>'}
      <div class="catatan" style="padding:0 14px 14px">Pengumuman yang disematkan tampil paling atas. Teks bisa dipakai saja, foto bisa dipakai saja, atau keduanya.</div>
    </div>`;

  const cari = (id) => daftar.find((x) => x.id === id);
  $("isiHal").querySelectorAll("[data-umedit]").forEach((b) => (b.onclick = () => formPengumuman(cari(b.dataset.umedit))));
  $("isiHal").querySelectorAll("[data-umpin]").forEach((b) => (b.onclick = async () => {
    const x = cari(b.dataset.umpin);
    try { await dUpdate(dRef(rtdb, "pengumuman/" + x.id), { pinned: !x.pinned }); catatLog("Pengumuman", (x.pinned ? "lepas semat " : "sematkan ") + (x.title || x.id)); gambarPengumuman(); }
    catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  }));
  $("isiHal").querySelectorAll("[data-umtampil]").forEach((b) => (b.onclick = async () => {
    const x = cari(b.dataset.umtampil);
    try { await dUpdate(dRef(rtdb, "pengumuman/" + x.id), { active: x.active === false }); gambarPengumuman(); }
    catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  }));
  $("isiHal").querySelectorAll("[data-umhapus]").forEach((b) => (b.onclick = async () => {
    const x = cari(b.dataset.umhapus);
    if (!confirm("Hapus pengumuman \"" + (x.title || x.id) + "\"? Langsung hilang dari aplikasi.")) return;
    try { await dRemove(dRef(rtdb, "pengumuman/" + x.id)); catatLog("Hapus pengumuman", x.title || x.id); toast("Pengumuman dihapus"); gambarPengumuman(); }
    catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  }));
}

function formPengumuman(d) {
  const x = d || {};
  modal(d ? "Edit pengumuman" : "Pengumuman baru", `
    <div class="isian"><label>Judul</label><input id="umJudul" value="${aman(x.title || "")}" placeholder="mis. Pembaruan aplikasi"></div>
    <div class="isian" style="margin-top:10px"><label>Isi pengumuman (teks)</label>
      <textarea id="umIsi" rows="6" style="width:100%;resize:vertical" placeholder="Tulis pengumuman di sini">${aman(x.body || "")}</textarea></div>
    <div style="margin-top:10px"><label style="font-size:12px;opacity:.7">Foto (opsional)</label>
      ${htmlSumber("um", x.img || "", ".png,.jpg,.jpeg,.webp,.gif")}</div>
    <div class="grid2" style="margin-top:10px">
      <div class="isian"><label>Sematkan di atas</label><div class="saklar ${x.pinned ? "on" : ""}" id="umPin"></div></div>
      <div class="isian"><label>Tampil di aplikasi</label><div class="saklar ${x.active !== false ? "on" : ""}" id="umAktif"></div></div>
    </div>`,
    async () => {
      const judul = $("umJudul").value.trim();
      const isi = $("umIsi").value.trim();
      let img = "";
      try { img = (await urlDariSumber("um", "pengumuman")) || ""; }
      catch (e) { return toast("Foto: " + (e.message || e.code), true); }
      if (!judul && !isi && !img) return toast("Isi judul, teks, atau foto dulu", true);
      const id = d ? d.id : "p" + Date.now().toString(36);
      const data = {
        title: judul || "Pengumuman", body: isi, img,
        at: d && d.at ? d.at : Date.now(),
        pinned: $("umPin").classList.contains("on"),
        active: $("umAktif").classList.contains("on"),
        oleh: (auth.currentUser && auth.currentUser.email) || ""
      };
      try {
        await dSet(dRef(rtdb, "pengumuman/" + id), data);
        catatLog(d ? "Edit pengumuman" : "Pengumuman baru", data.title);
        toast("Pengumuman disimpan");
        gambarPengumuman();
      } catch (e) { toast("Gagal menyimpan: " + (e.code || e.message), true); }
    },
    (s) => s.classList.toggle("on"));
}

async function gambarLog() {
  const logs = await ambilSemua("adminLogs", 200).catch(() => []);
  logs.sort((a, b) => (b.waktu?.seconds || 0) - (a.waktu?.seconds || 0));
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Log admin</h3><div class="sub">setiap aksi dari panel dicatat</div>
        <div class="filter"><div class="pil on">${logs.length} catatan</div></div></div>
      ${logs.length ? `<table><tr><th>WAKTU</th><th>ADMIN</th><th>AKSI</th><th>RINCIAN</th></tr>
        ${logs.map((l) => `<tr><td>${waktu(l.waktu)}</td><td>${aman(l.admin)}</td><td>${aman(l.aksi)}</td><td>${aman(l.rincian)}</td></tr>`).join("")}
        </table>` : '<div class="kosong">Belum ada catatan.</div>'}
    </div>`;
}

/* ================= pengaturan ================= */
async function gambarPengaturan() {
  const admins = await ambilSemua("panelAdmins", 100).catch(() => []);
  $("isiHal").innerHTML = `
    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
      <div class="panel" style="width:400px;flex:none">
        <div class="panelAtas"><h3>Daftarkan admin panel</h3></div>
        <div class="panelIsi">
          <div class="isian"><label>Nama</label><input id="aNama" placeholder="Nama admin"></div>
          <div class="isian" style="margin-top:10px"><label>Email (opsional)</label><input id="aEmail" type="email" placeholder="nama@email.com"></div>
          <div class="isian" style="margin-top:10px"><label>Password</label><input id="aSandi" type="text" placeholder="minimal 6 karakter"></div>
          <div class="isian" style="margin-top:10px"><label>Peran</label><select id="aPeran">
            <option value="admin">Admin</option>
            <option value="owner">Owner</option>
          </select></div>
          <button class="tombol" id="aSimpan" style="margin-top:14px;width:100%">Daftarkan admin</button>
          <div class="catatan">Password disimpan Firebase Authentication, bukan di panel. Setelah terdaftar, admin bisa masuk dengan email dan password itu.</div>
        </div>
      </div>

      <div class="panel" style="flex:1;min-width:320px">
        <div class="panelAtas"><h3>Admin terdaftar</h3><div class="filter"><div class="pil on">${admins.length + 1} akun</div></div></div>
        <table>
          <tr><th>NAMA</th><th>EMAIL</th><th>PERAN</th><th>STATUS</th><th>AKSI</th></tr>
          <tr><td>Bang Exxx</td><td>${aman(PEMILIK)}</td><td class="vip">owner</td><td><span class="tag aktif">aktif</span></td><td>—</td></tr>
          ${admins.map((a) => `<tr>
            <td>${aman(a.nama || a.id)}</td><td>${aman(a.id)}</td><td>${aman(a.peran || "admin")}</td>
            <td>${a.aktif === false ? '<span class="tag blokir">dicabut</span>' : '<span class="tag aktif">aktif</span>'}</td>
            <td><button class="aksi" data-toggle="${aman(a.id)}" data-aktif="${a.aktif !== false}">${a.aktif === false ? "Aktifkan" : "Cabut"}</button>
            · <button class="aksi" data-hapusadmin="${aman(a.id)}">Hapus</button></td>
          </tr>`).join("")}
        </table>
        <div class="kaki">Hanya email di daftar ini yang bisa membuka panel.</div>
      </div>
    </div>`;

  $("aSimpan").onclick = async () => {
    if (String((adminSaya && adminSaya.peran) || "") !== "owner") {
      return toast("Hanya Owner yang bisa mendaftarkan admin panel", true);
    }
    const nama = $("aNama").value.trim(), sandi = $("aSandi").value, peran = $("aPeran").value;
    let email = ($("aEmail").value || "").trim().toLowerCase();
    // Email tidak wajib. Kalau dikosongkan, panel membuat alamat login internal
    // dari nama admin, jadi owner cukup mengisi nama dan password.
    const emailInternal = !email;
    if (!nama || sandi.length < 6) return toast("Nama dan password minimal 6 karakter wajib diisi", true);
    try {
      const appKedua = initializeApp(firebaseConfig, "pendaftar-" + Date.now());
      const authKedua = getAuth(appKedua);
      // Buat akun login. Kalau email dikosongkan, alamat dibuat dari nama admin
      // (mis. boypanel@vizapanel.app) supaya password yang diketik langsung berlaku.
      let akunBaru = false;
      const dasar = kunciNama(nama) || "admin";
      const calon = emailInternal
        ? [1, 2, 3, 4, 5].map((n) => dasar + (n === 1 ? "" : n) + "@vizapanel.app")
        : [email];
      let galatTerakhir = null;
      for (const alamat of calon) {
        try {
          const kredensial = await createUserWithEmailAndPassword(authKedua, alamat, sandi);
          await updateProfile(kredensial.user, { displayName: nama }).catch(() => {});
          await signOut(authKedua);
          email = alamat;
          akunBaru = true;
          galatTerakhir = null;
          break;
        } catch (e) {
          galatTerakhir = e;
          const kode = String(e.code || "");
          if (kode !== "auth/email-already-in-use") break;
          if (!emailInternal) { await signOut(authKedua).catch(() => {}); break; }
        }
      }
      if (!akunBaru && galatTerakhir && String(galatTerakhir.code || "") !== "auth/email-already-in-use") throw galatTerakhir;
      await deleteApp(appKedua).catch(() => {});

      await setDoc(doc(db, "panelAdmins", email), {
        nama, peran, aktif: true, dibuat: serverTimestamp(), oleh: auth.currentUser.email
      });
      // Akun lama tidak bisa diberi sandi baru dari panel (Firebase menolak).
      // Jadi kirim tautan reset supaya dia bisa membuat sandi sendiri.
      let tautanTerkirim = false;
      if (!akunBaru && !emailInternal) {
        try {
          await sendPasswordResetEmail(auth, email);
          tautanTerkirim = true;
        } catch (e) { console.warn("reset gagal:", e.code); }
      }

      // Simpan nama agar admin bisa login memakai namanya, bukan email.
      // Kalau aturan Firestore panelNama belum dipublikasikan, jangan gagalkan
      // pendaftaran: admin tetap terdaftar dan bisa masuk memakai email.
      let namaTersimpan = true;
      try {
        await setDoc(doc(db, "panelNama", kunciNama(nama)), { nama, email, peran }, { merge: true });
      } catch (e) {
        namaTersimpan = false;
        console.warn("panelNama gagal:", e.code);
      }
      catatLog("Daftarkan admin", `${nama} · ${email} · ${peran}`);
      toast(
        (akunBaru ? "Admin terdaftar. Dia bisa langsung masuk dengan email dan password itu." : "Email itu sudah punya akun login. Akses panel ditambahkan; dia masuk dengan sandi lamanya atau reset sandi dulu.")
        + (namaTersimpan ? "" : " Catatan: login pakai nama belum aktif karena aturan Firestore panelNama belum dipublikasikan; untuk sekarang masuk pakai email.")
        + (tautanTerkirim ? " Karena akun loginnya sudah ada, tautan buat sandi baru sudah dikirim ke email itu." : ""),
        true,
      );
      gambarPengaturan();
    } catch (e) {
      toast("Gagal: " + pesanAuth(e), true);
    }
  };

  $("isiHal").querySelectorAll("[data-toggle]").forEach((b) => (b.onclick = async () => {
    const aktifBaru = b.dataset.aktif !== "true";
    const emailAdmin = b.dataset.toggle;
    await setDoc(doc(db, "panelAdmins", emailAdmin), { aktif: aktifBaru }, { merge: true })
      .then(async () => {
        // Nama untuk login ikut dicabut atau dipasang lagi supaya sama dengan aksesnya.
        try {
          const dd = await getDoc(doc(db, "panelAdmins", emailAdmin));
          const namaAdmin = dd.exists() ? String(dd.data().nama || "") : "";
          if (namaAdmin) {
            const kunci = kunciNama(namaAdmin);
            if (aktifBaru) await setDoc(doc(db, "panelNama", kunci), { nama: namaAdmin, email: emailAdmin }, { merge: true });
            else await deleteDoc(doc(db, "panelNama", kunci)).catch(() => {});
          }
        } catch (e) { console.warn("panelNama:", e.code); }
        toast(aktifBaru ? "Akses diaktifkan" : "Akses dicabut, dia tidak bisa masuk lagi");
        catatLog(aktifBaru ? "Aktifkan admin" : "Cabut admin", emailAdmin);
        gambarPengaturan();
      })
      .catch((e) => toast("Gagal: " + (e.code || e.message), true));
  }));
  $("isiHal").querySelectorAll("[data-hapusadmin]").forEach((b) => (b.onclick = async () => {
    if (!confirm("Hapus admin ini dari daftar panel? Akun Firebase-nya tetap ada, tapi tidak bisa membuka panel.")) return;
    const emailHapus = b.dataset.hapusadmin;
    try {
      // Ambil namanya dulu supaya pemetaan nama untuk login ikut dibersihkan.
      const dd = await getDoc(doc(db, "panelAdmins", emailHapus));
      const namaHapus = dd.exists() ? String(dd.data().nama || "") : "";
      await deleteDoc(doc(db, "panelAdmins", emailHapus));
      if (namaHapus) await deleteDoc(doc(db, "panelNama", kunciNama(namaHapus))).catch(() => {});
      toast("Admin dihapus, dia tidak bisa masuk lagi. Email yang sama boleh didaftarkan ulang kapan saja.");
      catatLog("Hapus admin", emailHapus);
      gambarPengaturan();
    } catch (e) { toast("Gagal: " + (e.code || e.message), true); }
  }));
}

/* ================= modal ================= */
function modal(judul, isiHtml, saatSimpan, saatToggle, saatHapus) {
  const tirai = el("div", undefined, "tirai");
  tirai.innerHTML = `
    <div class="modal">
      <div class="modalAtas"><h3>${aman(judul)}</h3><button id="modalTutup">✕</button></div>
      <div class="modalIsi">${isiHtml}</div>
      ${saatSimpan || saatHapus ? `<div class="modalKaki">
        ${saatHapus ? '<button class="tombol polos bahaya" id="modalHapus">Hapus dokumen</button>' : ""}
        <button class="tombol polos" id="modalBatal">Tutup</button>
        ${saatSimpan ? '<button class="tombol" id="modalSimpan">Simpan</button>' : ""}
      </div>` : ""}
    </div>`;
  document.body.appendChild(tirai);
  tirai.querySelectorAll("[data-sumber]").forEach((k) => aktifkanPratinjau(k.dataset.sumber));
  const tutup = () => tirai.remove();
  tirai.querySelector("#modalTutup").onclick = tutup;
  const batal = tirai.querySelector("#modalBatal");
  if (batal) batal.onclick = tutup;
  const simpan = tirai.querySelector("#modalSimpan");
  if (simpan) simpan.onclick = async () => {
    simpan.disabled = true;
    try { await saatSimpan(); tutup(); }
    catch (e) { toast("Gagal: " + (e.code || e.message), true); simpan.disabled = false; }
  };
  const hapus = tirai.querySelector("#modalHapus");
  if (hapus) hapus.onclick = async () => {
    hapus.disabled = true;
    try { await saatHapus(); tutup(); }
    catch (e) { toast("Gagal: " + (e.code || e.message), true); hapus.disabled = false; }
  };
  if (saatToggle) {
    tirai.querySelectorAll(".saklar").forEach((s) => (s.onclick = () => saatToggle(s)));
  }
  return tirai;
}

/* mulai */
bukaRute();
console.log("Viza Panel siap · project", firebaseConfig.projectId);

/* pasang sebagai aplikasi */
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}

/* ================= cek in harian ================= */
/* APK membaca RTDB signinCfg: { enabled, target, days/{1..7}{coins,item,itemDays,vip,vipDays} }.
   Jadi hadiah cek in bisa diubah dari sini tanpa membangun ulang APK. */
const BAWAAN_CEKIN = [
  { coins: 10_000_000, item: "", itemDays: 3, vip: 0, vipDays: 0 },
  { coins: 40_000_000, item: "", itemDays: 3, vip: 0, vipDays: 0 },
  { coins: 80_000_000, item: "", itemDays: 3, vip: 0, vipDays: 0 },
  { coins: 10_000_000, item: "", itemDays: 3, vip: 0, vipDays: 0 },
  { coins: 20_000_000, item: "", itemDays: 3, vip: 0, vipDays: 0 },
  { coins: 50_000_000, item: "", itemDays: 3, vip: 0, vipDays: 0 },
  { coins: 100_000_000, item: "", itemDays: 3, vip: 1, vipDays: 0 }
];

function hariCekIn(cfg) {
  const d = (cfg && cfg.days) || {};
  return BAWAAN_CEKIN.map((b, i) => {
    const x = d[String(i + 1)] || {};
    return {
      coins: Number(x.coins ?? b.coins),
      item: String(x.item ?? b.item ?? ""),
      itemDays: Number(x.itemDays ?? b.itemDays ?? 3),
      vip: Number(x.vip ?? b.vip ?? 0),
      vipDays: Number(x.vipDays ?? b.vipDays ?? 0)
    };
  });
}

async function bacaCekIn() {
  const s = await dGet(dRef(rtdb, "signinCfg"));
  return s.exists() ? (s.val() || {}) : {};
}

/* Daftar kunci aset di Store, untuk saran kolom item. */
async function kunciAsetStore() {
  try {
    const s = await dGet(dRef(rtdb, "vipCfg"));
    return s.exists() ? Object.keys(s.val() || {}) : [];
  } catch (e) { return []; }
}

async function gambarCekIn() {
  const cfg = await bacaCekIn();
  const hari = hariCekIn(cfg);
  const aktif = cfg.enabled === false ? false : true;
  const target = Number(cfg.target ?? 18);
  const kunci = await kunciAsetStore();
  const daftarKunci = kunci.map((k) => `<option value="${aman(k)}"></option>`).join("");
  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = `
    <div class="panel">
      <div class="panelAtas"><h3>Cek in harian</h3><div class="sub">hadiah hari 1 sampai 7, dibaca aplikasi langsung dari database</div></div>
      <div style="padding:12px 14px;display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end">
        <div class="isian" style="min-width:170px;margin:0"><label>Cek in harian</label>
          <select id="ciAktif">
            <option value="1" ${aktif ? "selected" : ""}>Aktif</option>
            <option value="0" ${aktif ? "" : "selected"}>Nonaktif</option>
          </select>
        </div>
        <div class="isian" style="min-width:170px;margin:0"><label>Target hari (teks di aplikasi)</label>
          <input id="ciTarget" type="number" min="1" max="365" value="${target}">
        </div>
        <button class="utama" id="ciSimpanAtas">Simpan</button>
      </div>
      <table><tr><th>HARI</th><th>COIN</th><th>ITEM</th><th>VIP</th><th>AKSI</th></tr>
        ${hari.map((h, i) => `<tr>
          <td><b>Hari ${i + 1}</b></td>
          <td>${rupiah(h.coins)}</td>
          <td>${h.item ? aman(h.item) + (h.itemDays ? ` · ${h.itemDays} hari` : "") : "<span style='opacity:.6'>tidak ada</span>"}</td>
          <td>${h.vip ? `VIP ${h.vip}` + (h.vipDays ? ` · ${h.vipDays} hari` : "") : "<span style='opacity:.6'>tidak ada</span>"}</td>
          <td><button class="aksi" data-hari="${i + 1}">Edit</button></td>
        </tr>`).join("")}
      </table>
      <div class="catatan" style="padding:0 14px 14px">Coin dikirim langsung ke dompet user. Kolom item bisa diisi kunci aset Store (mis. frame atau badge) atau dibiarkan kosong. Perubahan berlaku begitu user membuka aplikasi lagi; status klaim tiap user tidak terpengaruh.</div>
      <datalist id="ciAset">${daftarKunci}</datalist>
    </div>`;
  $("ciSimpanAtas").onclick = async () => {
    try {
      await dUpdate(dRef(rtdb, "signinCfg"), {
        enabled: $("ciAktif").value === "1",
        target: Math.max(1, Math.trunc(Number($("ciTarget").value) || 18))
      });
      toast("Cek in harian tersimpan");
      gambarCekIn();
    } catch (e) { toast("Gagal menyimpan: " + (e.code || e.message), "gagal"); }
  };
  $("isiHal").querySelectorAll("[data-hari]").forEach((b) => {
    b.onclick = () => formCekIn(Number(b.dataset.hari), hari[Number(b.dataset.hari) - 1]);
  });
}

function formCekIn(nomor, h) {
  modal("Hadiah hari " + nomor, `
    <div class="isian"><label>Coin</label><input id="ciCoin" type="number" min="0" step="1000" value="${h.coins}"></div>
    <div class="isian"><label>Item Store (kunci aset, boleh kosong)</label>
      <input id="ciItem" list="ciAset2" value="${aman(h.item)}" placeholder="mis. frame-fox">
      <datalist id="ciAset2">${Array.from(document.querySelectorAll("#ciAset option")).map((o) => `<option value="${aman(o.value)}"></option>`).join("")}</datalist>
    </div>
    <div class="isian"><label>Masa item (hari)</label><input id="ciItemHari" type="number" min="0" value="${h.itemDays}"></div>
    <div class="isian"><label>VIP (0 = tidak ada)</label><input id="ciVip" type="number" min="0" max="9" value="${h.vip}"></div>
    <div class="isian"><label>Masa VIP (hari)</label><input id="ciVipHari" type="number" min="0" value="${h.vipDays}"></div>
  `, async () => {
    const isi = {
      coins: Math.max(0, Math.trunc(Number($("ciCoin").value) || 0)),
      item: $("ciItem").value.trim(),
      itemDays: Math.max(0, Math.trunc(Number($("ciItemHari").value) || 0)),
      vip: Math.min(9, Math.max(0, Math.trunc(Number($("ciVip").value) || 0))),
      vipDays: Math.max(0, Math.trunc(Number($("ciVipHari").value) || 0))
    };
    try {
      await dSet(dRef(rtdb, "signinCfg/days/" + nomor), isi);
      toast("Hari " + nomor + " tersimpan");
      gambarCekIn();
    } catch (e) { toast("Gagal menyimpan: " + (e.code || e.message), "gagal"); }
  });
}

/* ================= reward room (Koin banyak) ================= */
/** Panggil server reward room. Panel memakai token login untuk izin admin. */
async function rewardAdmin(p) {
  const u = auth.currentUser;
  if (!u) throw new Error("Belum login");
  const t = await u.getIdToken();
  const res = await fetch(DOMPET_BASE + "/rewardroom", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...p, t })
  });
  const out = await res.json().catch(() => ({}));
  if (!out.ok) throw new Error(out.e || ("HTTP " + res.status));
  return out;
}

let rewardDraf = null;

async function gambarReward() {
  $("aksiTopbar").innerHTML = "";
  $("isiHal").innerHTML = '<div class="kosong">Memuat reward room…</div>';
  let cfg = { aktif: true, banner: "", ikon: "", aturan: "", tiers: [] };
  let lalu = null;
  try {
    const d = await rewardAdmin({ do: "info", uid: "-" });
    cfg = {
      aktif: d.aktif !== false,
      banner: d.banner || "",
      ikon: d.ikon || "",
      aturan: d.aturan || "",
      tiers: Array.isArray(d.tiers) ? d.tiers : []
    };
    lalu = d.lalu || null;
  } catch (e) {
    toast("Gagal memuat reward room: " + (e.message || e), true);
  }
  rewardDraf = cfg.tiers.map((t) => ({ ...t }));
  renderReward(cfg, lalu);
}

function barisTier(t, i) {
  return `<tr data-i="${i}">
    <td>${i + 1}</td>
    <td><input class="rwAliran" type="number" min="0" value="${Number(t.aliran || 0)}"></td>
    <td><input class="rwPemilik" type="number" min="0" value="${Number(t.pemilik || 0)}"></td>
    <td><input class="rwTop" type="number" min="1" max="15" value="${Number(t.top || 1)}"></td>
    <td><input class="rwOrang" type="number" min="0" value="${Number(t.perOrang || 0)}"></td>
    <td><button class="polos rwHapus" title="Hapus baris">✕</button></td>
  </tr>`;
}

function renderReward(cfg, lalu) {
  const pemenangLalu = (lalu && Array.isArray(lalu.pemenang)) ? lalu.pemenang : [];
  $("isiHal").innerHTML = `
    <div class="panel" style="max-width:880px">
      <div class="panelAtas"><h3>Reward room (Koin banyak)</h3><div class="sub">mingguan, otomatis</div></div>
      <div class="panelIsi">
        <div class="catatan">Periode dihitung Senin 00:00 sampai Minggu 23:59 WIB. Hadiah dibagikan otomatis
          Senin 00:05 WIB ke dompet pemenang, dan pemberitahuan dikirim ke chat Customer Service mereka.
          Aliran koin dihitung dari gift yang dibelanjakan di dalam room.</div>

        <div class="grid3" style="margin-top:14px">
          <div class="isian"><label>Acara</label>
            <select id="rwAktif">
              <option value="1"${cfg.aktif ? " selected" : ""}>Aktif</option>
              <option value="0"${!cfg.aktif ? " selected" : ""}>Mati</option>
            </select>
          </div>
          <div class="isian"><label>Gambar banner (tab Party + latar halaman)</label>
            <input id="rwBannerFile" type="file" accept="image/*">
          </div>
          <div class="isian"><label>Gambar ikon (di dalam room)</label>
            <input id="rwIkonFile" type="file" accept="image/*">
          </div>
        </div>
        <div class="grid3" style="margin-top:8px">
          <div class="catatan">Banner: <span id="rwBannerKet">${cfg.banner ? "sudah diunggah" : "belum diunggah"}</span></div>
          <div class="catatan">Ikon: <span id="rwIkonKet">${cfg.ikon ? "sudah diunggah" : "belum diunggah"}</span></div>
          <div class="catatan">Rasio banner 3:1 (misal 1080x360), ikon 211x130.</div>
        </div>
        <div id="rwProgres" class="catatan" style="margin-top:6px"></div>

        <h4 style="margin-top:18px">Tabel hadiah</h4>
        <div class="catatan">Aliran koin dan hadiah dalam satuan coin. Top = jumlah kontributor yang dibayar
          (1 sampai 15). Satu user hanya menerima satu hadiah per minggu, dari tingkat tertinggi.</div>
        <div style="overflow-x:auto;-webkit-overflow-scrolling:touch;margin-top:8px">
        <table class="tabel" style="width:100%;min-width:620px">
          <thead><tr>
            <th>#</th><th>Aliran koin</th><th>Hadiah pemilik</th><th>Top</th><th>Hadiah/orang</th><th></th>
          </tr></thead>
          <tbody id="rwTier">${rewardDraf.map(barisTier).join("")}</tbody>
        </table>
        </div>
        <div class="catatan">Geser tabel ke samping untuk melihat semua kolom.</div>
        <div style="margin-top:8px">
          <button class="polos" id="rwTambah">+ Tambah tingkat</button>
        </div>

        <h4 style="margin-top:18px">Aturan yang tampil di aplikasi</h4>
        <div class="isian"><textarea id="rwAturan" rows="6" style="width:100%">${aman(cfg.aturan)}</textarea></div>

        <div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">
          <button class="tombol" id="rwSimpan">Simpan pengaturan</button>
          <button class="polos" id="rwCek">Lihat pemenang periode ini</button>
          <button class="polos" id="rwBagikan">Bagikan periode ini sekarang</button>
        </div>

        <h4 style="margin-top:18px">Pemenang periode lalu</h4>
        <div id="rwLalu">${
          pemenangLalu.length
            ? pemenangLalu.map((p) => `<div class="catatan" style="margin-top:4px">
                ${aman(p.name || "-")} · ${aman(p.pos || "-")} · ${aman(p.room || "-")} ·
                <b>${rupiah(p.coin || 0)}</b> coin</div>`).join("")
            : '<div class="catatan">Belum ada hadiah yang dibagikan.</div>'
        }</div>
        <div id="rwHasil" style="margin-top:14px"></div>
      </div>
    </div>`;

  const ambilTier = () => {
    const out = [];
    document.querySelectorAll("#rwTier tr").forEach((tr) => {
      out.push({
        aliran: Number(tr.querySelector(".rwAliran").value) || 0,
        pemilik: Number(tr.querySelector(".rwPemilik").value) || 0,
        top: Number(tr.querySelector(".rwTop").value) || 1,
        perOrang: Number(tr.querySelector(".rwOrang").value) || 0
      });
    });
    return out.filter((t) => t.aliran > 0).sort((a, b) => a.aliran - b.aliran);
  };
  const gambarUlangTabel = () => {
    $("rwTier").innerHTML = rewardDraf.map(barisTier).join("");
    ikatTabel();
  };
  const ikatTabel = () => {
    document.querySelectorAll("#rwTier tr").forEach((tr) => {
      tr.querySelector(".rwHapus").onclick = () => {
        rewardDraf.splice(Number(tr.dataset.i), 1);
        gambarUlangTabel();
      };
    });
  };
  ikatTabel();

  $("rwTambah").onclick = () => {
    rewardDraf.push({ aliran: 0, pemilik: 0, top: 1, perOrang: 0 });
    gambarUlangTabel();
  };

  const unggah = async (file, folder, ketId) => {
    const lapor = (p) => { $("rwProgres").textContent = p > 0 && p < 100 ? "Mengunggah gambar… " + p + "%" : (p >= 100 ? "Selesai diunggah" : ""); };
    try {
      const hasil = await unggahBerkas(file, folder, lapor);
      // unggahBerkas mengembalikan URL sebagai teks, bukan objek.
      const url = typeof hasil === "string" ? hasil.trim() : (hasil && hasil.url ? hasil.url : "");
      if (!url) throw new Error("URL gambar tidak diterima server");
      $(ketId).textContent = "sudah diunggah";
      $("rwProgres").textContent = "";
      return url;
    } catch (e) {
      $("rwProgres").textContent = "";
      toast("Gagal mengunggah: " + (e.message || e), true);
      return "";
    }
  };

  $("rwSimpan").onclick = async () => {
    try {
      let banner = cfg.banner || "";
      let ikon = cfg.ikon || "";
      const fb = $("rwBannerFile").files?.[0];
      if (fb) { banner = await unggah(fb, "reward-banner", "rwBannerKet"); if (!banner) return; }
      const fi = $("rwIkonFile").files?.[0];
      if (fi) { ikon = await unggah(fi, "reward-ikon", "rwIkonKet"); if (!ikon) return; }
      const tiers = ambilTier();
      if (!tiers.length) return toast("Isi minimal satu tingkat hadiah", true);
      await rewardAdmin({
        do: "simpan",
        aktif: Number($("rwAktif").value),
        banner, ikon,
        aturan: $("rwAturan").value,
        tiers
      });
      catatLog("Atur reward room", tiers.length + " tingkat, banner " + (banner ? "ada" : "kosong"));
      toast("Pengaturan reward room disimpan");
      gambarReward();
    } catch (e) {
      toast("Gagal menyimpan: " + (e.message || e), true);
    }
  };

  $("rwCek").onclick = async () => {
    try {
      const d = await rewardAdmin({ do: "pemenang" });
      const rooms = Array.isArray(d.rooms) ? d.rooms : [];
      $("rwHasil").innerHTML = rooms.length
        ? `<div class="catatan">Periode ${aman(d.periode?.key || "")} — ${rooms.length} room dengan aliran koin.</div>`
          + rooms.map((r) => `<div class="catatan" style="margin-top:4px">
              <b>${aman(r.nama || "-")}</b> · aliran ${rupiah(r.aliran || 0)} · tingkat ${Number(r.level || 0)} ·
              hadiah pemilik ${rupiah(r.tier?.pemilik || 0)} · ${(r.kontributor || []).length} kontributor dibayar</div>`).join("")
        : '<div class="catatan">Belum ada aliran koin di periode ini.</div>';
    } catch (e) {
      toast("Gagal memuat pemenang: " + (e.message || e), true);
    }
  };

  $("rwBagikan").onclick = async () => {
    const yakin = prompt("Hadiah periode ini akan langsung masuk ke dompet pemenang dan tidak bisa dibatalkan. Ketik BAGIKAN untuk lanjut.");
    if (String(yakin || "").trim().toUpperCase() !== "BAGIKAN") return toast("Dibatalkan", true);
    try {
      const d = await rewardAdmin({ do: "bagikan" });
      const h = d.hasil || {};
      catatLog("Bagikan reward room", "periode " + (h.key || "-") + " total " + (h.total || 0));
      toast(h.sudah ? "Periode ini sudah pernah dibagikan" : "Hadiah dibagikan: " + rupiah(h.total || 0) + " coin ke " + (h.pemenang || 0) + " pemenang");
      gambarReward();
    } catch (e) {
      toast("Gagal membagikan: " + (e.message || e), true);
    }
  };
}
